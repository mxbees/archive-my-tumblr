---
id: 100823683634
slug: rhetorical-questions-for-white-people
date: 2014-10-24 12:00:32 GMT
tags:
- race to the bottom
- discussing discourse
title: "(rhetorical) questions for white people"
---
For those deeply and truly concerned about being anti-racist and checking their shit…

How prepared and comfortable are you with the notion that even if you do everything right, some PoC/non-white/Indigenous people will never trust, like, or love you? That some may always hate your whiteness and all the privilege that comes with it?&nbsp;

Are you prepared to not travel to non-white countries if there isn’t a good, ethical way to do so?

Are you prepared to stop doing yoga, stop getting tattoos and other body mods, etc.?&nbsp;

If you are doing area studies of non-white ares (i.e., Asian studies, etc.) are you prepared to change your major? Career?&nbsp;

Are you really able and willing to accept that some spaces will never be for you and that you are unwelcome there?&nbsp;

I wonder… (but seriously, these question are rhetorical)

