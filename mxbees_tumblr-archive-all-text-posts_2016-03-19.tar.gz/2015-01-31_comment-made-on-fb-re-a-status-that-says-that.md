---
id: 109671108864
slug: comment-made-on-fb-re-a-status-that-says-that
date: 2015-01-31 14:05:00 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
comment made on fb re: a status that says that menstruation related products should be free because condoms are free

while I agree that items related to menstruation should be free. No contest.

I saw the thread (I think) that prompts this post and it was filled with transmisogyny. Moreover, framing it as a ‘people with penises get free condoms’ is still transmisogynist.

Why? Because it still frames trans women with penises as somehow being privileged bc we can get/access free condoms… When this erases the reality that, esp. for us trans women of colour, _having_ a condom on our person can be cause for arrest for suspicion of sex work.

Which partially feeds into the astronomically high percentages of HIV+ trans women of colour (esp. Black trans women of colour in the US).

I’m unclear why asking for free/subsidized menstruation products needs to refer, in any way, to the availability of free condoms, especially when the framing of such only serves to marginalize trans women of colour.

