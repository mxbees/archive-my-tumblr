---
id: 126712526484
slug: hoodooqueer-b-binaohan-hoodooqueer
date: 2015-08-15 01:50:34 GMT
tags:
- epilepsy warning
- hmm hmm
title: 
---
[hoodooqueer](http://hoodooqueer.tumblr.com/post/126712049874):

> [b-binaohan](http://b-binaohan.tumblr.com/post/126711934369):
> 
> > [hoodooqueer](http://hoodooqueer.tumblr.com/post/126710487604):
> > 
> > > [b-binaohan](http://b-binaohan.tumblr.com/post/126710400919):
> > > 
> > > > did i come home from getting tattooed only to find out that most of my friends on here are secret toxic whites?
> > > > 
> > > > \>.\>
> > > > 
> > > > what.&nbsp;
> > > > 
> > > > and all this time i’ve been a poc trans woman twoc?&nbsp;
> > > > 
> > > > hanging around all these whites???
> > > 
> > > How do we know you’re not a white appropriating trans PoC experiences?
> > > 
> > > SO WHAT IS THE TRUTH?<figure class="tmblr-full" data-orig-height="300" data-orig-width="500"><img src="https://31.media.tumblr.com/be794f70884a56b12b67136a124a8cd8/tumblr_inline_nt3omv5IbQ1rdzs46_500.gif" data-orig-height="300" data-orig-width="500"></figure>
> > 
> > i’ll have u know that i’m an authentic 110% trans of colour poc<figure class="tmblr-full" data-orig-height="348" data-orig-width="618"><img src="https://38.media.tumblr.com/cb00c8de36348ad852cdbc19463a1544/tumblr_inline_nt3orjSHDC1qfzb2v_540.gif" data-orig-height="348" data-orig-width="618"></figure><figure data-orig-height="200" data-orig-width="245"><img src="https://33.media.tumblr.com/230a5410d1fafeadf5da9aac05d1d7d8/tumblr_inline_nt3p3lb5k61rdzs46_500.gif" data-orig-height="200" data-orig-width="245"></figure>