---
id: 100158182654
slug: once-more-for-the-record
date: 2014-10-16 13:40:50 GMT
tags:
- b loves logic
- classical biyuti
title: 'Once more for the record: '
---
Anyone who says that they need ‘rational’ or 'logical’ arguments for why they shouldn’t oppress people or why they should see marginalized people as human…

Can have all the fucking seats. All of them. And maybe should go play in traffic.

Because you are a shitstain. Because you fail at being human.

Fuck you. Forever. And ever.

What the fuck is wrong with you?

Fine.

Feel free to use this argument whenever you need to be convinced that oppression is wrong and marginalized people are human:

> 1. If p then q
> 
> 2. p
> 
> Therefore, q.

Just fill in the variables as needed.

Example:

> If I need logic to be see people as human, then I am an asshole.
> 
> I need logic to see people as human.
> 
> Therefore, I am an asshole.

Easy!

