---
id: 127806939654
slug: parents-upset-when-girl-uses-girls-changeroom
date: 2015-08-28 19:38:47 GMT
tags:
- current events
- transmisogyny
- trans bathroom panic
- trans youth
title: Parents upset when girl uses girls changeroom
---
Lila Perry is a high school senior who decided she didn’t want to be unconsensually third-sexed, so she used the gender appropriate facilities.

However, because of her transmisogynist classmates and their equally transmisogynist parents, a controversy has broken out at the school. Bigoted parents say that a cis girl’s right to privacy matters more than Ms. Perry’s dignity.

( [Original Source. Trigger Warnings for transmisogyny, trans bathroom panic, institutional discrimination, parents bullying kids, video in link](https://web.archive.org/web/20150828173511/http://fox2now.com/2015/08/27/transgendered-student-becomes-topic-of-discussion-at-hillsboro-high-school-meeting/))

