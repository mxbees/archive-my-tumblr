---
id: 111650750374
slug: thalmors-honestly-im-getting-really-sick-of
date: 2015-02-21 12:19:43 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[thalmors](http://thalmors.tumblr.com/post/111588301365/honestly-im-getting-really-sick-of-seeing-trans-nb):

> honestly im getting really sick of seeing trans/nb and mentally ill people referred to as “precious children” and “sweet babies” and stuff. like stop infantilizing us please we don’t exist to be cute and precious star children we’re diverse fucking people and we are not little kids in need of your cooing

especially not when u don’t see any of these same people doing a single fucking thing to actually support trans girls

