---
id: 129854574529
slug: peru-had-a-transgender-wedding
date: 2015-09-25 16:55:09 GMT
tags:
- current events
- peru
- wedding
title: Peru had a transgender wedding
---
> A historic first occurred on the night of September 19, 2015 when Thais Izuisa Tuanama, a transgender woman, symbolically tied the knot with her heterosexual partner of three years, Raúl Tello Reategui. The ceremony, which was witnessed by over a hundred of the bride and groom’s family and friends, as well as a sizable contingency of local journalists and television stations, began at 10:45 p.m. and festivities continued into the morning hours of the next day.

( [Original Source](http://web.archive.org/web/20150925094947/http://www.peruthisweek.com/news-inside-perus-first-transgender-wedding-107657))

