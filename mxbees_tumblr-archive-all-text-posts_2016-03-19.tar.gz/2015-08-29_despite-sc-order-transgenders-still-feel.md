---
id: 127873600975
slug: despite-sc-order-transgenders-still-feel
date: 2015-08-29 16:55:11 GMT
tags:
- current events
- discrimination
- transmisogyny
- oppression
- india
title: Despite SC Order, Transgenders Still Feel Discriminated
---
> Transgenders continue to face social exclusion and find it difficult to get official documents including ID cards even after the landmark Supreme Court verdict recognising the ‘third gender’, participants at a recent conference said.
> 
> Many transgender representatives said it was “almost impossible” for them to obtain identity papers and other official documents like Aadhar or ration cards and passports, and most of the cases came from states like Delhi, Jharkhand, Gujarat and West Bengal, a JGLS release said. According to Laxmi Tripathi, one of the intervenors in the landmark NALSA case in which the Supreme Court has created the 'third gender’ status for transgenders, expressed disappointment over the non-implementation of the verdict in several states.

( [Original Source. Trigger Warnings for transmisogyny, systemic oppression](https://web.archive.org/web/20150828201524/http://www.newindianexpress.com/nation/Despite-SC-Order-Transgenders-Still-Feel-Discriminated/2015/08/27/article2996478.ece))

