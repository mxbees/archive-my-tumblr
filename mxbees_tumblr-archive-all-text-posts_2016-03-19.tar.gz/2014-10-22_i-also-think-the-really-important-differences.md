---
id: 100626326419
slug: i-also-think-the-really-important-differences
date: 2014-10-22 00:29:42 GMT
tags:
- race to the bottom
title: 
---
i also think the really important differences between how east asia was colonized

vs south or SE asia was

is part of why there are such major differences in how they conceptualize and relate to white supremacy.

like, i know the history of China and Japan. and i know the history of the PH.

so fucking different. over 400 years of colonization vs 200 years of dealing with white imperialism

(colonisation never reached the same level in China and Japan as it did in the PH. and… yeah)

