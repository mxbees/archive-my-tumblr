---
id: 107122962059
slug: b-binaohan-soooo-here-is-a-thing-i-find
date: 2015-01-04 17:28:05 GMT
tags:
- antiblackness is real
title: 
---
[b-binaohan](http://xd.binaohan.org/post/107004390929/soooo-here-is-a-thing-i-find-interesting-i):

> soooo…
> 
> here is a thing i find interesting. i reblogged two posts by disabledqueerdyke today about Rita Hester.
> 
> one mentions that TDoR was created in response to her murder
> 
> and the other notes that we need to recognize that the Black community has a lot to do with knowledge of her life and death
> 
> _one_ of these posts has 200+ notes and the other? 28 (at this moment)
> 
> can u guess which one?
> 
> i hope all the ppl who’re reblogging one, but not the other recognize that their anti-Blackness is showing.
> 
> could u be more transparent?

a day later

and the one about tdor is almost 20k and the one about the role the Black community played in making sure she is remembered… at 300 or so.

i just.

i feel like i could write a long 2k word post about anti-Blackness in teh ~trans~ community

but. i don’t have the heart for it.

but this is also why i def. don’t want anything to do with teh ~trans~ community anymore.

just.

so.

transparent

