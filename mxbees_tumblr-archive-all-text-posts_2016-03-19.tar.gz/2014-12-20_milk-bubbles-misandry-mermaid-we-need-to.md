---
id: 105681415234
slug: milk-bubbles-misandry-mermaid-we-need-to
date: 2014-12-20 11:27:55 GMT
tags:
- race to the bottom
- b loves logic
title: 
---
[milk-bubbles](http://milk-bubbles.tumblr.com/post/103253612255/misandry-mermaid-we-need-to-get-rid-of-this):

> [misandry-mermaid](http://misandry-mermaid.tumblr.com/post/103252330963/we-need-to-get-rid-of-this-idea-of-logic):
> 
> > We need to get rid of this idea of “logic \> emotions”.&nbsp; It’s not a competition.&nbsp; They aren’t in opposition with each other.&nbsp; They are not gender-inherent or gender-specific, either.&nbsp; They are two incredibly valuable aspects of the human experience, and are both completely vital to our existence, not only at the survival level but with the goal of wanting to live a full, whole, mindful life.&nbsp; Stop putting them on a value hierarchy of human characteristics and start seeing them both as gifts that we must nurture and tend to equally.
> 
> I feel like the idea that “logic trumps emotion,” stems from hatred of the feminine, as greater emotional range is considered a feminine trait.
> 
> And I’d like to note that I’ve mostly only ever heard this argument coming from men and it makes me wonder if men ever use it against other men as often as they use it against women because I feel like probably not.

speaking to rubato’s tags…

ur missing out on part of the story here if u think that this is only about misogyny.

it isn’t.

it is also about race.

the value that ‘logic/reason’ \> 'emotion’ comes from the enlightenment (with seeds sown before then as well). more importantly, it isn’t just that 'logic trumps emotion’.

like the way ur framing this is still within the enlightenment framework of logic and rationality.

bc it actually goes _deeper_ than privileging rationality over emotion. the enlightement literally defines rationality/logic as being _without_ emotion of any kind. this is why they exist in a dichotomy that ends up getting coded with

- good \> bad
- man \> woman
- white \> iaopoc

bc u also need to remember that the enlightenment is also the formal ideology of white supremacy. just as the value of 'reason \> emotion’ encodes sexism, it encodes white supremacy.

don’t leave this out.

