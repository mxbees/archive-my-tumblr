---
id: 108503782479
slug: id-like-to-state-for-the-record-that-i-really
date: 2015-01-19 02:23:29 GMT
tags:
- accountability post
title: 
---
i’d like to state for the record that i really like @whatabootsecondbreakfast and hold them blameless for pretty much all the things.

