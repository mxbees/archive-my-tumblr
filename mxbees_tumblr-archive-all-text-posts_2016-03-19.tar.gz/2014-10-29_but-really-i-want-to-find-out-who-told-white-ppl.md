---
id: 101215751079
slug: but-really-i-want-to-find-out-who-told-white-ppl
date: 2014-10-29 00:37:45 GMT
tags:
- media musings
title: 
---
but really

i want to find out who told white ppl that describing white skin as

‘golden’

was even remotely accurate

