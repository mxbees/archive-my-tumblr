---
id: 107937603244
slug: idk-maybe-someday-ill-be-less-disaffected-by
date: 2015-01-13 00:35:06 GMT
tags:
- the life of an ordinary bakla
title: 
---
idk.

maybe someday i’ll be less disaffected by the shit on tumblr to

maybe actually get into the conversation about why certain topics are perceived as sancrosact

i mean….

o

i’m probably a terrible example for anyone to follow bc i talk a lot about shit that i’d probably be better off keeping my mouth shut about.

esp. since i often talk about stuff where… i’m the oppressor.

and maybe i need to take several steps back and re-think what i talk about and what i engage.

but of course. it is one of those things where u can never win, in the end. bc if u focus narrowly on talking ONLY about stuff that actually impacts u, u end up erasing and tacitely being complicit in other ppl’s oppression.

eh.

i don’t fucking know.

i feel like quitting everything.

no more blogging. no more books. nothing.

(this is not a plea for anyone to tell me how important my writing is. it isn’t that important. very little of what i write is new or novel. and many ppl are better writers than me)

