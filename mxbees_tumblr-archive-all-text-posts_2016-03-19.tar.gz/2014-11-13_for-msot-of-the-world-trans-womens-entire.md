---
id: 102491130604
slug: for-msot-of-the-world-trans-womens-entire
date: 2014-11-13 01:10:01 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
for msot of the world

trans women’s entire existence revolves around our shrodinger’s penis

so many ppl will be amazed and agog

at the fact that some trans women will do away with teh almighty penis

this possible absence of the magical,mighty penis is a great source of despaire, fear, and hatred for a subset of the ppl who hate trans women

on the other hand… are all the people who worry endlessly and obsess about the fact that a trans woman might actually

_have_

teh almighty penis

this also causes feelings of fear, disgust, and extreme hatred

interestingly… the two groups don’t really overlap all that much, but they sort of do too.

the whole notion of the trap

is the dire fear of the unknown

is there or isn’t there a penis????

how can ppl live with this kind of ambiguity????

worse is the implications…

if we do accept that trans women are, indeed, women

than….

every woman potentially could have the penis

life looses all meaning

it is the end of the world

no one will be able to sleep at night anymore

(except for us… since our fearsome power is knowledge. we are the few. the chosen. we actually know what is what. we can sleep peacefully at night…)

