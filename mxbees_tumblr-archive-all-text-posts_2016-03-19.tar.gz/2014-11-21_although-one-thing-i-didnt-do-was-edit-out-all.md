---
id: 103196249134
slug: although-one-thing-i-didnt-do-was-edit-out-all
date: 2014-11-21 12:00:29 GMT
tags:
- the life of an ordinary bakla
title: 
---
although. one thing i didn’t do was edit out all of my ‘pauses’

what i mean by this, is that i didn’t edit my audio post

so that i sounded neurotypical. bc. well. i’m not.

the pauses i take aren’t necessarily me thinking…

i just sometimes stop in the middle of a thought/sentence

and it can take me a few seconds to resume

