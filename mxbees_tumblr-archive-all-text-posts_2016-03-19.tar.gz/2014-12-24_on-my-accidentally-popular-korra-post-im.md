---
id: 106078774289
slug: on-my-accidentally-popular-korra-post-im
date: 2014-12-24 19:45:49 GMT
tags:
- media musings
title: 
---
on my accidentally popular korra post…

I’m getting some poc saying that they felt empathy for her….

which is sort of irrelevant to my point, which is about narrative framing

also, I’m not surprised that poc feel empathy for korra. I mean… if anyone was going to it’d be them

it is white ppl who’ve been shown to have no empathy for poc…

