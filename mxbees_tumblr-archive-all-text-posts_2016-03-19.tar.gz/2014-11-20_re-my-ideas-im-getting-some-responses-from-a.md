---
id: 103133724284
slug: re-my-ideas-im-getting-some-responses-from-a
date: 2014-11-20 18:02:04 GMT
tags:
- decolonization nao
- discussing discourse
- antiblackness is real
- accountability post
- op
title: 
---
re: ‘my ideas’

i’m getting [some responses from a friend (\*waves at Tala\*)](http://xd.binaohan.org/post/103116354489/yungmeduseld-replied-to-your-post-i-dont) that i might be over-interpreting but i wanted to clarify a certain thing about [my post on people using ‘my ideas’](http://xd.binaohan.org/post/103083141894/i-dont-necessarily-tend-to-think-of-myself-as).

when i refer to ‘my ideas’ what i’m really meaning to say is ‘my articulation of these ideas which are not unique or ~owned~ by me’.

a lot of my ideas aren’t unique. they certainly aren’t owned by me. i see myself as fundamentally embedded within a community of discourse. so many of the things i write about and how i conceive of them are deeply influenced by the discussions, interaction, thoughts, and existence of the people around me. esp. the ones i regularly interact with.

there is no coherent way for me to assert that any given idea is ‘mine’ without, at the same time, engaging in anti-Blackness and the erasure of Indigenous ppls.

this is actually the no.1 reason why i was being super non-specific when i was writing about it yesterday. because i don’t perceive these ideas as ‘mine’ in any sense of ‘ownership’ or ‘property’. they aren’t. the ideas and concepts that i discuss and talking about don’t belong to me.

while my perspective and my words are my own, there is also no way to coherently isolate them from the influence of the Black and/or Indigenous people i regularly speak with (in addition to the Latin@ ppl and the other Asians). i cannot even begin to fully articulate how fundamentally my perspective and my way of framing certain concepts/ideas/problem has been influence, changed, and transformed by the people around me.

here is an example:

the current discourse, esp. on tumblr, concerning the notiono of ‘binarism’ and/or the binary and its relationship to colonization has been strongly influenced by my articulation of the connection. it [started with this post](http://b.binaohan.org/blog/binarism-and-colonialism/). this was two or so years ago.

but notice how in that post i mention that the inspiration was directly from a conversation i was having with Riley. my understanding and conception of the relationship between the binary and colonialism didn’t occur in a vacuum. Riley has just as much credit, ~ownership~ over the idea as i do. perhaps more since it has hard to say whether or not i’d ever have gone down this intellectual path if not for them.

and i’ve writen elsewhare that i ended up doing a bit of research and it looks like there are some academics who’ve likewise explored the relationship between the gender binary and colonialism. i’ve also written that i enjoy encountering independent articulations of the same ideas i hold because it helps me confirm that what i’m articulating is meaningful and perhaps _true_ aspect of the world.

i have zero interesting in trying to claim credit or ownership over ideas that aren’t ‘mine’.

doing so, for example, would erase the incalculable influence that Tala has had on my way of thinking.

one a different level, this is in part what is desired in a capitalist system that operates on the fungibility of Blackness. the concept of ‘intellectual property’ is fundamentallyfucked up and dependent on anti-Blackness and settler colonialism.

within this system, there isn’t any real room for talking about communally created intellectual works. no way to say, actually the ideas contained [within this blog post](http://b.binaohan.org/blog/binarism-myths-and-reality/) are ‘owned’ by:

- Tala
- Riley
- metalmujer
- an Indigenous person i won’t mention by name bc i know they try to stay out of the light
- strugglingtobeheard
- girljanitor
- Blackamazon
- so-treu
- bad-dominicana
- Kai

and other people whose names i can’t remember bc that was written like a year ago and it is hard to delineate this conversation from ones that i’m _still_ having with some of the people on the list.

even the ideas within _this_ post aren’t mine (re: intellectual property and the creative works of community).

anyway.

things like intellectual property and copyright and the idea of a single ‘owner’ of ideas also require decolonization.

and this isn’t to say that credit shouldn’t go where it is due. indeed, quite the opposite, this is about truly giving credit where it is warranted. about understanding that so much intellectual work and knowledge creation are communal, not individual activities. the model of a distant thinker who sits shut away from others and thinks deeply about the world is super fucking white. and i don’t really want any part of it.

