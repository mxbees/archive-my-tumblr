---
id: 109890386039
slug: not-for-white-ppl
date: 2015-02-02 17:35:00 GMT
tags:
- decolonization nao
title: "(not for white ppl)"
---
ugh. i don’t know what the problem is, but, like. tumblr won’t let me reblog anything)

@this-is-not-filipinx and @pinoy-culture

i totally have more thoughts about the convo re: tattooing.

i very much do beleive that being inspired by our culture(s) to continue and recreate traditions is a great way to go.

and yeah. as i said. i feel… uncomfortable with the way that many of us in the diaspora want ~tribal~ tattoos without really reflecting on why…

and. OMG.

i totally agree with the filipin@ (inspired) tattoos that look like polynesian ones…

they also make me SO UNCOMFORTABLE.

