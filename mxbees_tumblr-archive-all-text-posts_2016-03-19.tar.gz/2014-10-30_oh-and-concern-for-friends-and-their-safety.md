---
id: 101342401904
slug: oh-and-concern-for-friends-and-their-safety
date: 2014-10-30 15:15:11 GMT
tags:
- the life of an ordinary bakla
title: 
---
oh?

and concern for friends and their safety

pretty much trumps any ideological whatever i have

like this sort of thing is no.1 for me.

no principle is worth hurting ppl i care about over

