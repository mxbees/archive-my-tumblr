---
id: 101334638309
slug: radicallyqueerandnow-b-binaohan-man-the
date: 2014-10-30 12:34:49 GMT
tags: []
title: 
---
[radicallyqueerandnow](http://radicallyqueerandnow.tumblr.com/post/101299049487):

> [b-binaohan](http://xd.binaohan.org/post/101220778419/man-the-only-shit-on-asexuality-that-i-ever-read):
> 
> > man, the only shit on asexuality that i ever read that makes sense is by poc
> 
> Any such readings you’d recommend in particular?

um… the one i just read by can’t remember anything? I didn’t book mark it.  
  
but gradientlair has some great discussions about asexuality and being a Black woman.  
  
(gradientlair is just great. period)

