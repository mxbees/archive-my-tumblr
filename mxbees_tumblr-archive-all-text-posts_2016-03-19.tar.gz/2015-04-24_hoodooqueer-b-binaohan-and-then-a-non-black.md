---
id: 117278956049
slug: hoodooqueer-b-binaohan-and-then-a-non-black
date: 2015-04-24 21:06:21 GMT
tags:
- antiblackness is real
title: 
---
[hoodooqueer](http://hoodooqueer.tumblr.com/post/117276563399/b-binaohan-and-then-a-non-black-person-will):

> [b-binaohan](http://xd.binaohan.org/post/117249770954/and-then-a-non-black-person-will-tell-me-hey):
> 
> > and then a non-Black person will tell me “hey, these convos aren’t for u” which is TRUE but… the timing is suspicious. ( [x](http://twitter.com/b_binaohan/status/591590411317207040))
> 
> TBH, I think it’s your place to call out non-Black people on antiblackness at any time, anywhere. If they don’t like it, maybe they should try not being antiblack. “You’re not Indigenous, so you can’t call out the antiblackness in this conversation about us that excludes Black people” bitch that leaves just Black people to defend/fend for ourselves. Swerve hella to the left, to the left

Ok. I’m going to trust you on this since…. Yeah.

It is interesting to me that I always get this when I’m talking about antiBlackness or defending Black ppl.

Just. Interesting.

