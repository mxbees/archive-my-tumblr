---
id: 100465537984
slug: and-the-nerve-stop-including-this-in-your
date: 2014-10-20 02:14:28 GMT
tags:
- able ability
- ye olde abuse culture
title: 
---
and the nerve…

‘stop including this in your lists of abusive behaviours!11!!’

u know.

these lists actually _help_ people contextualize and understand their experiences

the helped me a lot when i first got on tumblr

because a lot of the fucked up shit my parents did still seemed normal to me

but now i have words and ways to name and articulate my experiences

but hey. why bother caring about victims/survivors of emotional abuse?

