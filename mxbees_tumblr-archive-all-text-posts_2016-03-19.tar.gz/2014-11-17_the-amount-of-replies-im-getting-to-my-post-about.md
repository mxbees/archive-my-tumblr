---
id: 102827575699
slug: the-amount-of-replies-im-getting-to-my-post-about
date: 2014-11-17 00:16:37 GMT
tags:
- teh trans community
- transmisogyny is fun for the whole family
title: 
---
the amount of replies i’m getting to [my post about hormone blockers](http://xd.binaohan.org/post/102657008874/me-starting-to-get-really-fucking-annoyed-at-the) that assume i’m stupid right off the bat

(this is what is implied when ppl are saying “this isn’t the intended message!”)

i know what the post was trying to communicate

so why are you trying to silence me with this spurious garbage?

one. intent isn’t magic. u know this. or u should.

the reification, no matter what the intent, of the white medicalized model of trans

is _one_ of the ways that (racialized) transmisogyny inflicts itself onto my self and body

this means that an implicit support of this model of transness directly contributes to my oppression.

i’m not talking figuratively. i literally cannot get the right gender marker on my birthcertificate because white ppl have decided that i am not a woman unless i go through painful, invasive, and costly surgery.<sup id="fnref:p102827575699-1"><a href="#fn:p102827575699-1" rel="footnote">1</a></sup>

_why_ the fuck should i stay silent on a post/issue that is directly contributing to how i’m oppressed so that some asshole can make a cutesy post about hormone blockers for trans kids?

do i matter less because i’m an adult?

OR

as i pointed out in my post: dismantling transmisogyny and cissexism actually would help both me **and** trans kids.

both of us.

all of us.

* * *

1. 

which, if ur wondering, also means i can’t get a passport and thus means i’m basically stuck in my country for the foreseeable future.&nbsp;↩

