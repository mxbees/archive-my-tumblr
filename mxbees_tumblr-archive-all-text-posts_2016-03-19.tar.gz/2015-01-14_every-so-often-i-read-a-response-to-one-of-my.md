---
id: 108037044079
slug: every-so-often-i-read-a-response-to-one-of-my
date: 2015-01-14 02:14:16 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
every so often

I read a response to one of my posts and it breaks my fucking heart

like….

fuck.

my heart hurts for all the trans women who are in the closet bc they know the world will always think they are ugly.

and my heart hurts for all the out trans women who feel ugly all the time bc they disgust in the faces of cis ppl every fucking day.

you’re all so beautiful to me.

