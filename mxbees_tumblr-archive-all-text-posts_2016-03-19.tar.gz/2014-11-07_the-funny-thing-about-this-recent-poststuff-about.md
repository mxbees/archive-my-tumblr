---
id: 102017895809
slug: the-funny-thing-about-this-recent-poststuff-about
date: 2014-11-07 17:07:55 GMT
tags:
- transmisogyny is fun for the whole family
- teh queer community
title: 
---
the funny thing about this recent post/stuff about all these cis gays

going on and on about how trans women have co-opted their movement…

is that you can even see this notion trickling into ‘progressive’ spaces and into some 'progressive’ discourse

like.

it might seem tedious and annoying to some ppl nowadays for twoc to constantly be saying

“we started this. this is our movement.”

bc a lot of people i know actually know this by know

(but this is self-selecting, bc i don’t think i’d really bother hanging out with anyone who either didn’t know this or was in total denial about it)

bc this isn’t just about being ignorant about history

it is deeper and vaster than this

since the cis gay and cis lesbian rewriting of history

to push a certain narrative about how it was and always will be them

who matter the most

is about a violent process of consolidating power and enforcing hegemony over the discourse

and so we get to this point

where even with ppl who’ll recognize the history of the ~lgbt movement~

will turn around and say

“trans women are getting all the attention”

“trans women are talking up too much space”

“trans women are like the trump card when talking about gender-based oppression”

and, yeah, i’ve seen this said by a white nonbinary agender person who is a Big Name in disability activism

i’ve seen this expressed by a trans man of colour who is a Big Name in trans-activism

Black trans women literally get _two_ high profile role models

and suddenly it is all TOO MUCH

and twoc are getting accussed of playing ~oppression olympics~

coopting movements we started

getting all the media attention and love

despite the very real ongoing reality that

in the US it is Black and/or Latina trans women experiencing the majority of ~anti-lgbt violence~

and globally it is twoc who, yes, are experiencing the most violent oppression

but any assertion by us that we are

human

and thus deserve to set boundaries (ie, who can and can’t use tranny)

deserve respect, dignity, and safety

but in this zero sum game

any attention given to twoc means

no one else can get attention/safety/dignity/love

so. yeah.

fuck ur umbrella.

fuck all of them.

fuck ~lgbt~

fuck ~mogaii~

fuck ~trans~

fuck ~trans\*~

fuck ~transgender~

fuck ~gay~

fuck ~lesbian~

fuck ~queer~

fuck

ur

umbrella

