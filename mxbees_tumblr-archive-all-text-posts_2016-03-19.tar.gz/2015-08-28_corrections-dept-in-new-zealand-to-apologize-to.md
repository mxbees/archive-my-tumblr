---
id: 127810279984
slug: corrections-dept-in-new-zealand-to-apologize-to
date: 2015-08-28 20:33:26 GMT
tags:
- current events
- incarceration
- transmisogyny
- institutional abuse
title: Corrections Dept. in New Zealand to apologize to Jade Follet for some bullshit
  reason
---
The Corrections Department in New Zealand has finally admitted to receiving Jade Follet’s request to be incarcerated in a gender appropriate facility much earlier than they had previously claimed.

Local activists have been protesting and working to secure Ms. Follet’s transfer. And now the corrections deparment is doing some back-peddling for PR.

( [Original Source. Trigger Warnings for incarceration, transmisogyny, institutional abuse](https://web.archive.org/web/20150828174244/http://www.odt.co.nz/news/national/353946/corrections-apology-transgender-inmate))

