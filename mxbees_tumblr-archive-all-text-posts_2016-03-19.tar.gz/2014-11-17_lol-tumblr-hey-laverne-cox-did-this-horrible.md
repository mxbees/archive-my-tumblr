---
id: 102905814419
slug: lol-tumblr-hey-laverne-cox-did-this-horrible
date: 2014-11-17 22:29:11 GMT
tags:
- transmisogyny is fun for the whole family
- antiblackness is real
title: 
---
lol @ tumblr

hey. Laverne Cox did this horrible misogynist thing

_links to rabid transwoman hating website_

hahahaha.

fuck u all.

