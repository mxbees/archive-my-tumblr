---
id: 103888222474
slug: yes-i-point-out-frequently-that-atesh-the-xkit
date: 2014-11-29 13:57:15 GMT
tags:
- discussing discourse
- ur fav is problematic
- antiblackness is real
title: 
---
yes. i point out frequently that Atesh, the xkit guy, is problematic.

i hold a grudge about something he said about filipin@s and i’m a petty bitch and this shouldn’t surprise anyone.

but my pettiness doesn’t actually erase his history of ableism, anti-Blackness, or misogyny.

your fav is problematic.

my other big issue is the way that people… act like he is this great, wonderful, saviour person because he maintains an extension that makes tumblr more useable for a lot of us. he isn’t a saint. he is a person. and is flawed and problematic. like all people. including me.

i’m super happy to have xkit because i’m pretty sure i’d have given up on tumblr a long time ago without it.

the sort of thing that actually gets me excited is [a social media site created by a Black trans woman and a collective of queer/trans ppl](https://www.indiegogo.com/projects/quirell)

support that project than hoping some d00d makes another shitty social media site.

