---
id: 128364352054
slug: the-thing-that-amuses-me-most-about-these
date: 2015-09-04 23:23:49 GMT
tags:
- the life of an ordinary bakla
title: 
---
The thing that amuses me most about these community discussions is how much I know that I’m not a part of it and never have been. There has never been space or room for me. It has never been welcoming or accepting. Sure sure It claims me. And I guess that’s my ~privilege~.

