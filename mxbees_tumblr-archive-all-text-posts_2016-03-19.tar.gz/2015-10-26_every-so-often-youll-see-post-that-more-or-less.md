---
id: 131920895349
slug: every-so-often-youll-see-post-that-more-or-less
date: 2015-10-26 01:41:20 GMT
tags:
- discussing discourse
- decolonization nao
- op
title: 
---
every so often you’ll see post that more or less asserts:

“things would be so much better if we spend as much time loving each other/ourselves as we do hating white ppl”

by some poc who thinks that they are contributing something useful to teh discourse.

i think most recently it was this variation:

“imagine if we focused on loving each other instead of being angry/resentful towards white queers who reject us”

or something.

as much as i do get what these ppl are trying to communicate it always leaves me with a bitter taste in my mouth and one usual response:

fuck u.

i resent being told to just ‘get over’ my terrible experiences in dealing with white gays

i resent the implication that i was vulnerable to being hurt bc i just wasn’t focused on loving other poc, instead of seeking white validation.

i resent the idea that anyone, including other poc, are entitled to my love and attention.

i resent the idea that i can’t hate and love at the same time.

i resent being told that i’m not processing my emotions and trauma fast enough to suit someone else’s schedule.

no.

