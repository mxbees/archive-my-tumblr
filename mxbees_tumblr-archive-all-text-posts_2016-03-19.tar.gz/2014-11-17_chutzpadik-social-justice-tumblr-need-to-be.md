---
id: 102869253054
slug: chutzpadik-social-justice-tumblr-need-to-be
date: 2014-11-17 12:35:36 GMT
tags:
- able ability
- teh trans community
- transmisogyny is fun for the whole family
title: 
---
[chutzpadik](http://chutzpadik.tumblr.com/post/102822590729/social-justice-tumblr-need-to-be-really-really):

> social justice tumblr need to be really really really careful about conflating ‘has a slightly bigger number of awareness posts here on tumblr dot com’ with ‘actually materially oppresses people with more obscure illnesses’ in re: certain personality disorders.
> 
> that kinda bullshit showcases a fundamental misunderstanding of how systems of oppression function, and it’s how we end up with concepts like, uh, ‘bpd privilege’.

oh, hey.  
  
This was exactly what I was talking about when I said that trans women of colour get a lot of lip service when it comes to centering us on the internet…  
  
But how this rarely ever translates to offline.   
  
Where you’ll get dfab agender ppl  
  
\*cough\*youneedacat\*cough\*  
  
talking about how trans women of colour take up too much conceptual space when it comes to talking about gender-based oppression.

