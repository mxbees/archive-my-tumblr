---
id: 107140807649
slug: ugh-im-really-sorry-everyone-i-shouldve
date: 2015-01-04 20:48:49 GMT
tags: []
title: 
---
ugh. i’m really sorry everyone. i should’ve cropped that screen cap bc i’m finding it really disorienting to see the blue bar in the centre o the post.

bleh.

sorry

