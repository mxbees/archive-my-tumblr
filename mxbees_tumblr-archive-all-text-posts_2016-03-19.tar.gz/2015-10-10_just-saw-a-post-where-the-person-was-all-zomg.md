---
id: 130891232584
slug: just-saw-a-post-where-the-person-was-all-zomg
date: 2015-10-10 17:53:13 GMT
tags:
- able ability
- op
title: 
---
just saw a post where the person was all

“zomg! tumblr haz reduced disability discourse to a litst of words u can’t say!11!!!”

its one of those things that pops up every so often.

“why isn’t everyone doing Teh Discourse exactly how i think they should be???”

“why isn’t anyone talking about This Issue That Really Really Matters to me?????”

the mind boggles.

like. sure. ppl say and do a lot of wonky, weird, and kind of boring stuff here.

and i definitely get irritated by Teh Discourse on here frequently enough.

but seeing ppl add on to the OP going “this is real ableism” as if words don’t, in fact, actually matter.

sure, resisting ableism is more than a list of words. but words do matter.

i just get tired of ppl trying to control teh discourse by saying what is real and not real, while insisting that everyone else needs to care about what they care about and talk about it in the way they talk about it.

fuck u, basically.

