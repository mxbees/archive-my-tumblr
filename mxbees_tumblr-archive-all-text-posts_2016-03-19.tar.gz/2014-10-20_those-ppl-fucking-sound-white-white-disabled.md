---
id: 100464699534
slug: those-ppl-fucking-sound-white-white-disabled
date: 2014-10-20 02:04:39 GMT
tags:
- able ability
- ye olde abuse culture
title: 
---
those ppl fucking sound white. white disabled activists love to pull this

‘omg. this set of traits is part of a disability, thus saying they can be abusive is ableism’

gtfo

i hate u all

there are so many different ways to be abusive. indeed…

while we can note that there are common/similar patterns of behaviour

it is also the case that it is as individual as the abuser and the victim

the problem with this line of thinking is acting as if there is some

objective, observable quality to abuse

IT DOESN’T WORK LIKE THIS

if the victim/survivor names their abuser and says ‘

this and this behaviour was abusive’

even if this is part of some diagnostic criteria for a mental illness or disability

IT REMAINS ABUSIVE

no one other than the victim/survivor has a right to decide if we were abused

fuck u

and ur support of abuse culture

