---
id: 104442646564
slug: it-grates-me-how-many-ppl-who-clearly-dont-know-a
date: 2014-12-05 23:17:00 GMT
tags:
- race to the bottom
title: 
---
it grates me how many ppl who clearly don’t know a single thing about racism and it’s history try and act like they are experts

