---
id: 102794152494
slug: seeing-some-transmisogynist-self-defense-thing
date: 2014-11-16 17:37:12 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
seeing some transmisogynist self-defense thing about how to kick men in the balls…

with extra advice by a radfem tacked on

gross

just.

gross.

