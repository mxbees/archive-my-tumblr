---
id: 130654182429
slug: but-really-im-really-sorry-for-everyone-who-has
date: 2015-10-07 01:39:19 GMT
tags:
- able ability
title: 
---
but really. I’m really sorry for everyone who has to deal with shitty doctors who decide to be yet another barrier and obstacle in our lives.

like. it’s so incredibly and deeply awful. and I hope you can all access competent and affirming health care soon.

