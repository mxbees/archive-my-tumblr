---
id: 104442481414
slug: lol-i-still-cant-believe-im-seeing-ppl-here
date: 2014-12-05 23:14:48 GMT
tags:
- race to the bottom
title: 
---
lol

I still can’t believe I’m seeing ppl here trying to claim that Greek ppl aren’t white…

r u fucking kidding me?

whiteness has claimed them for a long time.

