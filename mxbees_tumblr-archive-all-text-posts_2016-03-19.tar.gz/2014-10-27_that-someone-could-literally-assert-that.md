---
id: 101045535729
slug: that-someone-could-literally-assert-that
date: 2014-10-27 01:01:52 GMT
tags:
- discussing discourse
title: 
---
that someone could literally assert that

~begging for money privilege~

is a real thing

is probably the best example of why

[privilege is a functionally useless concept](http://b.binaohan.org/blog/on-privilege-as-a-functionally-useless-concept/)

