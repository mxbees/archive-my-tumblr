---
id: 100513644234
slug: like-srsly-only-someone-white-or-a-poc-who-is
date: 2014-10-20 17:55:36 GMT
tags:
- race to the bottom
title: 
---
like, srsly. only someone white or a poc who is regularly coded as white

would think to themselves

‘how dare u make assumptions about my race based on my white supremacist behaviour. i don’t even know who my father was! and my grandpa said i might not be his grandoffspring'stop including this in your lists of abusive behaviours!11!!’

there isn’t some complicated rubric for knowing whether u aren’t white or not

while there are some genuine edge cases… these ppl usually know who they are too.

ur basically saying ‘no one ever told me i was anything other than white, so i might not be white!’

lol

