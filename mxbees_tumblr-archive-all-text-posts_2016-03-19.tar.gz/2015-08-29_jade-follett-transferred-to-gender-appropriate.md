---
id: 127827264250
slug: jade-follett-transferred-to-gender-appropriate
date: 2015-08-29 01:06:01 GMT
tags:
- current events
- incarceration
- trans women
title: Jade Follett transferred to gender appropriate facility
---
After a local activist group, No Pride in Prisons, began a hunger strick on Aug 27, 2015, they recieved word from Ms. Follett that she has finally been transfered to a women’s facility.

( [Original Source. Trigger Warnings for incarceration, transmisogyny, non-graphic description of violence](https://archive.is/KnP74))

