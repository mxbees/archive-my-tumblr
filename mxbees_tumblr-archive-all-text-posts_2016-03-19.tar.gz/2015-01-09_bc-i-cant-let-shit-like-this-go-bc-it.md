---
id: 107587053224
slug: bc-i-cant-let-shit-like-this-go-bc-it
date: 2015-01-09 10:18:16 GMT
tags:
- race to the bottom
title: 
---
bc i can’t let shit like this go….

bc it irritates me to no end

but also bc it leads ppl to pushing some strange theories/notions about race

if u actually look at the sources for scientific racism (which codified and formalized already existing systems of racism), you’ll find that eastern europeans and northern europeans were ALWAYS white.

yes. they were sub-races within white and considered inferior to the ‘nordic’ race (northern and west euros), but still white.

and note: the sources for scientific racism are all european. mainly french, german, with some english.

these are EUROPEAN racial distinctions.

the narrative of 'how italians and irish’ became white, though, is usually something discussed in the colonies, particularly america, where settlement happened primarily from french and england (at the beginning). then other europeans 'immigrated’. and the irish and eastern and southern europeans were discriminated against based on this notion that they were inferior _whites_

BUT.

how do we know they were STILL WHITE in america?

1. they could ALWAYS vote
2. they were citizens (and able to be citizens)
3. they could own property
4. they could marry OTHER white ppl (as in, not anti-miscagnation laws)

as in, they were LEGALLY WHITE.

once you really let this sink in, you realize that the narrative of 'becomes white’ is false and it kind of forces u to re-examine how certain gropus ppl claim are following in this path (East Asians and light skin Latin@s) might not actually be.

how does one bc white when the distinction has been remarkably firm over the years?

