---
id: 126211359084
slug: fyi-mentally-ill-ppl-are-going-to-exist
date: 2015-08-09 00:01:43 GMT
tags:
- able ability
title: 
---
fyi: mentally ill ppl are going to exist post-capitalism

you know. just like we existed pre-capitalism.

jesus

