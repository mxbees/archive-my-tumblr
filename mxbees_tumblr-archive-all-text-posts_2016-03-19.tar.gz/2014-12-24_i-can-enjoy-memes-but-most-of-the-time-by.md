---
id: 106074816424
slug: i-can-enjoy-memes-but-most-of-the-time-by
date: 2014-12-24 18:53:43 GMT
tags:
- the life of an ordinary bakla
title: 
---
i can enjoy memes….

but most of the time

by the time i’ve figured out what they mean and how i could maybe use them

they are done with.

i really am an old person. lol.

this is what i get for being 30+ on tumblr

