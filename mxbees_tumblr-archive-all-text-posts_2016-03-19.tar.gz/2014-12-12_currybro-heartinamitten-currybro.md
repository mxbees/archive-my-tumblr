---
id: 105013944784
slug: currybro-heartinamitten-currybro
date: 2014-12-12 16:30:51 GMT
tags:
- decolonization nao
- it literally takes five minutes of internet research
- and some critical thinking
- to put all these pieces together
title: 
---
[currybro](http://currybro.tumblr.com/post/105012825690/heartinamitten-currybro-b-binaohan-idly):

> [heartinamitten](http://heartinamitten.tumblr.com/post/105012520233/currybro-b-binaohan-idly-wonders-if-all-the):
> 
> > [currybro](http://currybro.tumblr.com/post/105012366050/b-binaohan-idly-wonders-if-all-the-rebellious):
> > 
> > > [b-binaohan](http://xd.binaohan.org/post/104958653094/idly-wonders-if-all-the-rebellious-body-modders):
> > > 
> > > > \*idly wonders if all the rebellious body modders realize that the counter-culture nature is bc of the cultural iaopoc roots of body mods\*
> > > 
> > > i’m just curious as to what this means, like…. do you mean it’s cultural appropriation? because europeans/basically everyone in the world has been doing body mods like tattoos for thousands of years.
> > > 
> > > _“The oldest documented tattoos belong to Otzi the Iceman, whose preserved body was discovered in the Alps between Austria and Italy in 1991. He died around 3300&nbsp;B.C., says Jablonski, but the practice of inserting pigment under the skin’s surface originated long before Otzi.”_
> > > 
> > > i don’t know much about piercing or other body mods but i know tattoos are far from a culturally exclusive thing as the japanese did it, a lot of asia did it, native americans have done it, and europeans have done it
> > > 
> > > so could you explain this better
> > 
> > cursory research into contemporary modern tattoo culture in the west is directly specifically appropriated from iaopoc cultures
> > 
> > see: sailor jerry & ed hardy
> 
> you raise a really good point and i hadn’t thought of those sorts of tattoos, so i can’t deny that. it still seems like sort of a broad statement though, as a lot of tattoos are also derivative of traditional european tattoos

this literally comes up _every single time_ i talk about the (modern) history of tattooing…

you don’t have to look all that hard at the history of white/euro tattooing to find out that _all_ white traditions of tattooing died out bc of christianity

and then tattooing got _reintroduced_ into white culture via colonialism. like we actually have an _exact_ historical person who we know reintroduced tattooing to white ppl (captain cook).

tattooing as a modern white cultural practice has its roots in white colonialism.

end of story.

this isnt just about certain motifs.

_without_ white colonialism and white supremacy, white ppl would not be getting tattoos today.

