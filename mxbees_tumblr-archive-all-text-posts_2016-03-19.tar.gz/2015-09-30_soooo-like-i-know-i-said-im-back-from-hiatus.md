---
id: 130231369549
slug: soooo-like-i-know-i-said-im-back-from-hiatus
date: 2015-09-30 23:26:17 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
soooo.

like. i know i said i’m back from hiatus. but i guess i’ve just been consumed by doing this critical race research.

and i’m still fucking flabbergasted that this is the shit that current scholars are putting out (of many races)

i don’t think that anything is more clear about how academia is a white supremacist institution that _will_ coopt you

