---
id: 106284080144
slug: it-always-kills-me-how-many-ppl-identify
date: 2014-12-27 03:31:46 GMT
tags:
- ye olde abuse culture
title: 
---
it always kills me

how many ppl identify with/are validated by

the posts i make about abuse.

this is how u know that abuse is a culture

not just individual actions between ppl

