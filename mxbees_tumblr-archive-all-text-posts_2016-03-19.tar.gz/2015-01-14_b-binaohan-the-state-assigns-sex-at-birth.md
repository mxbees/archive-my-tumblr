---
id: 108114286689
slug: b-binaohan-the-state-assigns-sex-at-birth
date: 2015-01-14 23:22:19 GMT
tags:
- teh trans community
title: 
---
[b-binaohan](http://xd.binaohan.org/post/108077416239/the-state-assigns-sex-at-birth):

> the state assigns sex at birth [http://t.co/pYxelD9o1S](http://t.co/pYxelD9o1S) ( [x](http://twitter.com/b_binaohan/status/555371584807260160))

note: this is the most recent post on my main blog. about the state function of assigning sex at birth.

