---
id: 100158185874
slug: it-disheartens-me-that-so-many-of-us-keep-up-the-idea
date: 2014-10-16 13:40:54 GMT
tags:
- ye olde abuse culture
- classical biyuti
title: It disheartens me that so many of us keep up the idea that some deserve protection
  and some don't.
---
And that this idea is always, always grounded in some behaviour policing garbage.

That only if you do _x_, will you avoid dire fate _y_.

When it is clear that the value of _x_ is usually 0 and nothing can stop some people from hurting you.

But somehow the discussion is always what is the value of _x_ such that _x_ \> 0 that will suddenly cause people to care about you and to think you are worth protecting.

Because some victims are always to blame and will never deserve protection.

