---
id: 100536744829
slug: it-is-funny-but-not-really-how-unwilling-so
date: 2014-10-20 23:05:00 GMT
tags:
- antiblackness is real
title: 
---
it is funny (but not really)

how unwilling so many non-Black ppl who’re somehow involved in anti-oppressive discourse/activism/whatever

or even ppl just trying to talk about their experiences

how unwilling (we) are to recognize that pretty much all of this has come from Black ppl.

even more unwilling to actively work to dismantle our own anti-Blackness

so that our engagement with these ideas can be just a little _less_ shitty

