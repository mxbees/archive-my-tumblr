---
id: 127817318213
slug: transgender-inmate-claims-correctional-officer
date: 2015-08-28 22:22:31 GMT
tags:
- current events
- rape
- prison rape
- incarceration
- abuse from authorities
title: Transgender inmate claims correctional officer raped her at Rikers Island
---
> A transgender inmate transitioning into a woman claims she was repeatedly raped by a Rikers Island corrections officer and jail officials turned a blind eye.

( [Original Source. Trigger Warnings for rape, prison rape, incarceration, abuse from authorities](https://web.archive.org/web/20150828175111/http://www.correctionsone.com/corrections/articles/8737289-Transgender-inmate-claims-correctional-officer-raped-her-at-Rikers-Island/))

