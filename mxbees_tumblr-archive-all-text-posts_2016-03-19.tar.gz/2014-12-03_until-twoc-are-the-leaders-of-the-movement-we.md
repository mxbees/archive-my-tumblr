---
id: 104199041799
slug: until-twoc-are-the-leaders-of-the-movement-we
date: 2014-12-03 00:18:23 GMT
tags:
- teh queer community
- transmisogyny is fun for the whole family
title: 
---
until twoc are the leaders of the movement we started

every other group trying to squeeze themselves into what we started

(while maintaining a system where we are pushed out and exploited)

you assholes can

_wait_

or maybe wake the fuck up to the fact that

uplifting and support twoc

would do so much more to improve your lives

than trying to join a shitty umbrella whose existence depends on

exploitation and hegemony

