---
id: 101943366839
slug: i-dont-care-how-many-different-kinds-of-ppl
date: 2014-11-06 19:18:06 GMT
tags:
- transmisogyny is fun for the whole family
- teh trans community
title: 
---
i don’t care how many different kinds of ppl

tell me that i should hate and loathe my body

it isn’t going to happen

i like my voice

i’m pretty okay with my body hair

i like my genitals just fine

this body is mine

this body is me

i am this body

and while i have trouble with the whole

~love ur body~

thing

this doesn’t mean i hate it.

or that i want to be shamed for having it

