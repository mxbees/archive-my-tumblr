---
id: 130909404384
slug: so-im-getting-into-numerology-in-the-hopes
date: 2015-10-10 23:12:17 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
so…

i’m getting into numerology (in the hopes that i find some way to appropriately listen to my ancestors without them having to destroy my life…)

and like the big stopping point, imo, is the fact that it relies heavily on one bit of information that, as a trans person, does not make me happy:

your name as it was written on your birth certificate.

like. this is how you’re supposed to calculate your destiny number.

i refuse.

i simply do not accept this. i refuse to accept that my dead name, the name my parents gave me is what’ll decide my destiny.

the unfortunate thing is that using the birth certificate name does yield accurate results. so the question is how to get the same number using different information that could be considered as meaningful/important as you deadname…

so far, what i’ve found yields the most consistent results is:

last name at birth + your astrological sign + the name of the town/city/whatever you were born in

in my tests so far, this regularly results in the same number as the birth certificate name.

but… i’d like more data before fully committing and i need to see how it impacts the rest of the chart (which relies heavily on the birth certificate name).

