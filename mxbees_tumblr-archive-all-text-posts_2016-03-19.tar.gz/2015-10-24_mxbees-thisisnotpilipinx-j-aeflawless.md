---
id: 131818304564
slug: mxbees-thisisnotpilipinx-j-aeflawless
date: 2015-10-24 16:24:40 GMT
tags:
- accountability post
- antiblackness is real
title: 
---
[mxbees](http://mxbees.tumblr.com/post/131804021754):

> [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131795136292):
> 
> > [j-aeflawless](http://j-aeflawless.tumblr.com/post/131794797266):
> > 
> > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131793955202):
> > > 
> > > > [tenacious-dingo](http://tenacious-dingo.tumblr.com/post/131793597080):
> > > > 
> > > > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131791261662):
> > > > > 
> > > > > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131790682622):
> > > > > > 
> > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131788837004):
> > > > > > > 
> > > > > > > > [wandamaxifuckoff](http://wandamaxifuckoff.tumblr.com/post/131787741317):
> > > > > > > > 
> > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131732201999):
> > > > > > > > > 
> > > > > > > > > > [wandamaxifuckoff](http://wandamaxifuckoff.tumblr.com/post/131719498987):
> > > > > > > > > > 
> > > > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131627684869):
> > > > > > > > > > > 
> > > > > > > > > > > > [glowingnectar](http://glowingnectar.tumblr.com/post/131624043727):
> > > > > > > > > > > > 
> > > > > > > > > > > > > [luvallstuff](http://luvallstuff.tumblr.com/post/131383472032):
> > > > > > > > > > > > > 
> > > > > > > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131375159539):
> > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > even media that is SUPPOSEDLY&nbsp;“”&nbsp;“”&nbsp;“””””&nbsp;“”&nbsp;“”””&nbsp;“&nbsp;“’ proggressive”””&nbsp;“””””&nbsp;“””” has no fucking clue how to write asian people
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > steven universe? fucking tiger mom stereotype whose shy daughter wants to BREAK FREE!!!! from ((also i get a real weebish vibe from this show which is partially why i couldn’t get into it…. like connie isn’t even japanese and yet she says&nbsp;“itadakimasu” before a meal??? not cute.))
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > how to get away with murder? yah oliver’s a little cinnamon roll but why is he the hacker genius.
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > brooklyn 99? again, hacker genius asian episode (and there was one that had a&nbsp;“filipino bieber” joke like ?? ????? ok??)
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > orange is the new black? this is the show that had an episode titled&nbsp;“ching chong chang” i don’t think i have to explain any further (there’s also numerous articles about its anti asian racism but you get the idea)
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > i’ve explained the issues with mulan and bh6 more times than i can count like i honestly should be compensated for this.
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > i mean it’s really fucking annoying how deep rooted in anti asian racism a lot of media is even the ones tumblr loves to hail as progressive, the pinnacle of DIVERSITY!!!!!!!!!!!!!!! !!! !!!!!!! and people just ignore it. even asian-americans for whom it’s IMPOSSIBLE to even be visible. like we literally cannot find asian characters that don’t have some glaring stereotype attached to them and i’m done with it.
> > > > > > > > > > > > > > 
> > > > > > > > > > > > > > Sense8 even. Sun is a Korean martial artist suffering at the hands of patriarchy. Very stereotypical
> > > > > > > > > > > > > 
> > > > > > > > > > > > > Should I even mention Dong’s role in The Unbreakable Kimmy Schmidt?
> > > > > > > > > > > > 
> > > > > > > > > > > > a lot of people have added comments like this to my post or left me asks like “oh man i didn’t realize” and it’s kind of jarring how obviously racist things to us didn’t occur to others until they read this
> > > > > > > > > > > > 
> > > > > > > > > > > > like this isn’t me being mad (because i definitely don’t recognize a lot of stereotypes from other groups im not a part of) but it’s super telling how prevalent this kind of racism is
> > > > > > > > > > > 
> > > > > > > > > > > i thought oliver was filipino tho
> > > > > > > > > > 
> > > > > > > > > > yes  
> > > > > > > > > >   
> > > > > > > > > > now if you look closely at a world map, on what continent would you find the philippines?
> > > > > > > > > 
> > > > > > > > > wow, mon ami, i just meant its normally considered a part of oceania, which some consider different. but go ahead keep criticizing people for making mistakes because that will FOR SURE get people to listen to your opinions.
> > > > > > > > 
> > > > > > > > [@thisisnotpilipinx](http://tmblr.co/muyXrURuizuGZbpEMcrNodw) if you can take this
> > > > > > > 
> > > > > > > wandamaxifuckoff The philippines aint a part of oceania… Its part of Asia. Its part of southeast asia to be specific. We’re not pacific islander/micronesian/macronesian…   
> > > > > > > -admin Kim Celine
> > > > > > 
> > > > > > [@wandamaxifuckoff](http://tmblr.co/m-rk12PgPXcvIm_5mvMr9Kw) i want u to see this because i want u to know that u are terribly terribly wrong… I’d like to know who u know that considers the philippines as part of oceania because i’d like to correct them too.
> > > > > 
> > > > > Papua New Guinean citizen of Filipino heritage here. The Philippines is Asian. We’ve always considered it Asian. I’ve gotten points off for writing about the Philippines when asked to write about current events in Oceania. All my geography classes in PNG had the Philippines down as an Asian country. I still remember getting side-eye from my PNGean friends for implying the Philippines was a Pacific nation. And if nothing else, I live in the Philippines and here it’s also considered Asian.
> > > > > 
> > > > > I actually never heard about the&nbsp;“it’s a Pacific Island/part of Oceania/Polynesia/etc” argument until a few years ago and it’s still kinda baffling. I mean, Southeast Asia is a thing.
> > > > 
> > > > Thanks for the commentary!  
> > > > -admin Kim Celine
> > > 
> > > as a filipino citizen born and raised and currently living in the philippines, yes, filipinos are asians, specifically south east asians. we are part of a group with other south east asian nations called ASEAN. we share the same ethnic roots as other SE countries, from our skin to our dialects. our population and other neighboring countries consider us as asians. we are asians.
> > 
> > I think it /is/ a diasporic thing tbh. I heard it when I first came to this country (10yrs ago). And yes i agree with your tags, i think that it comes from self hate etc etc  
> > -admin Kim Celine
> 
> i hate getting involved in this discussion but…
> 
> can we not pretend like this is some… ongoing stable reality? today, yes, we are considered asian. but this really actually hasn’t always been true.
> 
> and this isn’t just a ‘diaspora’ thing. one of the things, though, that you can learn in the diaspora is that white ppl have not always considered filipinxs to be ‘aisan’.
> 
> take american policy, for example, as best as i can tell we made the transition from 'malayan’ to 'asian’ sometime in the 1930s. prior to this point in time the world (bc the US occupied us at the time so what they said about us basically was global in impact), considered most of the asian island nations **AND** oceania to be what was known as the 'east indes’. the philippines, particularly, was part of the spanish east indes.
> 
> basically, the malay peninsula and all the pacific islands between it the the US were considered as one geographic zone populated by a distint race white ppl called 'malay’.
> 
> we’ve only been asian for about a hundred years. we were malayan for about a hundred and fifty years before that. and before that we were 'indians’ for a few hundred years. before _that_ we were ourselves and free.
> 
> this isn’t a stable reality. 'pacific islander’ as a distinct thing is fairly new, comparatively. so is filipinxs being asian.
> 
> also… it doesn’t matter if other asians think we are asian or not (some don’t). because _white_ people invented this racial classification system. it only matters what race _they_ think we are. and right now that’s asian.
> 
> we aren’t 'pacific islanders’ bc that term didn’t exist when we were racially grouped in with oceania. we (and pacific islanders) can and could call ourselves 'malayan’ or 'east indian’ if we want, though.
> 
> i think its important to acknowledge this history bc the changing status of our race actually made a _big_ difference for how colonization happened. and how white ppl treated us.

a kind friend pointed out to me that OP uses the language 'anti-Asian’ which i missed bc i only really read the comments about PI vs Asian.  
  
in any case: Black ppl have repeatedly said that 'anti Asian’ appropriates the framework of anti-Blackness. while i know it appears to be a neutral construction, i t really isn’t.   
  
engaging in (and ignoring as i did) this kind of anti-Black appropriation/co-opting is… not really something we ought to be doing.  
  
something to note for the future.

