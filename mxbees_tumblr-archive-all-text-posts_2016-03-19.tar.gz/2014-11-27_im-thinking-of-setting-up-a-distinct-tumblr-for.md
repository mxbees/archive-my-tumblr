---
id: 103724466159
slug: im-thinking-of-setting-up-a-distinct-tumblr-for
date: 2014-11-27 15:08:04 GMT
tags: []
title: 
---
i’m thinking of setting up a distinct tumblr for transcribing image-text-posts related to ferguson and stuff. like. i usually delete all non-original posts at the end of every month and i kind of think it is important to keep this stuff up. also. other people would be able to contribute too…

y/n?

