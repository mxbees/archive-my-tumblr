---
id: 100445384334
slug: yungmeduseld-b-binaohan
date: 2014-10-19 21:58:49 GMT
tags:
- epilepsy warning
title: 
---
[yungmeduseld](http://yungmeduseld.tumblr.com/post/100443293164/b-binaohan-imnotevilimjustwrittenthatway):

> [b-binaohan](http://xd.binaohan.org/post/100442107434/imnotevilimjustwrittenthatway-replied-to-your):
> 
> > [imnotevilimjustwrittenthatway](http://imnotevilimjustwrittenthatway.tumblr.com/) replied to your post: [just having a sudden thought about the…](http://xd.binaohan.org/post/100435577324/disability-politics-and-mind-body-dualism)
> > 
> > > i remember reading a book that was interviews + essays by ppl w/ disabilities who didnt have that cartesian duality and it was super interesting and really helpful to me.
> > 
> > it is suddenly reminding me why i have so many issues with trans humanism or cyborg theories and stuff…
> > 
> > i don’t actually subscribe to a world view where my body is distinct from my mind. i don’t think it is possible to upload our minds to the internet or whatever. i don’t think there is a coherent way to say that our minds can exist independently of our bodies and while i understand why some people find enormous potential in this …
> > 
> > but i’m fucking _tired_ of being told that my body is wrong
> > 
> > that i have to overcome it to exist as a free person.
> > 
> > it my body/mind. and the fact that the world is a hostile place for me, doesn’t make it wrong…
> 
> ![image](https://38.media.tumblr.com/465fb78be92c3481dc2af70f606afca2/tumblr_inline_ndpnt1B4FL1qfzb2v.gif)
> 
> But seriously, you put something into words a thing that has been in the back of my subconscious. Like…. I _like and trust my body (mostly, re: trust, despite the pain)_ but like also… I acknowledge that if you tried to separate my mind and spirit from this body, I would become someone else. It’s a whole new incarnation.

and this is totally the same logic that feeds into the ‘woman trapped in a mans’ body narrative in white trans theory.  
  
and this is, i think, the justification that a lot of parents feel when they murder their disabled children… 'freeing’ the mind trapped in that terrifying body  
  
and i think about all the ways i’ve been taught to hate my body  
  
eyes too dark, skin not white enough, eyes too small, not feminine enough, and so on and on on on on  
  
and i’m like…  
  
i may not have been able to get to a place where i love my body/self… but i’m geting to a place where i don’t hate it.  
  
it’s mine. and fuck anyone who wants to tell me it exists in the wrong way.  
  
it is \_me\_

