---
id: 101131370584
slug: im-trying-to-figure-out-how-to-reply-to-an-ask
date: 2014-10-28 00:42:07 GMT
tags:
- the life of an oridinary bakla
title: 
---
i’m trying to figure out how to reply to an ask…

like i see the person’s point…

but in context, i don’t think i agree.

maybe this is what i’ll write…

