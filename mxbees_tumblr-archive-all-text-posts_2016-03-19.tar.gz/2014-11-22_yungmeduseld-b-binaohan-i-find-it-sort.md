---
id: 103242731089
slug: yungmeduseld-b-binaohan-i-find-it-sort
date: 2014-11-22 01:11:18 GMT
tags: []
title: 
---
[yungmeduseld](http://yungmeduseld.tumblr.com/post/103242526594/b-binaohan-i-find-it-sort-disingenuous-for):

> [b-binaohan](http://xd.binaohan.org/post/103232962779/i-find-it-sort-disingenuous-for-non-black-ppl):
> 
> > I find it…
> > 
> > Sort disingenuous for non Black ppl to ask, at this point
> > 
> > “what can we do about dmr and antiBlackness”
> > 
> > ???
> > 
> > as if this is a real question.
> > 
> > first. we as non Black ppl created this situation. we are the antiBlack context that allowed two nonBlack poc to raise to such prominence in the community
> > 
> > to the extent that they are being asked to stand as authorities over things that they can never and should never be allowed to claim authority over.
> > 
> > we did this. we are the context that allows this to happen.
> > 
> > what can we do?
> > 
> > the question isn’t for us to answer.
> > 
> > Black ppl are already telling us what they need.
> 
> TBH I feel like unless y’all are meeting with them in these places and calling them to be accountable, y’all can fuck off. Like, how do you have meetings about anti/Blackness and have noooo Black people in the room. Like. Bitch whet. I bet they use AAVE.

here is a thing that we (non-Black ppl) can do.

