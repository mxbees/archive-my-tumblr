---
id: 109503819049
slug: ugh-of-course-update-breaks-xkit-replies-im
date: 2015-01-29 18:57:57 GMT
tags:
- the life of an ordinary bakla
title: 
---
ugh. of course update breaks xkit replies.

i’m so glad i stopped using the tumblr interface about… three iterations ago. actually it is probably more.

