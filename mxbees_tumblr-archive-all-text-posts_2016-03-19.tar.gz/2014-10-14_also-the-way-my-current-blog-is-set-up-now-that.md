---
id: 100031386754
slug: also-the-way-my-current-blog-is-set-up-now-that
date: 2014-10-14 23:24:45 GMT
tags:
- the life of an ordinary bakla
title: 
---
also, the way my current blog is set up, now that this one isn’t my primary, i miss out on a lot of comments bc i forget to check my notifications.

which is still a feature, bc it finally broke my obsessive need to check _all_ the time. which was definitely not good for my mental health.

