---
id: 119878572624
slug: chrysalisamidst-copperkeep-b-binaohan-how
date: 2015-05-25 20:53:06 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[chrysalisamidst](http://chrysalisamidst.tumblr.com/post/119875187043):

> [copperkeep](http://copperkeep.tumblr.com/post/119874952366/b-binaohan-how-are-you-translating-this):
> 
> > [b-binaohan](http://xd.binaohan.org/post/119680327974/how-are-you-translating-this-learning-into):
> > 
> > > how are you translating this ‘learning’ into actual, concrete action? what, exactly, are you doing? ( [x](http://twitter.com/b_binaohan/status/602111796544086016))
> > 
> > killing more trans women, tbh
> 
> I see no lies

omg. this is brutal. but soooo true.

