---
id: 129582902389
slug: ok-so-based-on-recent-events-id-like-to-learn
date: 2015-09-21 18:47:53 GMT
tags:
- the life of an ordinary bakla
title: 
---
ok.

so based on recent events, i’d like to learn and figure out a divination method, so i can listen to my ancestors better than i have been.

so far, i think i’m mainly interested in numerology?

but i could maybe do tarot (but i worry how image-based it is bc i really don’t do well with images).

does anyone have any suggestions? by this i mean types of divination and/or resources to learn.

criteria:

1. not appropriative in any way. this basically limits me to white, non-Indigenous practices. since i don’t have access to an elder who can teach me my own cultural ways, i think this is the only way to go, for now.
2. honest to god, one of the things that’s prevented me from really starting to explore anito is how much i can’t stand the cheesy way most white ppl talk about non-christian spirituality. so books and stuff that minimize white cheese and don’t push a specific set of cultural beliefs. 

i’m open to suggestions that fit this criteria.

