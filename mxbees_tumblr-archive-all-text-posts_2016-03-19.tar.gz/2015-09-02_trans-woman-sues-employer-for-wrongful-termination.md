---
id: 128198238266
slug: trans-woman-sues-employer-for-wrongful-termination
date: 2015-09-02 17:49:43 GMT
tags:
- current events
- medical discrimination
- employment discrimination
- transmisogyny
title: trans woman sues employer for wrongful termination
---
> A transgender woman has filed a federal discrimination lawsuit against a Seattle-based blood bank, saying she was fired after changing her donor profile to female to match her reissued birth certificate.
> 
> In the lawsuit filed last week in U.S. District court in Tacoma, Stephanie Binschus alleges Bloodworks Northwest treated her differently than other employees even though she made sure the company was fully aware of her transition.

( [Original Source. Trigger Warnings for employment discrimination](https://web.archive.org/web/20150902120543/http://www.komonews.com/news/local/Puget-Sound-blood-bank-sued-by-transgender-woman-323695191.html))

