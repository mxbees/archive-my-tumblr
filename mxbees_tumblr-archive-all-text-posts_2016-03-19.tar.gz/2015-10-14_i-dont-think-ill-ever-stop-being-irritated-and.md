---
id: 131179010119
slug: i-dont-think-ill-ever-stop-being-irritated-and
date: 2015-10-14 21:41:27 GMT
tags:
- ye olde abuse culture
- op
title: 
---
i don’t think i’ll ever stop being irritated and frustrated by ppl with mental illnesses who think that being mentally ill is a license to abuse.

someone writes “don’t tell ppl that if they leave u you’ll kill urself bc that’s manipulative”

invariably someone replies “sorry for being mentally ill”

i hope u realize that ur more damaging and harmful to mentally ill ppl than those who want to hold us accountable.

ur part of the reason ppl think that ppl with mental illnesses are dangerous.

thanks.

