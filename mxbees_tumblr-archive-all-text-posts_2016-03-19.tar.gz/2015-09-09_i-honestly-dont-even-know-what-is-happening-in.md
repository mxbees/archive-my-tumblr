---
id: 128715480375
slug: i-honestly-dont-even-know-what-is-happening-in
date: 2015-09-09 16:55:08 GMT
tags:
- current events
- new zealand
- wtf
title: I honestly don't even know what is happening in this story...
---
But I’m pretty sure this is a great example of trans\*nationalism in action. I mean… Wtf?

> The President of Agender has resigned after being criticised over comments she made three years ago about a picture of someone cleaning in a kinky maid’s uniform.

That’s it. That’s the story. The president of some advocacy org in New Zealand resigned over _a comment made on a picture of someone else in a maid’s uniform_. A comment. Like. I can’t even.

> The image, posted on her friend’s publicly open Facebook page, is a shot from behind of someone in a maid’s outfit bending over and cleaning:
> 
> Whitehead responded that she should perhaps get such an outfit. The comment was made before she was Agender President.
> 
> She says she feels her credibility and reputation have been tarnished, so she is resigning.

Wat. This is respectability politics dialed up to about 12. On a 10 point scale.

> There has been a divide among members of the organisation about its public image. Recently, Agender has publicly focused on pushing seriously for transgender rights, and has gained traction in the mainstream media this year…However recently there has been friction because some also want it to embrace and support kink and fetish.
> 
> She is blaming a group of cross-dressers in Christchurch as being an “embarrassment” to those trying to advocate for the broader community.

Um…

Anyway.

( [Original Source. Trigger Warnings for idk?](https://web.archive.org/web/20150909105905/http://www.gaynz.com/articles/publish/2/article_17264.php))

