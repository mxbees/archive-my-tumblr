---
id: 131429992916
slug: its-taken-me-quite-a-while-to-sort-out-my-deal
date: 2015-10-18 17:49:35 GMT
tags:
- actually autistic
- able ability
- op
title: 
---
its taken me quite a while to sort out my deal with socializing.

i used to say that i was ‘anti-social’ but this isn’t actually true. Or at least not true in the way that most people think of it. I don’t actually dislike or hate socializing.

i also thought (for the brief moment it took for me to google it) that maybe i had a social anxiety thing. this is also not true. socializing doesn’t give me anxiety.

instead, the root is with autism and the fact that i simply don’t appear to need/seek out/desire/crave social interaction to the same degree that many other people do.

i think it is common knowledge (or at least received folk wisdom) that people are social creatures. its a key element to our overall well-being and happiness. i don’t actually think this is untrue for me.

it is just that i appear to need much less of this than most of the people i know.

the fact that i’m generally unwilling to, for example, go to someone’s house party or whatever is simply because i don’t see the point. not anxious about it. there is just about a million things i’d rather do instead.

all of this is much worse when it comes to ppl i don’t know. like. i like seeing my friends. and am generally willing to go out to see them (and them alone) or for birthdays (because I think birthdays are important and they are about the only holidays i actually celebrate these days).

my issue is (and i’ve done this at parties), is that i’d rather sit by myself and play spider solitaire than talk to people i don’t know. because i very much don’t care, don’t need it, and don’t see the point.

\*shrugs\*

