---
id: 126216595044
slug: hoodooqueer-b-binaohan-fyi-mentally-ill-ppl
date: 2015-08-09 01:29:25 GMT
tags:
- able ability
title: 
---
[hoodooqueer](http://hoodooqueer.tumblr.com/post/126211485674):

> [b-binaohan](http://b-binaohan.tumblr.com/post/126211359084):
> 
> > fyi: mentally ill ppl are going to exist post-capitalism
> > 
> > you know. just like we existed pre-capitalism.
> > 
> > jesus
> 
> I guess pre-colonialism mentally ill PoC didn’t exist??

exactly…   
  
not only that. but like. we did have ways of managing and dealing with it (that didn’t involve killing ppl like a lot of neo-primitivists seem to think)  
  
i mean. taking even something like PTSD. really? no one was ever traumatised before capitalism? or no one was traumatised enough to get PTSD?   
  
no one ever got depressed? like. REALLY?   
  
how in the fuck does this make sense. capitalism isn’t this ahistorical reality that has always been around.

