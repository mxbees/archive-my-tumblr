---
id: 101429295664
slug: raise-ur-hand-if-u-actually-know-what-the-fuck
date: 2014-10-31 17:14:15 GMT
tags:
- race to the bottom
- mayo is as mayo does
title: 
---
raise ur hand if u actually know what the fuck an

‘aesthetic’ reason is for not clearly marking urself as white?

