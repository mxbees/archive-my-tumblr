---
id: 128048392190
slug: an-interview-with-dominique-jackson-author-of
date: 2015-08-31 19:38:38 GMT
tags:
- current events
- twoc thriving
- dominique jackson
title: An Interview with Dominique Jackson - Author of _The Transsexual From Tobago_
---
This is an interview with Dominique Jackson, a trans woman from Trinidad and Tobago. She recently published a memoir title _The Transsexual From Tobago_ ( [find it on amazon](http://www.amazon.com/Transsexual-From-Tobago-Dominique-Jackson/dp/1497337046)). She also recently appeared in the documentary _My Truth, My Story_ produced by The Caribbean Equality Project.

There are a lot of great answers here but perhaps my favourite:

> **What shall define your legacy?**
> 
> My resilience, perseverance and strength.

( [Original Source. Trigger Warnings for child sexual abuse, deadname, transmisogyny,](http://www.amazon.com/Transsexual-From-Tobago-Dominique-Jackson/dp/1497337046))

