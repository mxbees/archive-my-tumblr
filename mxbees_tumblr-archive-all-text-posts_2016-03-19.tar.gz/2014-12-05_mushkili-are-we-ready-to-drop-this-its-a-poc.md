---
id: 104436073729
slug: mushkili-are-we-ready-to-drop-this-its-a-poc
date: 2014-12-05 21:49:11 GMT
tags:
- antiblackness is real
- accountability post
title: 
---
[mushkili](http://mushkili.tumblr.com/post/104392397074/are-we-ready-to-drop-this-its-a-poc-issue):

> are we ready to drop this “it’s a poc issue” bullshit now that an east asian cop murdered a Black man? what other evidence do you need that we are complicit and participant in antiblackness? we are part of the problem so wake the fuck up fellow nonblack asians. stop sitting in the sidelines and start dismantling our own system.

adding to this….

non-Black asians should also be talking about daniel hortzclaw

because he is also Asian cop

who is a serial rapist who targeted Black women

we are also part of the system that terrorizes and murders Black ppl

