---
id: 100160397429
slug: oh-im-also-not-going-to-be-piping-my-tweets-into
date: 2014-10-16 14:27:07 GMT
tags:
- the life of an ordinary bakla
title: 
---
oh. i’m also not going to be piping my tweets into tumblr anymore. at least for now….

