---
id: 100442400879
slug: so-fucking-over-ppl-telling-me-that-my-mindbody
date: 2014-10-19 21:22:33 GMT
tags:
- able ability
- the life of an ordinary bakla
title: 
---
so fucking over ppl telling me that my mind/body is wrong. i hate it bc it took me such a long fucking time to obtain a certain level of peace with it. but no… always something wrong with it. never good enough. need to change so that i can live and succeeed or whatever.

and, honestly, the weight i’ve gained in the past two years is just another reason for ppl to be telling me that my body is wrong/bad.

