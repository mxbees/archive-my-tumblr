---
id: 100622833129
slug: one-thing-ive-definitely-learned-is-that
date: 2014-10-21 23:41:50 GMT
tags:
- able ability
- race to the bottom
title: 
---
one thing i’ve definitely learned….

is that there is always that certain class of ppl

willing to bust out their disabilities

as an excuse for shitty behaviour.

except, that, um, you know that no one ever actually needs this?

y r apologies so hard????

1. i’m sorry 2. this is how i fucked up 3. i’ll try not to do it again

three steps.

no one needs to know that maybe ur meds are messed up. or that u have autism.

u only look extra fucking silly

when literally _everyone else_ in the conversation

has a disability of some kind too.

and (by magic i’m sure)

none of us are fucking up.

