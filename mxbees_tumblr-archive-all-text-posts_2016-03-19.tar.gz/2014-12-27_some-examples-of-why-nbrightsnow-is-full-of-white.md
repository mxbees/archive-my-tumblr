---
id: 106314158419
slug: some-examples-of-why-nbrightsnow-is-full-of-white
date: 2014-12-27 12:35:54 GMT
tags:
- nbrightsnow
- teh trans community
title: 'some examples of why #nbrightsnow is full of white supremacist and transmisogynist
  garbage'
---
i had the misfortune of getting wind of the #nbrightsnow hashtag on twitter… and predictably, it is full of white afabs. boring. blah. [here is a link to all of the tweets i captured for this post collected in one place](http://biyuti.com/r)

![](https://38.media.tumblr.com/5741448d799c2e57b477432554ab8b3a/tumblr_inline_nh8qagEhjq1rdzs46.png)

first up, we outright colonialism. or maybe this is neocolonialism? idk. what do u call it when a white person whose ancestors did their level best to entirely eradicate indigenous genders and is now trying to push a white hegemonic discourse of gender on us?

ok. not neocolonialism since this is actually just continuing the tradition. lol. fuck u.

![](https://33.media.tumblr.com/f8a6c09f16236169a41056c2c6e6e5b8/tumblr_inline_nh8qdgKxd21rdzs46.png)

sounds like someone doesn’t actually know [what binarism is and isn’t](http://biyuti.com/p). it also sounds like someone doesn’t understand how oppression works. but good job! ur a shitty white supremacist jerkface.

![](https://38.media.tumblr.com/afdf3785a5747584de7f218eb4bc57d9/tumblr_inline_nh8qg6gmms1rdzs46.png)

huh. so. wait. u experience the same kind of thing that a lot of trans ppl experience? maybe u don’t experience transphobia bc it doesn’t actually exist. but this is also a good straw man.

the reality is, sure, u might have some of the experiences. but if u think it compares to what ~binary~ twoc have to deal with? ur wrong and ur a transmisogynist.

![](https://38.media.tumblr.com/b6aa2c05c632ff530d3ed33e72636f74/tumblr_inline_nh8qjgtqLp1rdzs46.png)

but _is_ easier for them. look. i’m not trying to play oppression olympics, but it is irrefutable _fact_ that twoc and poc who experience transmisogyny have it worst. asking u to recognize this isn’t throwing u under the bus…

but having an entire hashtag revolving around transmisogyny and erasure actually is throwing _us_ under the bus.

![](https://33.media.tumblr.com/f3d21e504806002d5a588d417ae011c8/tumblr_inline_nh8qmbqJAG1rdzs46.png)

i’m guessing by ‘matter of life and death’ u mean suicide? or something similar? bc the nonbinary ppl who’re dying bc of transmisogynist violence are……. people of colour (mostly Black and/or Latin@ poc). the same ppl who your race likes to flatten out into just being 'binary’ twoc… even as that conceptual framework is imperialistic in its own right.

also? don’t think i didn’t see how u mention 'binary ppl’ having basic rights. u realize this includes binary trans ppl right? and since it does, ur outright lying here. and ur an asshole.

![](https://33.media.tumblr.com/db5d5bcf32756b3b429ed3031ae58156/tumblr_inline_nh8qqyuyVv1rdzs46.png)

more lies. the only person (just one) who i saw calling the hashtag transmisogynist was a nonbinary Black person. so. way to be fucking disingenous and anti-Black.

talk about erasure too…

![](https://38.media.tumblr.com/f09d9af68a95358ab63f400f127d4839/tumblr_inline_nh8qssWs2i1rdzs46.png)

the other white nb problem: appropriation. (and in this case, anti-Blackness)

![](https://38.media.tumblr.com/491fbc54bebaa5b33834fcd2db250708/tumblr_inline_nh8qtgXAGO1rdzs46.png)

are u one of the ppl with 'culture-specific’ genders? let me tell u as a person with an indigenous gender (oh hey, maybe try using the terms and discourse we uses for ourselves?), that while this is true…

i don’t need white ppl trying to speak for me. doing so is also an act of erasure.

i can talk for myself. and believe me, i’m well aware of how appropriated my life and identity and experiences are by white nb ppl

![](https://33.media.tumblr.com/8f20be00bb0e38b5893ffc9fac5b19f1/tumblr_inline_nh8qw6Wc551rdzs46.png)

here’s a lovely bit of anti-Blackness….

first thing u need to ask yourself: why the fuck does Laverne Cox need to speak for you?

the fact that she speaks so strongly about the experiences of Black trans women (and often, trans ppl in genreal) is a fucking gift and its revolutionary.

who are u to be making demands like this? why do u think ur entitled to her attention?

go fuck ur anti-Black misogynoir ass in a corner

