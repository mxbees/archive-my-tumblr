---
id: 100823696444
slug: also-had-a-conversation-last-weekend-about-the
date: 2014-10-24 12:00:41 GMT
tags:
- race to the bottom
- decolonization nao
title: 
---
also

had a conversation last weekend about the white [saviour] industrial complex

and one of the things I said, that stuck with me was that if the problem is&nbsp;

white people being involved in your shit

the solution will never be

white people being involved in your shit

