---
id: 109094806264
slug: also-comments-on-corporal-punishment-arent-an
date: 2015-01-25 11:46:30 GMT
tags:
- ye olde abuse culture
- child abuse
- corporal punishment
title: 
---
also…

comments on corporal punishment aren’t an invitation for a bunch of ppl to tell me that

‘i was spanked and i think it is ok!’

like. good for u. yay.

note how i’m not even saying it is always bad/abusive.

again. there are cultural differences here that matter.

but me saying

'i don’t think it is the most effective method of discipline’

is not me passing judgement on you and your experiences

(or, for any parents that read this who spank, i’m not judging how you raise your kids. i don’t know you and i don’t know your situation)

i will say it is interesting that i have to put this post here bc whenever ppl see a discussion about spanking, some ppl get really invested in asserting that they have every right and reason to hit kids.

and i’m not interested in having that discussion with anyone.

