---
id: 125720756224
slug: hoodooqueer-crazo3077-bofa-gender
date: 2015-08-03 01:53:31 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[hoodooqueer](http://hoodooqueer.tumblr.com/post/125716618079):

> [crazo3077](http://crazo3077.tumblr.com/post/125604808081):
> 
> > [bofa-gender](http://bofa-gender.tumblr.com/post/125601682431):
> > 
> > > [queerdybbuk](http://queerdybbuk.tumblr.com/post/121504967652):
> > > 
> > > > “Trans men are men”  
> > > > Trans men- okay but this is the dumbest fucking opinion on tumblr
> > > 
> > > Trans man: I might be a man, but I’m also assigned female at birth, giving me unique experiences from cis men. One thing is that I’ve been viewed as female most of my life. Being viewed as female means I’ve been treated as female. One treatment females receive is misogyny. Please don’t tell me what my experiences are.
> > > 
> > > Queer theorists: LOL LOOK AT THIS TRANS BRO MISGENDERING HIMSELF.
> > 
> > I will always say that trans men often understand the treatment of women better than trans women, and to disregard a trans man’s input is only going to hurt your perspective.
> 
> I want to know why Black Jesus let this post be posted on God’s green earth.

omg. but anyway.  
  
what’s really interesting about all of this is how its gone mainstream and how i’ve read this exact same shit on the advocates ‘boys do cry’ series.  
  
like.   
  
'trans men understand women better than trans women’  
  
literally eject yourself into space, pls

