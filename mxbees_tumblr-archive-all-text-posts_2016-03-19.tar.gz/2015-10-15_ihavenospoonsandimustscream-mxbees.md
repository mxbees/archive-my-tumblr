---
id: 131187335624
slug: ihavenospoonsandimustscream-mxbees
date: 2015-10-15 00:15:38 GMT
tags:
- discussing discourse
- op
- idk
- my brain is kind of spinning now
- so i'm not sure how much sense i'm making
title: 
---
[ihavenospoonsandimustscream](http://ihavenospoonsandimustscream.tumblr.com/post/131183964150):

> [mxbees](http://mxbees.tumblr.com/post/131183772224):
> 
> > [ihavenospoonsandimustscream](http://ihavenospoonsandimustscream.tumblr.com/post/131183283625):
> > 
> > > [mxbees](http://mxbees.tumblr.com/post/131183098374):
> > > 
> > > > [mxbees](http://mxbees.tumblr.com/post/131179010119):
> > > > 
> > > > > i don’t think i’ll ever stop being irritated and frustrated by ppl with mental illnesses who think that being mentally ill is a license to abuse.
> > > > > 
> > > > > someone writes “don’t tell ppl that if they leave u you’ll kill urself bc that’s manipulative”
> > > > > 
> > > > > invariably someone replies “sorry for being mentally ill”
> > > > > 
> > > > > i hope u realize that ur more damaging and harmful to mentally ill ppl than those who want to hold us accountable.
> > > > > 
> > > > > ur part of the reason ppl think that ppl with mental illnesses are dangerous.
> > > > > 
> > > > > thanks.
> > > > 
> > > > but really.
> > > > 
> > > > these ppl basically confirm the stigma that we are all just potentially harmful abusers who’ll drag our non-mentally ill loved ones down into our endless pits of despair and pain and suffering.
> > > > 
> > > > who the fuck is going to want to even try to have a relationship with us if their general expectation is that they might be told
> > > > 
> > > > ‘if u leave me i’ll kill myself’
> > > > 
> > > > **I** wouldn’t want to date a mentally ill person if i thought this would be something that would happen.
> > > 
> > > Just adding this “for fun,” I’ve had this scenario happen to me. The whole “U can’t leave me b/c I’ll commit suicide and if you do ur ableist.”
> > > 
> > > The best part is that I also have a mental illness and said person threatened to leave when **_I_** attempted suicide.
> > > 
> > > lol.
> > 
> > now i kind of feel like maybe there is a real discussion about people who absolutely use their mental illness as both an abusive weapon and a way to dodge accountability.
> > 
> > bc the sort of thing you describe above is something i’ve heard from several ppl, esp. those who date people we might call ‘activists’ or whatever, you know what i mean.
> > 
> > not just ableism either. i’ve seen ppl have anything from racism to fatphobia used as a way to coerce them into having sex or being in a relationship (ie, if u don’t fuck me, it must be bc ur a racist/fatphobic/ableist/whatever).
> > 
> > bc in a lot of these communities it really does seem like a lot of ppl using fucking as a way to demonstrate their ideological purity. and it happens from the other end, ppl fucking ppl just so that they can say ‘i’m not fatphobic bc i fucked a fat person’ (i see this happen to twoc all the time).
> 
> I think this kind of conversation needs to go on in every marginalized group, tbh. Using social justice/radical activist lingo in order to infiltrate/gain people’s trust as well as later discredit people when said abuser is ousted/outed as an abusive person is actually a pretty common abuser tactic I’ve seen a lot, and not just in romantic settings.

trueeee.

i guess i want to focus on sex/desire/romance atm bc the context i usually see this come up is in the cis lesbians vs. trans lesbians. and while the radfem side is… obviously incorrect, the basic assertion, though, that there are people who use ~politics~ as a method of sexual coercion is actually something that i see play out in a lot of other contexts.

and while no one listens to the radfems in this context bc they’re being transmisogynist shitheads… i guess i suddenly wanted to think about the actual economies of desire in left/activist/radical communities.

i’m also talking about when i hear (and i’ve heard this on many different ocassions) that ppl gauge their romantic/sexual partners based on how ‘good’ their politics are… (one notable person i dated a while back said this frequently about me)

like. idk. this sexualization of trying your best to treat ppl like human beings is…

bc it isn’t even just individual people (although it is a lot of the time) but the general notion that fucking is praxis (yes. this is the concept i want). bc while all of us totally have internalized a lot of fucked up and oppressive stuff about desirability… there’s this expectation that you 'prove’ that you’ve done this work by fucking certain kinds of people (you know the 'undesirable’ ones, the ones who get to be your praxis fuck).

now that i think about this, this is also related to how a lot of discussions about racist sexual preferences happen. bc while the prevelance of writing 'no asians’ on white cisgay hookup profiles online was incredibly damaging for me…

i honestly think that one of the reasons why these issues get so contentious so quickly is that… there truly is this pervasive idea that you can only demonstrate how you’ve 'worked through’ whatever internalized garbage you have by fucking ppl. that unless you can point to a past history of fucking just about anybody, that ur being oppressive or whatever.

fucking as praxis.

