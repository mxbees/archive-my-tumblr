---
id: 100857944879
slug: like-really-my-feelings-and-attitude-towards
date: 2014-10-24 21:43:42 GMT
tags:
- the life of an ordinary bakla
- that light skinned privilege
title: 
---
like…

really. my feelings and attitude towards iaopoc spaces

as a light skin mestisa

changes

_all the time_

bc i just don’t know.

esp. since yes. some do read me as white. and those are the people i care about.

as nice as it is to hear from friends and ppl i trust

that they don’t see me this way

(like, yeah, not that many ppl have seen how i look)

and it is like hugely satisfying that i don’t look like a white person to them

this just means that

(thank the ancestors)

they aren’t the ones i might hurt by existing in certain kinds of spaces

fuck. i even try to do a lot of my processing outside of tumblr and just in my head

bc sometimes i feel like posts like this might come off as me wanting friends to reassure me that

‘no, your one of the good ones!’

which is not at all what i want.

but after recent experiences with some white coding ppl

i’m starting to think that i’m also doing _them_ a disservice by not

publicly talking about how to not act like a shitty entitled white person

and how to centre darker skinned iaopoc in how we do things.

bc this shit actually needs to be discussed.

and a lot less mixed-with-white tears that i see

