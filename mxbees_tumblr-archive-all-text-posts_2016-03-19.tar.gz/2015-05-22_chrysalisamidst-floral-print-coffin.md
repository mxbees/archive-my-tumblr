---
id: 119595044374
slug: chrysalisamidst-floral-print-coffin
date: 2015-05-22 11:31:34 GMT
tags:
- tech support
title: 
---
[chrysalisamidst](http://chrysalisamidst.tumblr.com/post/119581332883):

> [floral-print-coffin](http://floral-print-coffin.tumblr.com/post/119579770611/floral-print-coffin-so-im-pretty-torn-between):
> 
> > [floral-print-coffin](http://floral-print-coffin.tumblr.com/post/119579386456/so-im-pretty-torn-between-getting-a-computer-and):
> > 
> > > So I’m pretty torn between getting a computer and getting an iphone. I’d love to have mobile music, and my phone now sucks, but at the same time I do need a new laptop soon so the hit I’m taking will be pretty much equal except financially, which isn’t my concern. So idk what to do
> > 
> > suggestions are welcome on the matter, please talk me through this?
> 
> Computer?

it depends on a few things…

how do you usually access the internet? like via wifi or mobile data? what do you have at home? work? school?

like, if you have pretty much constant access to wifi or ethernet (wired internet), i’d go with a laptop. you can do so much more with a laptop than you can with an iphone (microsoft office, photoshop, etc). like, if you really need mobile music, you can get an ipod shuffle or something, they are like $50 or whatever.

if you mainly access the internet via mobile data, then the iphone is the obvious choice.

this is one way to split it.

i know for me, i’d always choose the laptop because of how much more useful they are, overall. also… far less delicate since you don’t tend to actually carry them everywhere.

