---
id: 110632421174
slug: life-beyond-being-broken-i-feel-like-this-post
date: 2015-02-10 14:21:22 GMT
tags:
- ye olde abuse culture
title: 
---
life beyond being broken…

i feel like this post is necessary.

a lot of us who were abused, traumatized, however you wantto phrase this

feel like we are broken. permanently damaged. beyond repair.

i feel this way. i feel like…

i will always be the ruin of the person i could’ve been if not for neglectful and abusive parents

like i’m a memorial of the happy, lovely child i remember being for all of five seconds

but one thing i’ve also learned is that there is life beyond being broken

that…

there can still be joy, happiness, and many good things

even if u are broken

the thing is

the _thing_ is

is that these things won’t look like anything u see in media

bc no one tells the stories of broken ppl and the ways

we can still find

joy

and sometimes

happiness

