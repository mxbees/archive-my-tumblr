---
id: 128723954553
slug: unemployment-for-transgenders-in-tamil-nadu
date: 2015-09-09 19:38:31 GMT
tags:
- current events
- india
- unemployment
title: Unemployment for Transgenders in Tamil Nadu
---
> There are close to 35,000 trangenders in Tamil Nadu, but not even a fraction of them can claim to have a regular stream of employment from a recognised organisation or a proper establishment. Though employment and lack of societal support are issues that have been plaguing the trangender community for a long time now, they are ready with solutions.
> 
> “Besides the lack of reservation in state education and employment, there is also the ever present problem of not being able to even find a home. No landlord wants to give a home for rent to a transgender,” said Dhanam, a transgender activist who runs the NGO Snegidhi.

( [Original Source. Trigger Warnings for employment discrimination, housing discrimination](https://web.archive.org/web/20150909111618/http://www.newindianexpress.com/cities/chennai/Transgenders-Still-Struggling-to-Find-Employment-Housing/2015/09/09/article3017257.ece))

