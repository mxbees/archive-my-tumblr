---
id: 119879130689
slug: thisismyblogyo-b-binaohan-fucking-destroy
date: 2015-05-25 21:00:14 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[thisismyblogyo](http://thisismyblogyo.tumblr.com/post/119685007544/b-binaohan-fucking-destroy-the-wpath-its):

> [b-binaohan](http://xd.binaohan.org/post/119680329224/fucking-destroy-the-wpath-its-standards-and-the):
> 
> > fucking destroy the WPATH, its standards, and the ppl who advocate for it. ( [x](http://twitter.com/b_binaohan/status/602112960920690688))
> 
> Uhhmm, okay. Why??

bc some organization started but a shitty transmisogynist cis white man and propped up and run by the same

shouldn’t set the global standards for trans healthcare.

no one should set ‘global’ standards for trans healthcare.

bc trans women should be in charge of our own health and care

bc medical gatekeepers are a major part of the violence that trans women experience

bc fuck medical gatekeepers.

that’s why.

