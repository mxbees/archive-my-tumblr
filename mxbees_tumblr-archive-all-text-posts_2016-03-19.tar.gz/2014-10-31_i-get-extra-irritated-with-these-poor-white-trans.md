---
id: 101452293944
slug: i-get-extra-irritated-with-these-poor-white-trans
date: 2014-10-31 23:34:32 GMT
tags:
- mayo is as mayo does
- teh trans community
title: 
---
i get extra irritated with these poor white trans women on tumblr

u assholes are fucking awful

bc u totally act like that one extra oppression

~poverty~

somehow gives u the righ to talk over iaopoc about our shit

or gives u the right to express ur shitty fucking opinions about it

and there is totally a handful of this shitty white trans women

who take up a lot of discursive space

bc like all other vats of mayo

they feel entitled to all the space and to say whatever they want

in case u forgot… fuck u.

