---
id: 102641104779
slug: part-of-my-problem-these-days-is-that-so-much
date: 2014-11-14 22:35:20 GMT
tags:
- teh trans community
title: 
---
part of my problem (these days)

is that so much of the trans discourse i see just bores the heck out of me

so too with a lot of queer stuff i see

half the time when i see something i find troubling

i just roll my eyes and scroll past it

bc i fucking _hate_ repeating myself

but so often it is stuff i’ve already talked about…

just with the shit shuffled off to a different pile

