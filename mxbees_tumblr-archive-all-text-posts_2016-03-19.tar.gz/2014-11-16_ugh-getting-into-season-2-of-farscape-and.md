---
id: 102825066159
slug: ugh-getting-into-season-2-of-farscape-and
date: 2014-11-16 23:44:50 GMT
tags:
- media musings
title: 
---
Ugh

getting into season 2 of farscape

and Crichton is so fucking irritating

like perhaps unbearable

