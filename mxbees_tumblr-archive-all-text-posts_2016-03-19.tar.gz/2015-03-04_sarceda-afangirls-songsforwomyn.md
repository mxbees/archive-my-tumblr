---
id: 112684155304
slug: sarceda-afangirls-songsforwomyn
date: 2015-03-04 09:52:10 GMT
tags:
- not poor of mind
title: 
---
[sarceda](http://sarceda.tumblr.com/post/112682800101):

> [afangirls](http://afangirls.tumblr.com/post/112682199660/songsforwomyn-the-great-trevor-songsforwomyn):
> 
> > [songsforwomyn](http://songsforwomyn.tumblr.com/post/112092235711):
> > 
> > > [the-great-trevor](http://the-great-trevor.tumblr.com/post/112091282484/songsforwomyn-also-why-cant-poor-people-have):
> > > 
> > > > [songsforwomyn](http://songsforwomyn.tumblr.com/post/110981594366):
> > > > 
> > > > > also. why cant poor people have things they like. why do we have to further dehumanize them by telling them that they deserve to starve if they spend money on luxuries
> > > > 
> > > > This is a whole new level of stupid.
> > > 
> > > Ok yeah go yell at someone living below the poverty line and tell them they should die of hunger because they bought their kid a 3ds.
> > 
> > I’m sorry but this is ridiculous. If you barely have enough money to keep a roof over your head and feed and clothe your children, you shouldn’t prioritize a fucking 3ds. So you’d rather let your kids have a video game but no food in their stomachs? Not saying one should have to live in poverty, but come on for fucks sake, use your head!
> 
> how many times do i have to tell you idiots that there is no child out here whose parents opted to buy them games instead of food&nbsp;

what was said above…

but.

as a poor person who literally just bought a 3ds

despite having barely enough money to pay rent, buy food, etc. and lives in extreme poverty

i did a bit of freelance work and crowdsourced games as birthday presents and now i have something that’ll give me _years_ of entertainment and fun.

but tell me, directly, assholes above, that i deserve to starve/lose my home/die just because i bought myself a 3ds.

go ahead. i’ll be waiting.

