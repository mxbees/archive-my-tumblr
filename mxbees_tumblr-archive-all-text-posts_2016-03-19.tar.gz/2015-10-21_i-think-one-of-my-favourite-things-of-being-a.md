---
id: 131590165519
slug: i-think-one-of-my-favourite-things-of-being-a
date: 2015-10-21 01:17:12 GMT
tags:
- teh trans community
- the life of an ordinary bakla
- op
title: 
---
i think one of my favourite things of being a non-cis coding ladyboy is the calculations i end up having to do when i know i have to be out of the apartment for a period of time.

like. today i’m purposefully dehydrating myself so i don’t have to use the washroom as much at work tomorrow (bc there is only one neutral washroom and it is pretty popular).

i was also going to make eggs and hashbrowns and toast for dinner until i remembered that, again, work tomorrow and sometimes eggs make me gassy and washroom access isn’t guaranteed.

i’m having an general IBS flareup atm with constipation and bloody shits. i’m hoping that i keep this up for another few days so i don’t have to urgently use the washroom at work tomorrow.

it really doesn’t help that one of my main panic attack systems is urgently needing to use the washroom. need to make sure i remember which tran stations on my way to work have public restrooms.

all super fun, no?

