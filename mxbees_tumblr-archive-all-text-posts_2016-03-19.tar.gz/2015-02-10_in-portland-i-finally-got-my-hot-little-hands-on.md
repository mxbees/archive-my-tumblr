---
id: 110591236879
slug: in-portland-i-finally-got-my-hot-little-hands-on
date: 2015-02-10 01:47:09 GMT
tags: []
title: 
---
in portland, i finally got my hot little hands on a used gameboy and i found out that i’ve been gifted some games…

thank you all so much.

this means a lot to me. especially as i feel super fucing crazy and delirious rn from insomnia

ur all the best

