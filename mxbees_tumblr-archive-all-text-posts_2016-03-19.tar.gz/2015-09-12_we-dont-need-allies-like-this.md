---
id: 128926845578
slug: we-dont-need-allies-like-this
date: 2015-09-12 16:54:59 GMT
tags:
- current events
- transmisogyny
- racialized transmisogyny
title: we don't need allies like this
---
Honestly… this article tries _so hard_ that I almost feel bad for it and the writer… but not bad enough to point out how much bullshit this is.

So it is about how the ’T’ is forgotten in LGBT. Okay. Great.

You click to read and immediately see…. three white people.

Beyond assuming a cis audience for this piece… after the white ppeople I stumble on this assertion:

> Can you name a transgender celebrity in the media who gets as much attention as the ones that I mentioned? Honestly, I could name two off the top of my head. Laverne Cox and Caitlyn Jenner. I could cheat and use Ruby Rose but she classes herself as genderfluid, so it doesn’t feel fair.

Um. Genderfluid is trans? Wat? How are you going to write an article about erasure while actively doing it? Bleh.

> Amanda Lepore. Chaz Bono. Alexis Arquette. Isis King. Janet Mock. All of these names are hugely successful in their own right, for years and years. So how come we’ve never heard of them? Why are these extremely talented people not getting the same recognition and reverence that their gay counterparts get?

This of course is a valid point. But then…

> So let’s change gears for a second. Does the name Lucy Meadows mean anything to you? How about Leelah Alcorn? Or perhaps Jennifer Gable?

Well. Given that I’m an Actual Trans Person™ and I like to stay informed, I actually know who all of these people are without having to google. But since I’m clearly not the expected audience, perhaps I can forgive this…

> The fact is, when it comes to the LGBT movements, the ‘trans’ part is often the one that gets left behind.

And… that’s it. The writer talks about suicide, which is a serious and important issue within the community, to be sure, but doesn’t breath a single word about the violence that impacts trans women of colour globally?

Really. I just… Next time? Don’t bother with this kind of ally-article. It doesn’t help and no one needs it.

( [Original Source. Trigger Warnings for erasure, mayo](https://web.archive.org/web/20150912131132/http://culturedvultures.com/t-lgbt-one-keeps-getting-left-behind/))

