---
id: 128727275718
slug: survey-reports-that-denying-trans-people-health
date: 2015-09-09 20:33:25 GMT
tags:
- current events
- usa
- healthcare
title: Survey reports that denying trans people health care is bad...
---
For the bottom line, lol. People should know by now that I hate economic arguments like this. So what if providing trans people healthcare cost more than not providing it? Does this mean we wouldn’t have any right to ask for it? Or any rational reason why we should get it?

> As the Obama administration proposes new rules that would prevent health care providers from discriminating against transgender patients, a national survey finds that when care is denied, there are important costs for both insurers and the public.
> 
> As a result of being denied coverage for transition-related care, preliminary results indicated that 35 percent of respondents reported needing psychotherapy, 23 percent became unemployed, 15 percent attempted suicide, and 15 percent needed public assistance programs.
> 
> The report also found that 37 percent of respondents denied care turned to drugs and/or alcohol; 36 percent developed other physical symptoms.

Look. I believe everyone should have free access to healthcare. All healthcare.

Remember… using the bottom line to advocate for something leads to nasty consequences. Money is not and should never be what determines (or even factors into) whether or not people receive healthcare.

( [Original Source. Trigger Warnings for healthcare discrimination](https://web.archive.org/web/20150909111858/http://www.prnewswire.com/news-releases/as-affordable-care-act-extends-support-for-transgender-surgery-survey-finds-denying-care-has-costs-for-insurers-public-300139492.html))

