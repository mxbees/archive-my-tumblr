---
id: 131368123334
slug: it-is-official-i-cannot-spend-lots-of-time-around
date: 2015-10-17 19:55:06 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
it is official: i cannot spend lots of time around many people

notice that it isn’t ‘i don’t like to’ (which was somewhat true before). but _can’t_, **cannot**.

a combination of sensory stuff plus my allergy to fragrances basically means that i have maybe a few hours for that sort of thing until i have to leave.

my head is spinning and i’m dizzy and nauseaous.

i need lots of quiet time away from the nice smelling ppl.

but i had lunch with bad-dominicana and that’s pretty much the highlight of my year, tbh.

