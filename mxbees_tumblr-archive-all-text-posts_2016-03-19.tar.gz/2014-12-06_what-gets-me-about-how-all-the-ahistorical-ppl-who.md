---
id: 104450609734
slug: what-gets-me-about-how-all-the-ahistorical-ppl-who
date: 2014-12-06 01:12:30 GMT
tags:
- race to the bottom
title: 
---
what gets me about how all the ahistorical ppl who talk about race and whatever

is how they seem to think that race is this mutable thing that….

idk

just happened by accident?

while it did happen over hundreds of years thinking that the ‘slow’ consolidation of power equals something that was unplanned or something that happened by chance

that just a magical accident that the boundaries of Europe was drawn to exclude brown ppl

yeah…

