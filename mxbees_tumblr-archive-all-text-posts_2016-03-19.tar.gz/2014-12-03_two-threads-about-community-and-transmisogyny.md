---
id: 104279611974
slug: two-threads-about-community-and-transmisogyny
date: 2014-12-03 23:28:57 GMT
tags:
- binaohan does twitter
- lunaconagua
title: two threads about community and transmisogyny
---
these are collected tweets from earlier, as for the request of luna

[The first is about choosing community and allies and transmisogyny](https://twitter.com/b_binaohan/timelines/540282008426266624)

[the second is a kind of discussion with @blackfoxx about the numbers of global deaths and how Brazil has the most murders for Black and/or Latina trans women](https://twitter.com/b_binaohan/timelines/540281527905841153)

