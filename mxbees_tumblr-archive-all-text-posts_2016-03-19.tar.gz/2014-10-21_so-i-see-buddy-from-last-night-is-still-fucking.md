---
id: 100617225959
slug: so-i-see-buddy-from-last-night-is-still-fucking
date: 2014-10-21 22:24:30 GMT
tags:
- race to the bottom
- mixed with white feefees
title: 
---
so i see buddy from last night is still fucking.

i woke up with an ask and an apology

but i see they are going around accusing a poor Black autistic person of

~ableism~ ~classism~ and whatever ism.

but i also just went to check their blog…

and i think they deleted their previous reblogs of my post

but still has something up saying that there somehting

~problematic~

with my original post

looK:

i couldn’t give a fuck what u think is problematic about my post

there are literally racial hierarchy diagrams

from my ppl and of the spanish empire in general

and spain had a _lot_ of colonies

mixed-with-white ppl were privileged at every turn

yes. some of this mixing is a result of trauma and violence.

so what?

u think that not-mixed-with-white poc didn’t have this problem?

gtfo.

