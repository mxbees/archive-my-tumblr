---
id: 128568325744
slug: cops-in-nyc-continue-to-be-oppressive-assholes
date: 2015-09-07 16:55:09 GMT
tags:
- current events
- police violence
- transmisogynoir
title: Cops in NYC continue to be oppressive assholes towards twoc
---
> When the patrol guide reforms were issued, advocates for transgender people lauded the changes as groundbreaking, if overdue. Officers now were required, among other provisions, to refer to people by their preferred names and gender pronouns, to allow people to be searched by an officer of their requested gender, and to refrain from “discourteous or disrespectful remarks” regarding sexual orientation or gender identity.
> 
> But in interviews with more than 20 transgender and gender nonconforming New Yorkers who have been arrested or had other contact with the police, as well as activists and lawyers representing them, they charge that three years since the regulations were adopted, police officers regularly flout them. Even as transgender visibility surges in the news media and in popular culture, and government agencies develop more sensitive policies, many transgender people continue to report that they are mocked in the most degrading terms by officers, searched roughly and inappropriately and placed in holding cells that do not correspond with their gender identity, all violations of the reforms enacted to address those very indignities.

( [Original Source. Trigger Warnings for descriptions of police violence against trans women of colour, Black trans women specifically](https://archive.is/YtEBe))

