---
id: 109092172469
slug: i-know-there-are-some-cultural-variations-and
date: 2015-01-25 10:42:34 GMT
tags:
- ye olde abuse culture
title: 
---
i know there are some cultural variations and stuff…

but i do have to say that i’m firmly in the ‘no corporal punishment’ camp.

even when/if not abusive, i don’t think hitting kids communicates the right message re: discipline

