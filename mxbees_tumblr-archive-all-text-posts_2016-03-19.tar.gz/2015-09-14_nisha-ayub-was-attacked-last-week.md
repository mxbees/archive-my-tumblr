---
id: 129088211911
slug: nisha-ayub-was-attacked-last-week
date: 2015-09-14 18:44:17 GMT
tags:
- current events
- malaysia
- transmisogyny
- violence
- hate crimes
title: Nisha Ayub was attacked last week
---
> The attack on award-winning transgender activist Nisha Ayub last week, was a reminder of dangers faced by the LGBT community in Malaysia, human rights group Suaram said.
> 
> Nisha was assaulted by two men unknown to her on her way to work last Thursday, sustaining injuries to her ankle and leg.
> 
> In a Facebook posting, Nisha (photo) said the attack on Thursday was the first she had faced.
> 
> She said the attackers fled after her mother, who saw it through a window at their home started screaming.
> 
> “I ran to the left and shouted for help. Everyone came. A Malay auntie came and hugged me, bringing me to the lift. When I reached my floor, I fainted.
> 
> "Thank God all the neighbours came and helped me. Another auntie hugged me and brought me to their house,” she said.
> 
> “All I can say is time will heal me…You can put me in jail, you can hurt me, you can even kill me but it will never take away my identity as a transgender woman.
> 
> "My work as an advocated will never stop until my last breath,” she wrote in a posting today.

( [Original Source. Trigger Warnings for transmisogyny, violence, hate crimes](http://syx.pw/1KNnS48))

