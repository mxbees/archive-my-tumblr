---
id: 100776603899
slug: ill-never-be-over-some-14-white-girl-tring-to
date: 2014-10-23 21:29:31 GMT
tags:
- discussing discourse
title: 
---
i’ll never be over

some 14 white girl

tring to act like she _knows_ about Stonewall

‘trans-medicalists’

go home.

