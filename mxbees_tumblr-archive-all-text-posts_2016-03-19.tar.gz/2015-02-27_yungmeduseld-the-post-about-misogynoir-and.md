---
id: 112227695184
slug: yungmeduseld-the-post-about-misogynoir-and
date: 2015-02-27 15:37:24 GMT
tags:
- transmisogyny is fun for the whole family
- misogynoir
title: 
---
[yungmeduseld](http://tmblr.co/mATJRYAZfhGQ-9IOrhdBB-Q)

The post about misogynoir and transmisogyny would be about the similarities and differences.

Like… I recently saw someone say that the construction of Black women as unwomen was transmisogyny and I was like….

O.o

Bc no. But there are parallels between how misogynoir and transmisogyny are expressed and the results, but their source is different.

AntiBlackness cannot be removed or forgotten from the specificity of misogynoir.

Just as which bodies transmisogyny targets cannot be removed from how it works.

And the two of these things working together is why Black trans women are so violently targeted by this world.

I guess this is the short form of the post since I’m on my phone. But yeah. Just. Seeing ppl erase misogynoir and misappropriate transmisogyny and thereby erase Black trans women from the picture was just a big ‘no’.

I think the best blogger who talks about this in non theoretical ways is Monica Roberts, esp when she talks about the Williams sisters.

