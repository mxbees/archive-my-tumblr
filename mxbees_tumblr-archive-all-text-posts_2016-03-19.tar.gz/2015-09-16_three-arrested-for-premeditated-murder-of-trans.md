---
id: 129222421145
slug: three-arrested-for-premeditated-murder-of-trans
date: 2015-09-16 16:55:09 GMT
tags:
- current events
- transmisogyny
- violence
- tdor
title: Three arrested for premeditated murder of Trans Woman
---
Selvi was killed in North Cikarang by four men who planned it out in advance. Three men have been caught, and the fourth is still at large.

( [Original Source. Trigger Warnings for GRAPHIC DETAILS OF VIOLENCE](http://syx.pw/1UUA6qU))

