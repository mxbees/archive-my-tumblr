---
id: 102917755199
slug: why-does-this-discredit-feminism-and-not
date: 2014-11-18 01:03:35 GMT
tags:
- i rebuke thee feminism
title: 
---
‘why does this discredit feminism and not capitalism???’

lol

most white feminists i’ve ever dealt with are unabashed capitalists and colonizers

i super resent the ppl who act like there are no legit criticisms of feminism

fuck feminism

i rebuke thee

