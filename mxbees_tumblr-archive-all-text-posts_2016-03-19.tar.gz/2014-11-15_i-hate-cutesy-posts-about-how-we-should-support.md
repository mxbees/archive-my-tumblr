---
id: 102659085794
slug: i-hate-cutesy-posts-about-how-we-should-support
date: 2014-11-15 02:53:20 GMT
tags:
- teh trans community
title: 
---
i hate cutesy posts about how we should support trans kids

but say nothing about actually addressing the material reality of dismantling transmisogyny

bc nothing less than this will actually help them

it’ll also help trans adults, as it happens

another reason the puberty blocker thing is annoying:

let’s not pretend all families will be supportive enough of their kids to allow them access to blockers

let’s also not pretend like all supportive families will have the money and ability to provide blockers if their kids wants them

what is ur cutesy post going to do to help them???

(and then there all the ppl who’ll claim i’ve been ~poisoned~ by my hormones. like u get how that post feeds into the same conceptual discourse, right?)

