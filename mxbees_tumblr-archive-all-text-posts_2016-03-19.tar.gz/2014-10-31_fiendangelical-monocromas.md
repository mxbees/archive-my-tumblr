---
id: 101429892384
slug: fiendangelical-monocromas
date: 2014-10-31 17:24:49 GMT
tags:
- mayo is as mayo does
title: 
---
[fiend–angelical](http://fiend--angelical.tumblr.com/post/101429622291/monocromas-fiend-angelical-b-binaohan):

> [monocromas](http://monocromas.tumblr.com/post/101429429444/fiend-angelical-b-binaohan):
> 
> > [fiend—angelical](http://fiend--angelical.tumblr.com/post/101428600521/b-binaohan-fiend-angelical-really-the-last):
> > 
> > > [b-binaohan](http://xd.binaohan.org/post/101428393914/fiend-angelical-really-the-last-thing-i-want):
> > > 
> > > > [fiend—angelical](http://fiend--angelical.tumblr.com/post/101427341546/really-the-last-thing-i-want-is-a-gringxs):
> > > > 
> > > > > Really, the last thing I want is a gringx’s opinion in “third world”/”developing” countries. Including the terminology.
> > > > 
> > > > not only is she white  
> > > >   
> > > > but she is also one of those whites who get SUPER DEFENSIVE  
> > > >   
> > > > when ppl ask why they don’t make it clear that they are white.
> > > 
> > > I’m so unsurprised.
> > 
> > Question:   
> > What’s the alternative here? What would the desired course of action for a gringue?  
> > Maybe saying something like “ok I’m white but I think \_\_\_”, or just not saying anything at all? Because keeping silent about these things, wouldn’t it be taken as, like, reinforcing the oppressive opinion?  
> >   
> > Help. I’m confused.
> 
> The alternative in a post like that one I reblogged is really to not say anything because a white settler’s opinion in terminology that applies mostly or completely to colonized countries WITHOUT including the voices of non-white people from said countries, is colonialist on itself.
> 
> Regarding stating her race on her description; if she’s still gonna keep talking about racial issues (Instead of amplifying the voices of poc talking about that), she should AT LEAST clarify that she’s white somewhere for accountability purposes.

like. why could she (or any other white person) just link or quote to something and iaopoc person has said?   
  
as far as racism and colonialism is concerned, white ppl have no original thoughts. it came from somewhere… so point, boost, and highlight.   
  
and i really had to fucking \_dig\_ to find that post about her race.   
  
“i’ve never tried to hide my race, except that if you actually try to find it, you’ll have to look really really hard”  
  
before i engage pretty much anyone i don’t know about topics like racism or colonialism (fuck, actually any topic tbh, including trans stuff, sexuality, how to make muffins, whatever), i usually go check out the person’s bio.   
  
in general, i’m not on tumblr to have conversations with white ppl about anything.   
  
whether or not someone is important information for us and our safety  
  
and this is what needs to be prioritized

