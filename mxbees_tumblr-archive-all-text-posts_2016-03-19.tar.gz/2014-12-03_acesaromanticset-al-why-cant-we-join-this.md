---
id: 104236967699
slug: acesaromanticset-al-why-cant-we-join-this
date: 2014-12-03 11:14:00 GMT
tags:
- teh queer community
- transmisogyny is fun for the whole family
title: 
---
aces/aromantics/et al: ‘why can’t we join this community that literally organizes itself and priorities around throwing twoc under the bus?’

twoc: …

et al: 'i mean… we also want to be involved in things like ENDA where we can push to protect ourselves, while leaving ~gender identity~ out bc it is too controversial (esp. re: public accommodations). i promise, twoc, unlike the other cis queers, we really will come back for you’

twoc: … \>.\>

et al: 'like… we are totally just as homonationalist as the gays and the lesbians. we want to make sure gays can get married in all 50 states before twoc can safely pee in public’

twoc: :|

et al: 'plus, i’m totally more involved in the community than any twoc i’ve seen. like i barely see them at any events and none even showed up to hear my tdor speech :’(((

twoc: i hate u

et al: 'zomg. see. we are oppressed and excluded from queer spaces’

