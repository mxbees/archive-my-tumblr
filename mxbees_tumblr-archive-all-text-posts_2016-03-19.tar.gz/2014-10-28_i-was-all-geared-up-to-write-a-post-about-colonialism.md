---
id: 101198906411
slug: i-was-all-geared-up-to-write-a-post-about-colonialism
date: 2014-10-28 21:01:27 GMT
tags:
- decolonization nao
- classical biyuti
title: I was all geared up to write a post… about colonialism and gender and stuff.
---
But. I tried. And then failed. In part because my bf kept interrupting me but also because I was annoyed with him. Also, they cleaned the halls of my building with something strong that is making me sneeze, so I’m feeling super drowsy from anti-histamines. Blech.

The post was going to be about:

- R\*dfems and their inherent white supremacy
- Because of their position on trans stuff and they ways they support/enforce the binary
- And since the binary is a colonial tool
- this means that r\*dfems are colonialist
- and colonialism also an expression of white supremacy,
- therefore, r\*dfems are colonialists and white supremacists.
- and will always be
- because the very foundations of their analysis and ‘radical’ approach
- depends on reifying a tool of white supremacy
- and you can never win so long as your approach simply creates what you wish to destroy.
- those feminists who are not radical but neither challenge radicalism nor include intersectionality in a meaningul way
- are exactly the same
- and this is, in part, why I still don’t have time for trans feminism
- because I have no desire to associated with hate mongering white supremacists and the people that complacently go along with it
- I don’t need feminism
- I need decolonization

That is the post I wanted to write…

instead I have a post that doesn’t make any sense and I’m still not sure what the hell I’m talking about.

