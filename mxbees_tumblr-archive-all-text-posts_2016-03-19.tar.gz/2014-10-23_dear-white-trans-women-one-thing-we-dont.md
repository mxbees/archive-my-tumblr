---
id: 100785275420
slug: dear-white-trans-women-one-thing-we-dont
date: 2014-10-23 23:31:02 GMT
tags:
- teh trans community
- classical biyuti
title: 
---
Dear white trans\* women,

One thing we don’t often sit down and chat about is your relationship to colonialism.

We do talk, every so often, about your relation to whiteness and various racist institutional structures that privilege you over trans PoC.&nbsp;

But lets talk about that, plus, how one of the most important racist institutional structures is colonialism, be it material or cultural, and how you most definitely benefit from it and are complicit in it.&nbsp;

Can we talk about this?&nbsp;

About how all white americans are responsible for and complicit in the many ills currently plaguing the Philippines (see american occupation of the Philippines)? Especially the sex tourism industry and the role that many bakla people play in it? Can we talk about how the transition focused discourse of the white trans community plays a role in many bakla illegally and dangerously taking hormones? Can we talk about how the white people and their pageants have created a vast bakla, pageant culture in the Philippines that often (accidentally, I’m sure) perpetuate whiteness as the ideal for beauty and femininity?

I suppose you want me to wait until you’ve achieved a level of equality on the backs of trans\* women of colour, before we discuss all this. Because so few of you seem willing to deal with the reality that your whiteness oppresses people of colour and that this means trans people of colour too.&nbsp;But even those who partially get still only think that you are complicit in my oppression as a PoC. No. You are also complicit in my genderescent oppression. Because they are not different things.&nbsp;

It is interesting, isn’t it, how intersectionality is always forgotten when it is time for accountability.

No love,

biyuti

