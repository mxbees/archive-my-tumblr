---
id: 128930510204
slug: a-small-thought-about-survival
date: 2015-09-12 17:53:20 GMT
tags:
- discussing discourse
- op
title: a small thought about survival
---
this isn’t… entirely a criticism of the notion but rather… perhaps a small resistance to it.

i often see in many different contexts the idea that so and so’s survival is resistance

and while i generally do agree with the sentiment it also troubles me

my survival doesn’t have to mean anything or resist anything in order for it to be ‘good’

the very fact that i’m alive is all the justification i need in order to continue existing.

(caveat aside that my life isn’t justification to harm others in order to continue existing…)

my life has value in and of itself

without any reference to some larger movement or system or whatever

and notice how it is really only marginalized ppl who need to justify our survival.

my life matters.

not bc it serves some grand purpose or means something to teh movement

it matters bc i matter.

i matter bc i’m here and i’m human.

my survival is necessary, powerful, and meaningful on this basis alone

