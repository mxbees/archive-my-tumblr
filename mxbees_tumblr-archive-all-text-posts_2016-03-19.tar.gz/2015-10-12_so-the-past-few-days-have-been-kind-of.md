---
id: 131044486014
slug: so-the-past-few-days-have-been-kind-of
date: 2015-10-12 21:19:50 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
so… the past few days have been kind of interesting/weird?

i wrote about 4k words on the epic essay on scientific racism (it is about 7k right now and i’m not sure how long it’ll be by the time i finish it).

i also worked a lot on my numerology stuff.

which has been kind of fun. i have a fully functional numerology program that allows me to plugin the relevant data and its spits out a nice looking PDF of the person’s chart. :D

i’ll probably end up sharing the code on github for anyone who might want to use it. what i need to do is finish re-writing a bunch of the number descriptions and what they mean, bc right now i’m using stuff i copied from another book (which is why the code isn’t available yet). although… i guess i could make the part of the code that just does the calculations available since the copyrighted stuff is in a different script (having the calculator as a distinct script was useful for debugging).

i’m enjoying the process of writing my own descriptions and interpretations more than i thought i would. i’m making a _lot_ of analogies to RPGs. lol.

the thing i’m hating most about reading this stuff is cheesy new age crap.

its weird. i’m very pragmatic about my spiritual approach atm. my bf asked me once what i actually thought the ontological status of my ancestors was, since i think they exist and speak to me. i basically was like “idk, i don’t really think about it”. and i don’t.

this is what comes of being a metaphysical realist. my ancestors exist bc they talk to me. what is the nature of their existence? i can’t help but think of Confucius’ answer to a similar question:

“not yet knowing life, why do you ask about death?”

