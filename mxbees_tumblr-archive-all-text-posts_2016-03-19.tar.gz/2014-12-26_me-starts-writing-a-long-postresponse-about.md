---
id: 106264301634
slug: me-starts-writing-a-long-postresponse-about
date: 2014-12-26 23:02:21 GMT
tags:
- race to the bottom
title: 
---
me: starts writing a long post/response about racialized feminity and Asians (men are feminized and women are hyperfeminised)

\*thinks for a second\*

\*deletes\*

there is a time for having this discussion about femininity and asians… but i don’t feel like doing it rn

