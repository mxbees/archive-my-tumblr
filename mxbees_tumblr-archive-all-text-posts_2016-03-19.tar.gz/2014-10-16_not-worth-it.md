---
id: 100162396424
slug: not-worth-it
date: 2014-10-16 15:06:04 GMT
tags:
- discussing discourse
title: not worth it
---
nowadays when i see a new term (like sapiosexual) i don’t bother to look it up

i just roll my eyes and keep moving.

bc. like.

the ppl i follow and speak with on a regular basis are (and have been) at the avant garde of anti-oppressive discourse for quite some time.

this is especially true of the Black ppl i know

(since, like, it is a historical fact that Black ppl have been at the literal bleeding edge of liberatory discourse for hundreds of years)

so

if the new term doesn’t come from one of them

or someone they know

i know without having to check that it is most likely white bullshit

and i don’t have to care about it.

like i just googled ‘sapiosexual’ and i’m looking at this fucking bullshit thinking

“holy fuck, white ppl really do make an identity out of their rancid farts”

not surprising given that white ppl will make a community out of beards. like just growing beards. competitions with reward money and everything. they’ll base their identity off of the most tenuous bullshit.

'zomg! u grow hair out of face? me too! let’s bond about this’

go build another atheist church u irrelevant assholes.

