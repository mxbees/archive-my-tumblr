---
id: 116399625944
slug: thebooknotthemovie-b-binaohan-ill-say-it-as
date: 2015-04-14 18:46:42 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[thebooknotthemovie](http://thebooknotthemovie.tumblr.com/post/116394954042/b-binaohan-ill-say-it-as-much-as-needed-though):

> [b-binaohan](http://xd.binaohan.org/post/114078423909/ill-say-it-as-much-as-needed-though-trans):
> 
> > I’ll say it as much as needed though.
> > 
> > Trans women, should we have penises, are not privileged because of them. Not ever.
> > 
> > Not even a little bit.
> > 
> > So be careful when trying to talk about “people with penises” as if cis men and trans women with penises EVER share some common privilege.
> > 
> > Now \_that\_ is classic transmisogyny.The only privilege is peeing standing up, I am jealous of that.

This is like the fifth time someone has left this fucking comment and it is so fucking annoying.

I get it. You’re fucking super clever and so fucking funny. Ha. Ha.

This despite the fact that peeing standing up can cause dysphoria for some trans women.

This despite the fact that some of us who don’t mind peeing standing up get policed by other trans women for being fake.

Or that peeing standing up in a public washroom could lead to violence.

But. Ha! Make a fucking clever joke about what trans women do in the washroom like this isn’t a constant source of anxiety and violence.

