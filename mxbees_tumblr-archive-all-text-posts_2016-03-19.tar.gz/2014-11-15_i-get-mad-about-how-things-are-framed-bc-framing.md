---
id: 102692785094
slug: i-get-mad-about-how-things-are-framed-bc-framing
date: 2014-11-15 14:45:00 GMT
tags:
- teh trans community
- discussing discourse
title: 
---
i get mad about how things are framed bc

framing is so critically important for how we interpret a message

like, no, the framing doesn’t determine the meaning of the message

but the framing is what will import unstated and assumed assumptions

these assumptions are what makes the message coherent

so, for that hormone blocker post, the unstated assumption that medical interventions are the most critical and important kind for trans kids

is deeply harmful

(because of the pathologizing of transness and white medical models of gender and imperialism)

like… have u seen that stats for the number of trans women who self-harm or commit suicide after they get the Big Surgery?

yes, a lot of conservatives and whatever take this as evidence that GCS (and related technologies) are really mutilation

but the actual interpretation is that

medical interventions (as necessary as they sometimes are)

are insufficient on their own to dramatically improve the quality of life of trans women

so it matters a great deal

that when u are trying to give positive information like

‘hormone blockers are safe for kids’

that you also note that

hormone blockers are _not_ what will make a kid a boy or a girl or anything else.

nor are they a magical solution that will make all of your kid’s struggles with their gender magically evaporate.

parents of trans kids need to be prepared for more than just trying to provide appropriate health care. it is also about the emotional (and social) support.

and, yes, i fully expect that this information is conveyed in any and all info posts. because it matters.

