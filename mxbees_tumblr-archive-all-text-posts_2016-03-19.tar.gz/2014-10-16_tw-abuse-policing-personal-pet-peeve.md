---
id: 100157482209
slug: tw-abuse-policing-personal-pet-peeve
date: 2014-10-16 13:25:00 GMT
tags:
- ye olde abuse culture
- classical biyuti
title: "(tw: abuse, policing) Personal pet peeve"
---
(probably because it is so fucking gross)

People who think that for something to count as abuse it needs to fulfill some arcane formula they decide on.&nbsp;

People who think their experiences are the authoritative measure for abuse.&nbsp;

People who watched a tv movie and think that abuse must be \*visible\* and \*dramatic\* for it to count.&nbsp;

People who use their experiences to silence yours.&nbsp;

People who think their personal experience makes them experts and, thus, qualified to make judgements about other people’s experience.&nbsp;

People who do this fucking suck.&nbsp;

