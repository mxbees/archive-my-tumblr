---
id: 128787370239
slug: in-mcdermott-ohio-a-bunch-of-transmisogynist
date: 2015-09-10 17:49:28 GMT
tags:
- current events
- trans bathroom panic
title: 
---
In McDermott, Ohio, a bunch of transmisogynist parents filled the power of trans bathroom panic, are protesting a trans girl using the washroom.

> One of the main concerns that was heard at the Sept. 8 school board meeting was people’s moral rights and what exactly they are entitled to.
> 
> The school board is standing firm that the opinions of other parents do not trump the rights of its students.

( [Original Source. Trigger Warnings for transmisogyny, biological essentialism](https://web.archive.org/web/20150910121315/http://www.wowktv.com/story/29990631/parents-angry-after-transgender-students-bathroom-choice))

