---
id: 99719519354
slug: omg-so-so-apparently-the-teen-wolf-fandom
date: 2014-10-11 11:42:50 GMT
tags:
- tyler posey
- teen wolf is a shitty racist fandom
title: 
---
omg.

so. SO.

apparently the teen wolf fandom is _still_ going after tyler posey for saying that he thinks sterek is gross

saying that he is homophobic bc he thinks that a relationship betweeen a grown man and a teen is kinda icky?

(which it is, btw, especially the way that some sterek writters write the relationship)

lol

this is the fandom that effectively killed my desire to participate in any way (including reading fic) by its relentless racism

why not do something about _that_? hmm?

