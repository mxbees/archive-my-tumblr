---
id: 131652370779
slug: i-guess-on-one-level-it-is-a-good-thing-to-know
date: 2015-10-22 00:22:47 GMT
tags:
- transmisogyny is fun for the whole family
- op
title: 
---
i guess on one level it is a good thing to know that most trans women would find my body gross?

that bc they hate their body, they also hate mine?

that there are real and serious limits to how much body positivity and acceptance of diversity within teh community?

that the ppl who say ‘testosterone poisoning’ never think about the girls who don’t want hormones or the girs who can’t take them or the girls who want to take them but there are too many barriers?

i mean, who gives a fuck about girls like us?

