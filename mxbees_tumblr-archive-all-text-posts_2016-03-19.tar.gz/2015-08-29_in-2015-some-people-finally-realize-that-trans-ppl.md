---
id: 127824079434
slug: in-2015-some-people-finally-realize-that-trans-ppl
date: 2015-08-29 00:11:33 GMT
tags:
- current events
- medical abuse
- rape
- sexual assault
title: In 2015 some people finally realize that trans ppl have needs and experience
  sexual assault
---
In Oregon a bunch of medical professionals are getting the FIRST-EVER train on how to better assist trans victims of sexual assault.

Some person notes that ‘the training is needed because transgender people are both at higher risk of sexual assault and less likely to report it because they have not had good experiences with the medical community in the past’, the only response is… no shit.

( [Original Source. Trigger Warnings for](https://web.archive.org/web/20150828180254/https://around.uoregon.edu/content/university-host-new-training-care-transgender-assault-victims))

