---
id: 107363752014
slug: i-wish-this-story-didnt-have-a-main-character-who
date: 2015-01-07 01:23:34 GMT
tags:
- media musings
title: 
---
I wish this story didn’t have a main character who is white and dreads.

