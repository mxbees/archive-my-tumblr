---
id: 100823692479
slug: loling-a-little-this-morning
date: 2014-10-24 12:00:37 GMT
tags:
- decolonization nao
- i rebuke thee feminism
- epilepsy warning
title: lol'ing a little this morning
---
at the seemingly inexplicable argument that&nbsp;

thinking that gender is a social construct = accepting [r]dfmnism’s basic tenets

er.

![](https://33.media.tumblr.com/tumblr_mbksq6futb1qkf4s2.gif)

First. I was utterly unaware that [r]dfms are 1. the ones who came up with social constructionism as a critical viewpoint and 2. that their beliefs/philosophy/etc. were supposed to be challenging it, rather than reifying them.&nbsp;

Like. This phrase “gender is a social construct created to oppress women” (which I saw in this argument) is, yes, something that [r]dfms say… but it is so obviously white supremacist that I’m not sure why it is something they’d assert…

unless (as decades of evidence show) they simply are just a white supremacist hate group?&nbsp;

I can think gender is a social construct without thinking that anything that any white ]r\dfm has ever said has any liberatory value of any kind.&nbsp;

social constructionism isn’t central to white [r]dfm philosophy. whereas white supremacy \*is\* central to it

so, again the burden of proof shifts to you/them.&nbsp;

Prove to me that 1. it isn’t white supremacist or 2. that they are now currently doing anything to address their white supremacy or 3. what any ideas of value exist within it that aren’t tainted by their white supremacy.&nbsp;

And prove on of points 1-3 without invoking WoC involved in the movement (i.e., “I have a Black friend!”) or similar rhetorical or logical fallacy.&nbsp;

