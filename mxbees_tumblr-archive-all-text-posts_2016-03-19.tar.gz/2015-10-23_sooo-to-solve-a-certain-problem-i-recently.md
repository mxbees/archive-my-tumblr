---
id: 131760874108
slug: sooo-to-solve-a-certain-problem-i-recently
date: 2015-10-23 18:44:04 GMT
tags:
- tech support
- op
title: 
---
sooo. to solve a certain problem, i recently started using google music.

the problem was this: i’m poor, my external HD is old, i want to back up my audio without having to pay any money (i’ve already had one HD die on my and i lost like… 30gb of music or something – on top of my pictures).

my solution? google music. while they have a paid streaming service, they also provide [a ‘locker’ where you can upload upto 50,000 of your songs](http://techcrunch.com/2015/02/25/google-play-music-increases-cloud-storage-limit-to-50000-songs/). Not sure how true this is bc the google website seems to say 10,000.

I realize that this isn’t… a ton of space for ppl with extensive music libraries. but it is a space for you to back up some of the essentials/your favourites.

for me, though, this is great bc it means i can back up my audiobooks and podfic. there is a 300mb file size limit and this mainly means that most books can be uploaded as one or two 'songs’. fucking awesome.

and then its available for me to stream wherever? awesome. possum.

anyway, just a tip for ppl with limited HD space and money.

