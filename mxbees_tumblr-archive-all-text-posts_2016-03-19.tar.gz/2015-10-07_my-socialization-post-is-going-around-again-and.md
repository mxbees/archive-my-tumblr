---
id: 130691027725
slug: my-socialization-post-is-going-around-again-and
date: 2015-10-07 16:55:18 GMT
tags:
- discussing discourse
- op
title: 
---
my socialization post is going around again and i’m getting some interesting responses…

like.

“are we ignoring how ppl treat other ppl? if ppl treat a trans girl like a boy, then she was socialized as a boy.”

lol.

if everyone treated me like a turkey, that wouldn’t mean i was socialized as a turkey.

jsyk.

