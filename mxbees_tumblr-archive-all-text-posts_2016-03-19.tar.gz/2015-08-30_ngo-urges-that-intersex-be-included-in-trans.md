---
id: 127961709191
slug: ngo-urges-that-intersex-be-included-in-trans
date: 2015-08-30 18:44:02 GMT
tags:
- current events
- india
- intersex
- trans rights
title: NGO urges that Intersex be included in trans rights bill
---
> The non-inclusion of intersex persons in the Transgender Rights Bill, 2014, passed successfully in the Rajya Sabha recently is a cause for concern for gender rights activists.
> 
> Worried over this category of people being kept out of the purview of the Bill, Srishti Madurai, a gender rights organisation, has decided to take up their cause.
> 
> “We will impress upon BJP MP Shobha Karanlaje, who is likely to sponsor the Bill in the forthcoming Lok Sabha session, to include intersex persons too,” said Gopi Shankar, founder-member of Srishti.

( [Original Source. Trigger Warnings for some medical descriptions, nonconsensual surgery, medical abuse](https://web.archive.org/web/20150830104857/http://www.newindianexpress.com/states/tamil_nadu/List-Intersex-in-Transgender-Bill-Urges-NGO/2015/08/29/article2998899.ece))

