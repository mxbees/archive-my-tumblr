---
id: 109093058939
slug: b-binaohan-i-know-there-are-some-cultural
date: 2015-01-25 11:03:39 GMT
tags:
- ye olde abuse culture
title: 
---
[b-binaohan](http://xd.binaohan.org/post/109092172469/i-know-there-are-some-cultural-variations-and):

> i know there are some cultural variations and stuff…
> 
> but i do have to say that i’m firmly in the ‘no corporal punishment’ camp.
> 
> even when/if not abusive, i don’t think hitting kids communicates the right message re: discipline

i’m not quite arguing for that super white parenting thing where they try to discuss/debate every single fucking thing with their kids (which i think it horrible in a different way, since child development means that, for example, toddlers aren’t capable of the type of moral reasoning i see some white parents expecting from their kids)

but i think it is a lack of imagination that makes a lot of the ppl i see think that you either do corporal punishment OR you do white-hippie-style of parenting.

however. the awesome parents i do know, the ones who give me hope about the reality and possibility of good parenting do seem to have a good balance between the two.

i believe that punishment and disciplining children can be accomplished without abuse. it happens. i know it does.

