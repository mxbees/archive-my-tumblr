---
id: 103408567579
slug: i-wonder-if-ppl-realise-that-their-desire-to
date: 2014-11-23 22:54:54 GMT
tags:
- media musings
title: 
---
i wonder if ppl realise that their desire to always write stiles as a cop

shows just what an awful asshole he is.

and so too with the sheriff.

