---
id: 131345177079
slug: i-think-i-decided-that-im-going-to-read-something
date: 2015-10-17 12:43:37 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
i think i decided that i’m going to read something different than i read on thursday. definitely going to the first patreon personal essay. idk. seems… better?

its also at a public library and i’m like… should i be swearing? there might be kids.

i’m not really nervous, which is cool. although i’m amazed that it takes 60mg of prozac and 300mg of wellbutrin to make me a reasonably functional human being (obvs, these don’t do anything about autism and executive dysfunction).

still trying to decide what else i might want to do at the festival thing.

bad-dominicana is doing at thing at 17:15 and i’m definitely going to that bc… yeah (whether or not i have the courage to actually go up and say ‘hi’??? who knows).

there’s a workshop on libel tomorrow morning that i’m half-tempted to go to and share my experience with being sued for libel.

most of which can be summed up as: don’t.

-1/10 do not recommend.

