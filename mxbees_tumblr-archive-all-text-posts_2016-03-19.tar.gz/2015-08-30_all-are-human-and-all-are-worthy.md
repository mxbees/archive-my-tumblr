---
id: 127973642847
slug: all-are-human-and-all-are-worthy
date: 2015-08-30 21:27:54 GMT
tags:
- race to the bottom
- transmisogyny is fun for the whole family
- classical biyuti
title: all are human and all are worthy
---
A note on how some activists are discusing Michelle Koselik and CeCe McDonald.

This question was salient for me because I haven’t heard too much about Kosilek (beyond the news I read). And pretty much all the news I’ve been reading is talking about using ‘tax dollars’ to pay for SRS. Or continuously mentioning that she is in jail for murder… as if it is at all relevant.

I also come from a place with universal health care that is slowly starting to include SRS for all citizens. This includes people who are in prison.

But beyond the parallels of the situations…

Michelle Koselik is a human being who deserves this medical care. And she deserves everyone’s support in this, wholeheartedly and without reserve. People seem to forget that no one is arguing that she should be let out of jail or not serve her sentence… The issue of whether or not she should have this surgery paid by the state is distinct. And she should. Because if the state is going to incarcerate her, she is their responsibility.

More stunning is how short sighted everyone is about this. Yes, Michelle isn’t the most sympathetic person (on paper, at least). But she isn’t the only trans woman in jail. There are other trans women in jail, disproportionately trans women of colour, who could and would benefit from having a precedent set for _all_ the medical needs of incarcerated trans women being taken care of.

Even more dangerous is how much of this discussion has been legitimizing the prison industrial complex. Nothing good can ever come of acting as if one of the worst state institutions should have the right to decide who deserves what medical care (to decide what is necessary). Because Michelle’s 12+ year battle has shown: the prison industrial complex is not interested in either the health or safety of trans feminine people.

Also in terms of people’s indignation that her surgery would be covered… (but not yours! as if you are more worthy)

The question should always be: why is it that we are living in a society that simply does not have the infrastructure to provide the necessary health care to all of its citizens (yes, I’m including canada in this because not all necessary care is covered here)? We are _literally_ in the wealthiest parts of the world. This shouldn’t be an issue or a debate.

But if you are going to debate it… invoking some kind of respectability politics is a grave error. As I’ve noted before: respectability politics are racist. Because even if this particular instance involves a white woman… how much less deserving do you think women of colour will be found?

Either we are all human and worthy

or none of us are

