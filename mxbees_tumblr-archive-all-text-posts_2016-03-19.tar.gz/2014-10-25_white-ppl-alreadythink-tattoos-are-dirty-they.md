---
id: 100873267689
slug: white-ppl-alreadythink-tattoos-are-dirty-they
date: 2014-10-25 01:39:18 GMT
tags:
- everyone wants to know about tattooz
title: 
---
white ppl alreadythink tattoos are dirty

they thought they were dirty when they first encountered iaopoc

they still think they are dirty today

why else do tattoos

(amongst white ppl)

remain a traditional marker of counter culture

you do it to debase urselves like u imagine iaopoc are

this is literally why u think having tattoos means

u can be oppressed for ur skin like iaopoc

