---
id: 130847619614
slug: today-has-been-kind-of-interesting-i-wrote-3k
date: 2015-10-10 01:03:21 GMT
tags:
- the life of an ordinary bakla
title: 
---
today has been kind of interesting?

i wrote 3k words on the essay about racism that i wasn’t actually goign to finish, which is kind of cool. its at about 5k words right now, so this pretty much going to be epic, lol. i think i’m maybe… at least halfway through everything i wanted to talk about?

then, bc i couldn’t write anymore… i decide to make programs? lol.

i wrote a script to autogenerate numerology profiles (after i’ve done the calculations – i might try to figure out how to also get the program to do the calculations too… but i might have to switch programming languages to make that actually easy on myself).

i wrote a script that should hopefully allow me to backup my tumblr again (since the method i was using before broke bc of some changes tumblr made to the api).

i started another script that will, hopefully, allow me to read the text posts on my dash from the command line. which is kind of fun…

:P

soon i’ll be going to bed…

