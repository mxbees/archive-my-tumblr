---
id: 103365734964
slug: friendly-reminder-to-ignore-salvation-army-bell
date: 2014-11-23 13:23:58 GMT
tags:
- discussing discourse
- decolonization nao
title: Friendly reminder to ignore Salvation Army bell ringers this year.
---
[sirsmalldog](http://sirsmalldog.tumblr.com/post/103174881520/friendly-reminder-to-ignore-salvation-army-bell-ringers):

> [lelaid](http://lelaid.tumblr.com/post/103128768218/friendly-reminder-to-ignore-salvation-army-bell-ringers):
> 
> > They use your money to lobby for anti-LGBT laws around the world in addition to exploiting the homeless, supporting anti-POC, anti-LGBT, anti-woman Conservative politicians, and doing it all under the guise of being a “religious organization”
> > 
> > [Read about it here.](http://wrongkindofgreen.org/2013/03/18/the-starvation-army-12-reasons-to-reject-the-salvation-army/)
> 
> I’m glad this post says “ignore”. Please remember not to rude - often times the workers do not know the messed up workings of the people they work for.

meh. fuck them.  
  
be rude if u want.  
  
sally anne’s is a church and i’ll be as rude as i want to a bunch of colonialist assholes who get in my face about christmas or any other thing

