---
id: 103195814474
slug: are-ppl-ready-to-hear-my-voice-totally-just
date: 2014-11-21 11:46:35 GMT
tags:
- the life of an ordinary bakla
title: 
---
are ppl ready to hear my voice?

totally just made my first audiopost.

but. BUT.

i guess i’m a bit nervous. lol

