---
id: 100464169924
slug: tw-for-abuse
date: 2014-10-20 01:58:20 GMT
tags: []
title: tw for abuse
---
[imnotevilimjustwrittenthatway](http://imnotevilimjustwrittenthatway.tumblr.com/post/100461506444/tw-for-abuse):

> [secretandroid](http://secretandroid.tumblr.com/post/100460716585/tw-for-abuse):
> 
> > [prudewheresmyghost](http://prudewheresmyghost.tumblr.com/post/100456804101/tw-for-abuse):
> > 
> > > [creatingmyselfasigo](http://creatingmyselfasigo.tumblr.com/post/100449041874/theindivisibles-smitethepatriarchy):
> > > 
> > > > [theindivisibles](http://theindivisibles.tumblr.com/post/100445228321/smitethepatriarchy-tommcready-sooooo-sick-of):
> > > > 
> > > > > [smitethepatriarchy](http://smitethepatriarchy.tumblr.com/post/100435275998/tommcready-sooooo-sick-of-yall-putting-sudden):
> > > > > 
> > > > > > [tommcready](http://tommcready.tumblr.com/post/100427390195/sooooo-sick-of-yall-putting-sudden-mood-swings):
> > > > > > 
> > > > > > > sooooo sick of yall putting ‘sudden mood swings’ in the lists of abusive traits like that isnt a symptom of many stigmatised mental illnesses i see you&nbsp;
> > > > > > 
> > > > > > This is so true, and it’s not an abusive trait. “Mood swings” are involuntary and due to changes in serotonin or dopamine or something like that. Abusers deliberately choose to act suddenly angry or sad or whatever in order to manipulate their victim.
> > > > > 
> > > > > i disagree with the argument that abuse is necessarily intentional. there is a big difference between emotion and action.   
> > > > > all emotions are valid but no amount of emotional turmoil excuses abusive actions.  
> > > > > you don’t get a free pass to act abusive ‘unintentionally’ just because you have a history of abuse or fit the criteria for a mental illness. we are each responsible for our own actions, whether we have difficulty regulating our emotions or not.
> > > > > 
> > > > > Everybody messes up sometimes but when it becomes a recurring theme it is problematic, whether it is intentional or not.
> > > > 
> > > > That needed to be said. Abuse is often not intentional. Many abusers DO have sudden mood swings that they do not control that cause them to lash out (and often, to think they’re justified at the time). I’d go as far as to say most people with mood swings are not abusive (obviously I don’t have statistics for this), but ALL of the abusers I’ve known have had them.
> > > 
> > > Abuse IS intentional. An abuser’s intent is to control their victim[s] into getting what they want. They’re entitled people who will use _anything_ as an excuse in attempts to justify their controlling behaviour. Abusers KNOW what they are doing. If an abuser happens to have mood swings/or whatever other symptom & uses that as an excuse to abuse, the abuser is to blame, _not_ the mood swings. I’m pretty sure that’s all the OP was saying&nbsp;?
> > 
> > we need to differentiate here between An Abuser and _abusive behaviors_, which often CAN and DO happen unintentionally (and yes sometimes due to mental illness). a person can do an abusive thing accidentally, it does not necessarily make them An Abuser. abuse does not have to be intentional to be abuse. that is a dangerous idea. i often see people deny acting abusively because they didn’t realize what they were doing.&nbsp;
> > 
> > mood swings are not inherently abusive. they CAN be a red flag. both of these things need to be acknowledged.
> 
> Maybe this is just a language problem but I’m kind of disturbed by the idea that ‘person who does abusive things’ and ‘abusive person’ are separate concepts. And by the defensiveness.
> 
> (Re: the mood swings thing….ime mood swings have less to do with abuse than abusers being incredibly entitled and angry and it therefore being very easy to do something they react badly to.)

there isn’t a distinction… abusive behaviours can be determined and understood as how abusers behave. how they abuse their victims.  
  
and the ‘mood swings are involuntary thus not abusive…’  
  
lol  
  
fuck all of you.   
  
this sounds like ppl who’ve never been at the mercy of an abuser who had unpredictable mood swings and created a pervasive environment of terror  
  
raising hypervigilent children…

