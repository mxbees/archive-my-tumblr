---
id: 128336219304
slug: some-ppl-might-think-im-being-super-defensive-or
date: 2015-09-04 15:06:01 GMT
tags:
- the life of an ordinary bakla
- i'm so mad
- omg
- its been a while since something a person said on the internet has gotten under
  my skin this way
title: 
---
some ppl might think i’m being super defensive or something with that last response…

but i actually find myself more annoyed and aggravated by that comment than many of the entirely shitty things that’ve been added to my posts in recent memory.

from a mention of length alone, i’m assumed that i’m writing long, complicated, dense prose? ok.

the reality is, is that my posts have gotten longer so that i can actually explain people how i reach the conclusions that i reach. i’m doing the extra work of articulating the connections between a lot of ideas that have bee floating around, instead of just expecting that ppl will be able to make the same cognitive connections.

i think i’m also just… mildly insulted about the comment on my writing. i know i’m not a great writer. i work hard at it. i also work really hard at not writing jargon-laden, theoretically dense posts. bc my target audience isn’t academics so i don’t write for them.

