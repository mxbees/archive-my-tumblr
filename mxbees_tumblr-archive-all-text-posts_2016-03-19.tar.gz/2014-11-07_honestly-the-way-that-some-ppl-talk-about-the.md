---
id: 101975698564
slug: honestly-the-way-that-some-ppl-talk-about-the
date: 2014-11-07 02:28:27 GMT
tags:
- media musings
title: 
---
honestly…

the way that some ppl talk about the smith children gives me the willies

just….

creepy.

