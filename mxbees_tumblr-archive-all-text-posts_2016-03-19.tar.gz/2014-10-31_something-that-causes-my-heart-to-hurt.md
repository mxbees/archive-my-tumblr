---
id: 101442874022
slug: something-that-causes-my-heart-to-hurt
date: 2014-10-31 21:01:31 GMT
tags:
- decolonization nao
- classical biyuti
title: Something that causes my heart to hurt
---
That a definition of luck I just saw is avoiding becoming a victim of white eugenics (which is really a slow kind of genocide).&nbsp;

I often see sentiments like this, that avoiding x experience of oppression is lucky.&nbsp;

Every manner and way that we manage to resist oppression is awesome and should be celebrated…

But think about how awful this measurement of luck is. And other similar things.&nbsp;

While my family was poor growing up, we never went hungry. I feel lucky that I had enough to eat even though I didn’t always have clothes that fit or were in good repair. I feel blessed about this.&nbsp;

But, fuck, not starving and/or not being a victim of eugenics is a pretty poor measure for luck.&nbsp;

This is the world we live in:&nbsp;

A place where I feel lucky that my poor immigrant one parent family had enough food.&nbsp;

Or someone mentioning they feel blessed to have medical insurance to access needed services.&nbsp;

Is it just me? Or should I stop thinking that this sort of shit should be the absolute minimum?&nbsp;

No families should starve. No one should fear eugenics. Everyone should have access to medical services. Etc.&nbsp;

I think of all the things that really make me feel defeated, it is when I feel blessed for shit that should just come out of the box for just being born.&nbsp;

