---
id: 128195144466
slug: basically-angelica-ross-is-awesome
date: 2015-09-02 16:55:00 GMT
tags:
- current events
- twoc thriving
- Black trans women thriving
- angelica ross
title: Basically, Angelica Ross is awesome.
---
Not too many comments here, since I encourage everyone to go read this profile of Angelica Ross. It’s great.

( [Original Source. Trigger Warnings for survival sex work, family rejection](https://web.archive.org/web/20150902115900/http://www.advocate.com/print-issue/current-issue/2015/09/01/showgirl-ceo-trans-businesswoman-angelica-ross-tells-all))

