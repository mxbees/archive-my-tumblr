---
id: 103931479819
slug: like-some-white-lady-seriously-thought-me-being
date: 2014-11-30 00:13:00 GMT
tags:
- antiblackness is real
title: 
---
like some white lady seriously thought me being mean

was equivalent to Black ppl’s experience of police violence.

white women are so fucked up.

