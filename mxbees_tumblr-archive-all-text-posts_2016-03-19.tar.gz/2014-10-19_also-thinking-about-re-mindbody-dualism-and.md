---
id: 100444280364
slug: also-thinking-about-re-mindbody-dualism-and
date: 2014-10-19 21:45:08 GMT
tags:
- able ability
title: 
---
also thinking about re: mind/body dualism and healig and disability

like, that thing about how white doctors tried to go to Rwanda and ‘help’ with the trauam

but couldn’t do a single fucking thing to help

bc all their solutions were too focused on the individual

white ideology functions off of reduction.

always reducing us to smaller and smaller parts

but never letting us be whole, complete human beings

