---
id: 100682092413
slug: i-have-so-many-feelings-about-rationality-and-logic
date: 2014-10-22 18:30:51 GMT
tags:
- b loves logic
- classical biyuti
title: 'I have so many feelings about rationality and logic. '
---
Once upon a time I studied logic. And what always gets me whenever white people, esp the racist, sexists, or social justice people is how they go on and on about logic.&nbsp;

Never realizing that there is more than one kind of logic. There are logics. These logics are competing.&nbsp;

There are logics where ‘or’ isn’t even a valid operator (i.e., classical Chinese logic).&nbsp;

There are logics that stress relevance (i.e., invalid arguments are both false and irrelevant)

There are logics that assert contradictions are true (yes, contradictions. True. And I’ve seen the math for this, it works).&nbsp;

There are logics that allow for degrees of truth.&nbsp;

There are logics for time.&nbsp;

For knowledge.&nbsp;

For every damn thing you can imagine. There are so many logics in the west.

There is also a variety of Buddhist logics, Arabic logics, Indian logics, some Chinese logics, and (I have zero doubt but never had the chance to study) many kinds of African logics.&nbsp;

Logic (and, thus, rationality) is just as diverse as the people who use it.&nbsp;

But this also doesn’t account for cognition. Which tends to contradict logical systems. How our brains process information and make decisions has almost no relation to logic.&nbsp;

Western/white logic is the foundation for computers and computational languages.&nbsp;

I am not a computer. I also don’t value the sort of 'intelligence’ that computers have. They are not my ideal for rationality.&nbsp;

I will keep my emotions. I will use my intuition.&nbsp;

And I will also use my deep knowledge of logic to destroy the arguments of any white person, if I feel like.&nbsp;

