---
id: 116853645259
slug: bigbardafree-the-thing-about-being-someone
date: 2015-04-19 21:43:11 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[bigbardafree](http://bigbardafree.tumblr.com/post/96054724187/the-thing-about-being-someone-whos-never):

> the thing about being someone who’s never catcalled is that you start to wonder why like is it because im ugly???
> 
> and then you realize that youre judging your worth by whether or not you are objectifiable to a man and thats so fucked up like honestly its so fucked up&nbsp;
> 
> but the worst part about the patriarchy is that it still sits at the back of your mind regardless like “nobody thinks youre pretty because they dont see you as a sex object” like somehow thats a desirable thing and it fucks me up

and if ur a trans woman u get the fun, fucked up experience of getting catcalled/street harassed and maybe feeling like u’ve accomplished something bc, for once, u passed well enough to be subjected to this really commonplace (but violent) form of misogyny…  
  
then ur like… this is fucked up bc i’m basing my ‘success’ as a woman based on whether or not some random fucking guy decides to be sexist shithead

