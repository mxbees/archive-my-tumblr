---
id: 117464516619
slug: warning-paypal-new-user-agreement-changes-all
date: 2015-04-26 22:30:05 GMT
tags:
- capitalism for the win
title: 'Warning: Paypal new User Agreement changes, “All Your Stuff Belongs To Us”'
---
[shadowlillium](http://shadowlillium.tumblr.com/post/117391848000):

> [thinkererdreamspace](http://thinkererdreamspace.tumblr.com/post/117391047246/warning-paypal-new-user-agreement-changes-all):
> 
> > [baraswamperthugs](http://baraswamperthugs.tumblr.com/post/117390772265/warning-paypal-new-user-agreement-changes-all):
> > 
> > > [shadowedformlovingheart](http://shadowedformlovingheart.tumblr.com/post/117390552917/warning-paypal-new-user-agreement-changes-all):
> > > 
> > > > [summer-of-the-shinx](http://summer-of-the-shinx.tumblr.com/post/117390252981/warning-paypal-new-user-agreement-changes-all):
> > > > 
> > > > > [shadowlillium](http://shadowlillium.tumblr.com/post/117388151900):
> > > > > 
> > > > > > Coming to all July 1, 2015, All Your Copyrighted material, Trademarked, Intellectual Ideas, and Much More will belong to Paypal if you use their services.  
> > > > > > \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  
> > > > > > [https://www.paypal.com/ie/webapps/mpp/ua/upcoming-policies-full?locale.x=GB](https://www.paypal.com/ie/webapps/mpp/ua/upcoming-policies-full?locale.x=GB)  
> > > > > >   
> > > > > > _**Amendment to the PayPal User Agreement.  
> > > > > >   
> > > > > > Intellectual Property**  
> > > > > >     
> > > > > >   
> > > > > > We are adding a new paragraph to section 1.3., which outlines the licence and rights that you give to us and to the PayPal Group (see paragraph 12 below for the definition of “PayPal Group”) to use content that you post for publication using the Services. A similar paragraph features in the Privacy Policy, which is removed by the addition of this paragraph to the User Agreement. The new paragraph at section 1.3 reads as follows:  
> > > > > >   
> > > > > > **“When providing us with content or posting content (in each case for publication, whether on- or off-line) using the Services, you grant the PayPal Group a non-exclusive, worldwide, perpetual, irrevocable, royalty-free, sublicensable (through multiple tiers) right to exercise any and all copyright, publicity, trademarks, database rights and intellectual property rights you have in the content, in any media known now or in the future. Further, to the fullest extent permitted under applicable law, you waive your moral rights and promise not to assert such rights against the PayPal Group, its sublicensees or assignees. You represent and warrant that none of the following infringe any intellectual property right: your provision of content to us, your posting of content using the Services, and the PayPal Group’s use of such content (including of works derived from it) in connection with the Services.”**_  
> > > > > >     
> > > > > > \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  
> > > > > > I’m switching to [Google Wallet](https://wallet.google.com/enroll/?flow=wallet&continue=https://wallet.google.com/manage/?referer%3Dhttps://support.google.com/mail/answer/3141103?hl%253Den%26pli%3D1#) or something else. Paypal lost me.
> > > > > 
> > > > > Wow lost me too, PayPal. That’s seriously uncool.
> > > > 
> > > > Thanks for the link to Google Wallet because uh, nope. Nope nope nope
> > > 
> > > can someone mind breaking this down to simple speech i don’t ndertsa d what they wrote |D
> > 
> > TL;DR version: the moment you provide PayPal with content, said content belongs to them.
> > 
> > Not cool, PayPal.
> 
> ^  
> Yup.  
>   
> Like say you make an art commission to an individual with original characters, or you are selling videos,video games, logo, or books that you made, all that content you sold and had Intellectual rights to through Paypal, even if you copyrighted them or trademarked them, Paypal is trying to say because you used their services THEY now own the rights to it. No where in the writing does it say&nbsp;“unless you had previous trademark or copyrights,” Nope. They are saying they own it regardless, and you are agreeing to them owning your works digitally or physically and future works from these forms of art and characters, they will own it.

not that this isn’t important…

but if _this)_ is what gets u to realize that paypal is a shitty corporation, then u haven’t been paying attention.

they are a privately owned, right wing christian thing

they have constantly been stealing the money (by freezing and refusing to release the funds) of sex workers and other marginalized ppl.

paypal is and always has been a shitty corporation

no surprise.

but of course, the straw that breaks the back is _property_ not other ppl’s humanity and ability to make a safe living.

ok. sure.

