---
id: 103846284079
slug: as-shitty-as-tumblr-is-the-deletion-of-the
date: 2014-11-29 00:48:41 GMT
tags:
- Ferguson
- race to the bottom
- antiblackness is real
title: 
---
as shitty as tumblr is…

the deletion of the Ferguson tag is…

idk

a step too far I think.

