---
id: 103146028189
slug: and-i-think-im-ready-to-give-up-for-the
date: 2014-11-20 21:08:13 GMT
tags:
- the life of an ordinary bakla
title: 
---
and….

i think i’m ready to give up for the day.

i just.

gah. this day. this fucking day.

but i’m so glad i made some food for Jennifer, January, and Mark.

I hoped they liked the adobo…

i’m thinking i’m going to light candles for them too.

ala my catholic background bc why not?

