---
id: 103842934179
slug: it-is-kind-of-hard-to-talk-about-what-the-most
date: 2014-11-28 23:59:20 GMT
tags:
- tech support
title: 
---
it is kind of hard to talk about what the most appropriate replacement for tumblr is…

partly because a lot of us stay here because there are certain features/experiences about the website that are unique enough that you can’t find anything exactly like it.

the closest is probably soup.io, but fuck that is an ugly site and it is slow, laggy, and weird.

but u can import your entire tumblr into it.

the next closest is probably wordpress.com. now… i know a lot of ppl think of wp blogs as ‘individual’ and wordpress.com as not being a social site…

but they’ve actually implemented a dashboard and a reblog function. you can also import your entire tumblr to wordpress.

the next, esp if we look more towards microblogging, is twitter. you can retweet. the block function actually works and, importantly, a lot of people are already on there. but then there is the character limit… which i know really limits things for a lot of people.

which is kind of… the point? i mean.

tumblr really does occupy the perfect niche between real microblogging like twitter and longer-form blogging like wordpress.

even more importantly… it allows for a lot of different media types that you won’t find support for on a lot of the other networks.

like twitter doesn’t allow for gifs.

wordpress does allow for video/audio embeds, but if you want to host there it costs money and the space is really limited (yes, you can self host wordpress, but then you loose out on the social features).

stuff like instagram is images (and super short videos) only. no reblogs.

there isn’t any real alternative to tumblr. if you want to leave the platform for something else… i’m there with you.

lately i like twitter a lot and my own self-hosted blog (ie, my main blog).

