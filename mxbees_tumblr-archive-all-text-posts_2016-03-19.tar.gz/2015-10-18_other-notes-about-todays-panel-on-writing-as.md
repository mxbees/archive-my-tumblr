---
id: 131445154864
slug: other-notes-about-todays-panel-on-writing-as
date: 2015-10-18 21:38:22 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
other notes about today’s panel on ‘writing as resistance’

- ppl really can’t refrain from making fat phobic and transmisogynist jokes.
- like i’m not joking
- and most of the audience laughed
- but i’m glad that i didn’t do the uncomfortable chuckle u do when you don’t want to seem out of place but someone just said something fucked up

there was one white person on the panel. and he was a cis gay man. and (obviously) he was the one who made a few transmisogynist jokes. even though there were two fucking tpoc on the same panel as him.

anyone surprised? i’m sure not.

this also serves (imo) as a reminder as to why i tend not to do these types of things. inevitably, there is some kind of micro (also macro) aggression. no one (including me) says anything.

then there’s the access issue re: fragrance. its weird bc even my professional conferences have instituted fragrance free policies (that almost no one follows… but at least they are trying).

one large reason i did do this thing (despite not really liking to do them) is that it was, at least, local. i’m really serious that i will probably turn down most invitations for me to go places if i think there is someone local who is awesome. beyond just the social capital aspects, i have a lot of… idk, feels about the fact that ppl will spend thousands of dollars to fly someone in to talk about a thing when there are (always) awesome ppl local. like why can’t u give that two thousand dollars or whatever (airfare + accommodation + honorarium) to a local Black trans woman?

for all that a lot of ppl really claime to want change, we still end up making this kind of… celebrity culture in activist/progressive/left circles. like. sure. i get that i’m somewhat higher profile than some other ppl. but i really have to ask what ur community is doing such that they can’t identify and locate someone local who can give (more or less) the same message i would. seems like a way to dodge accountability for real change.

“we do things for trans women of colour, look we invited this out-of-town twoc to do some event or other”

all the local twoc: fuck u.

this post totally went in a direction i didn’t intend… :P

