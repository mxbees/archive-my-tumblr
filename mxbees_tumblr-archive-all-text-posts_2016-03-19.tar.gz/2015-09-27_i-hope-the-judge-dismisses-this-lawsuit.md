---
id: 129999943799
slug: i-hope-the-judge-dismisses-this-lawsuit
date: 2015-09-27 17:49:35 GMT
tags:
- current events
- usa
- lawsuits
- planet fitness
title: I hope the judge dismisses this lawsuit
---
So the lady who got her Planet Fitness membership revoked for refusing to stop harassing other customers over her alarm that trans women exist is suing them.

> Cormier’s lawsuit claims invasion of privacy, multiple violations of the Elliott-Larsen Civil Rights Act, breach of contract, intentional infliction of emotional distress, exemplary damages and a violation of the Michigan Consumer Protection Act.

Now. For me, the most ‘interesting’ part of this law suit is the Ellioit-Larsen invocation (which I learned via this very article, is the American law dealing with sexual harassment).

(note: there will be some misgendering in the quotes to follow but I think its contextually important)

> Since the lawsuit does not include a claim that Cormier experienced any behavior of a sexual nature during her time at Planet Fitness, Beale asked Kallman how the Elliott-Larsen Act could apply, as far as counts of sexual harassment are concerned.
> 
> “Women and men being naked together in the same locker room, taking showers and doing all this and they’re saying that doesn’t have any component of a sexual nature to it,” Kallman said.
> 
> “You don’t have those facts in this case,” Beale replied.

The lawyer goes on to cite a case where a woman won a sexual harassment claim based on a policy that made her wear scanty clothing and it was decided that the policy was enough to create an environment where sexual harassment could occur.

Then mentions specifically how she still had clothes on, unlike the case at Planet Fitness.

I’m writing this at length because I want people to understand that _this_ is the consequence of people thinking that trans women are inherently sexual predators. We are _sexually harassing_ cis women by simply existing in the same place. Not a distant cousin to radfems claims that we are 'raping’ women by existing. Also not a distant cousin from Pemberton’s claim that he murdered Jennifer Laude because he was worried she’d rape him. Same thing that people are invoking for why grade school trans kids shouldn’t be allowed to pee in gender appropriate washrooms.

These 'stereotypes’ have real consequences in the world.

( [Original Source. Trigger Warnings for misgendering, transisogyny](http://web.archive.org/web/20150927115209/http://www.mlive.com/news/saginaw/index.ssf/2015/09/civil_case_involving_transgend.html))

