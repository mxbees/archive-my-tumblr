---
id: 116555365219
slug: imnotevilimjustwrittenthatway-crawlboy-if
date: 2015-04-16 13:54:08 GMT
tags:
- ye olde abuse culture
title: 
---
[imnotevilimjustwrittenthatway](http://imnotevilimjustwrittenthatway.tumblr.com/post/116554799064/crawlboy-if-your-discourse-is-communicated):

> [crawlboy](http://crawlboy.tumblr.com/post/116052782987/if-your-discourse-is-communicated-regularly-with):
> 
> > if your discourse is communicated regularly with scorn, anger, & opinions stated as undeniable fact with those emotions behind them, it is dangerous and inaccessible to survivors/victims of abuse.
> > 
> > being abused changes the way your brain works. sometimes i see arguments that i know i 100% disagree with, but if they’re stated in a way that makes it clear that i am being a bad/evil person or stupid for not agreeing, my knee jerk is to start rethinking everything i know. it takes a considerable effort to stop this and come back to being rational, and sometimes i can’t. it’s a survival mechanism i can’t turn off
> > 
> > it is not tone policing to acknowledge the presence of survivors/victims in every social group and state that abused people’s needs have to be recognized. when your arguments are presented in a repetitively vicious way that you never back down from, there is a huge chance that you are being directly harmful to the most vulnerable members of your radical space
> 
> My main problem with this post is the idea presented at all abuse survivors find scorn/anger/undeniable-fact-opinions triggering and dangerous? Like, abuse survivors are really NOT a monolithic group! We are not all triggered by the same things!
> 
> Whenever anyone groups all abuse survivors/victims and says&nbsp;‘this groups needs this’ and the&nbsp;‘this’ is anything but, like,&nbsp;‘human respect and dignity and to not be abused and to be believed’ I am very, very suspicious. It is entirely possible OP is doing this out of sheer ignorance, which is annoying and stupid but not malicious.
> 
> But, like, here’s the thing, OP. _I_&nbsp;find arguments stated as fact, angrily sometimes, with the implication that OP hates me, much, much easier to deal with than politely-stated, bewildered dehumanization. Like, I also find being yelled at easier to deal with than people being soft-spoken and manipulative.&nbsp;
> 
> I am also not suggesting that every space be tailor-made for me and not OP. That’s equally bad. I am suggesting that perhaps OP not overgeneralize their own needs and/or patterns they’ve noticed to everyone who has ever been abused.
> 
> I’m not saying that you’re wrong or bad for needing to avoid people that always post with anger an scorn or whatever. Seriously, avoiding being triggered isn’t immoral. But it is false to say that&nbsp;‘people who are very angry and scornful’ are dichotomous with&nbsp;‘abuse survivors/victims’, and it is false to say that what triggers you triggers _me_&nbsp;as well.&nbsp;
> 
> If I need to speak up, the people I am tumblrfriends with will listen if I ask for something, won’t judge or notice if I blacklist some tags, and won’t quietly manipulate me back to where I started like certain exes did. I’ll take the people who can scream at the top of their lungs but won’t sweetly and politely dehumanize me, ever, over the people who can play the game of social points and then look at me as a _thing_&nbsp;anyday.

all of this…

and. like. _part_ of my abuse was making me think that any and all expressions of anger are dangerous/bad/make me a bad person

i find ppl who can access their anger and express it unapologetically _healing_ and _comforting_. they help me access my own anger at injutice while also making me feel safer.

like. great. u find ppl being unrelentingly angry about injustice triggering as a survivor? i’m glad you have identified this trigger. thinking u get to impose, yes, i _will_ say it, tone policing on entire groups of ppl?

bc… some of us, regardless of what our tone actually is or our actual internal feelings when we write stuff are always perceived as angry. read what Black women have to say about this.

do not act like the perception of anger isn’t gender and race coded.

