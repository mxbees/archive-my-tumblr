---
id: 127813761485
slug: transgender-woman-suing-over-discrimination-at
date: 2015-08-28 21:28:02 GMT
tags:
- current events
- workplace discrimination
- transmisogyny
- labour rights
title: Transgender Woman Suing Over Discrimination at Burger King
---
Steph Williams-Blackmon works at Burger King. She feels that she has been harassed by a gradual reduction in her hours and was targetted because she is trans.

( [Original Source. Trigger Warnings for](https://web.archive.org/web/20150828174418/http://www.wandtv.com/story/29897946/transgender-woman-suing-over-discrimination-at-burger-king))

