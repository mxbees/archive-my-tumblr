---
id: 102488698269
slug: i-love-how-one-of-the-best-ways-to-get-endless
date: 2014-11-13 00:37:11 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
i love how one of the best ways to get endless tumblr harassment

and shitty ppl showing up with their asshole ~opinions~

is to merely suggest that many cis ppl’s (inclusive of cis lesbians)

unending obsession with trans lady peen

might be something they want to look into

‘i don’t want to touch it111’ u screech

when… who the fuck invited u in the first place????

'u make me want to vomit’ u moan

yeah, u and everyone else, ur not special

what _would_ be special is if u spent five minutes trying to figure out why the fuck ur so obsessed with trans lady peen in the first place.

