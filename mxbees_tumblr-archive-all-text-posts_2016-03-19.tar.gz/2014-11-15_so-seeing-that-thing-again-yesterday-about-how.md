---
id: 102727368664
slug: so-seeing-that-thing-again-yesterday-about-how
date: 2014-11-15 22:43:52 GMT
tags:
- transmisogyny is fun for the whole family
- teh trans community
- op
title: 
---
So seeing that thing (again) yesterday about how trans men, even though they are men, aren’t men in the same way as cis men and so deserve access to women’s spaces.

Or something.

The logic on this is always convoluted and twisted and doesn’t make any sense. But you see transbr0s articulating it all the time.

“zomg! we are still trans!”

Which, whatever, ok.

The thing that gets me is that they operate on this notion that there is, in reality, a scarcity of spaces that trans men can access. Which is pretty fucking ridiculous and counter to how the world actually works.

So, like. Outside of a very few occassions (with maybe some more occurrences online), trans men can easily access any and all trans spaces (like specific spaces for trans ppl in general). They can easily access a lot of spaces for (cis) women. They can, depending on how well they blend, access a lot of spaces for men.

Online, sure, things are a bit different. You’ll see a greater prevelance for people (cis and trans) talking about how trans women totes belong in women’s spaces. And that trans men… maybe they don’t because men. But you also<sup id="fnref:p102727368664-1"><a href="#fn:p102727368664-1" rel="footnote">1</a></sup> see a lot of people saying the opposite (especially a certain group of cis feminists).

The thing is, is that a lot of non-twoc like to talk about how important it is to include us, how important it is to support us, how we are the most likely targets of trans related violence, how we should be centred and supported….

But do you know how many spaces I’ve been in where that was actually and literally true?

One.

Just one.

And you know _why_?

Because it was something organized by twoc for other twoc.

In general trans spaces, transbr0s are all over the place. Especially the white ones. They are leading the groups, organizing and dominating the spaces, they are the ones getting paid to be activists and to represent ~teh trans community~. Maybe, MAYBE, some of these spaces will have some white trans women.

If things were actually different… If stuff was actually changing, I wouldn’t be about to ~celebrate~ my fourth (fifth?) TDoR where literally everyone on the list is a trans woman of colour.

Sure, its fashionable to pay lip-service to twoc, but this rarely translates to actual, real world difference unless it is being spoken by twoc ourselves.

But, sure, br0, tell me again how you don’t have enough spaces when I can still point to at least one women’s rape centre where you’re welcome and I’m not.

* * *

1. 

I mean, I’m writing this fucking post in response to more suggestions that men belong in women’s spaces, aren’t I?&nbsp;↩

