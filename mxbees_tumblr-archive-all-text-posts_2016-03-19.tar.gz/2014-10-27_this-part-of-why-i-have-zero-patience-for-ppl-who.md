---
id: 101045034409
slug: this-part-of-why-i-have-zero-patience-for-ppl-who
date: 2014-10-27 00:55:49 GMT
tags:
- survival is a communal activity
title: 
---
this part of why i have zero patience for ppl who literally come

onto _every fucking donation post ever_

to go ‘zomg, hdu ask ppl for money’

like. u don’t want to give anything? don’t

u don’t want to boost? don’t.

these ppl will literally pull anyting out of their asses to criticize u

there is no fucking dignity or glamour in being poor.

none.

this isn’t about fucking pride.

one of the key features to human survival is our ability and willingness to cooperate.

it is literally one of the most beautiful thing about us

‘do it all on ur own!’

fuck off.

