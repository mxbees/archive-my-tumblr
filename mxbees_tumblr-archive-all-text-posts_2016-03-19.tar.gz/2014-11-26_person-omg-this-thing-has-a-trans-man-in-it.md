---
id: 103597171774
slug: person-omg-this-thing-has-a-trans-man-in-it
date: 2014-11-26 01:02:32 GMT
tags: []
title: 
---
person: ‘omg. this thing has a trans man in it! yay representation!’

me: wow. i’m having a hard time imagining myself caring less about there being more men in media

