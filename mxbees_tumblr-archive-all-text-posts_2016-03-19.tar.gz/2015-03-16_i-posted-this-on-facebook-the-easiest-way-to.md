---
id: 113773079714
slug: i-posted-this-on-facebook-the-easiest-way-to
date: 2015-03-16 08:41:12 GMT
tags:
- race to the bottom
title: 
---
(i posted this on facebook)

The easiest way to determine if a group of people was white in the early days of colonization is a simple checklist of the most important white privileges:

1. Could they become citizens?
2. Could they own enslaved Black people?
3. Could they own property?
4. Could they marry white people?

If the answer to all of these questions is ‘yes’, then the group was white. Irish people could do all of these things from the moment they arrived to settle in the americas.

I will say this as much as is needed…. (this was posted in a comment thread elsewhere).

Only white people are able to answer 'yes’ to all of these questions, esp. during the early days of colonization in the Americas. These were literally, at the time, the biggest and most important white privileges.

