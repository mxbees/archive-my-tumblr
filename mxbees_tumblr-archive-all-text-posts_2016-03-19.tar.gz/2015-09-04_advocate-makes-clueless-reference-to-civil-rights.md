---
id: 128341872751
slug: advocate-makes-clueless-reference-to-civil-rights
date: 2015-09-04 16:55:03 GMT
tags:
- current events
- trans rights
- trans bathroom panic
- anti-Blackness
title: advocate makes clueless reference to civil rights movement
---
when i saw the original comment from Lila Perry, i sort of… shrugged bc she’s young<sup id="fnref:p128341872751-1"><a href="#fn:p128341872751-1" rel="footnote">1</a></sup>. not that this is an excuse for the anti-Blackness, just a reason for her ignorance. at issue is comments like this:

> Surrounded by almost 40 supporters gathered Monday to counter the transphobic rally, Perry drew parallels to well-known anti-segregationist, Jim Crow-era battles in the American civil rights movement. “It wasn’t too long ago that white people were saying that they don’t feel comfortable sharing a bathroom with a black person, and history repeats itself,”

many Black ppl have discussed why comparisons like this are harmful and anti-Black, and i’m not going to talk about that (bc they say it better than me).

but rather… as a non-american, for a long time i really didn’t get why ‘civil rights’ was a such a… term of contention amongst Black americans. of course, this is bc i didnt’ learn american history to any real extent. i didn’t understand that while in canada 'civil rights’ can be a broadly used term to describe a kind of political agenda, in the american context it really refers to a specific history and context.

i encourage everyone to learn about this context and why comparisons like this are anti-Black.

( [Original Source. Trigger Warnings for transmisogyny, anti-Blackness](http://web.archive.org/web/20150904100330/http://www.advocate.com/transgender/2015/09/02/missouri-trans-students-bathroom-struggle-history-repeating-itself))

* * *

1. 

but i remember pointing out the problems with the original comment – although&nbsp;↩

