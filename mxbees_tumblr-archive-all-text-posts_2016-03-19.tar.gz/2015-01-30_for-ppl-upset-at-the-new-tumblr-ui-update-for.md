---
id: 109567977784
slug: for-ppl-upset-at-the-new-tumblr-ui-update-for
date: 2015-01-30 09:34:15 GMT
tags:
- tech support
title: 
---
for ppl upset at the new tumblr UI update… (for posting)

may i suggest learning markdown? i actually didn’t really notice much of a difference bc the markdown interface on tumblr was about that bare as it is now.

it also means that you don’t really need those additional editing tools unless u want to insert a gif.

plus, markdown is great.

