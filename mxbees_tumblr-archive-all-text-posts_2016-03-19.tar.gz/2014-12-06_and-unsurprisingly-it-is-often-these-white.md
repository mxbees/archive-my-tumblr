---
id: 104452642659
slug: and-unsurprisingly-it-is-often-these-white
date: 2014-12-06 01:43:16 GMT
tags:
- race to the bottom
title: 
---
and, unsurprisingly it is often these white ethnics who want to complain about

how the social construct of ‘race’ has erased their individual identities

even though this is literally true of _every_ single race

that is the whole point of race

and YET

interesting how these ethnic whites _still_ get better recognition for their unique

ethnicities over and above any poc ethnicity i know

almost like they are white… and thus get the benefit of being seen as unique/individual

