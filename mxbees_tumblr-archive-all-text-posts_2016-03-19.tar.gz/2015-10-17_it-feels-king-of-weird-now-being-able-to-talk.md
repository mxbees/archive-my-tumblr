---
id: 131317595744
slug: it-feels-king-of-weird-now-being-able-to-talk
date: 2015-10-17 00:55:51 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
it feels king of weird now. being able to talk about whatever in my life without having to worry (well, to an extent of course).

i was just thinking about how i’m unemployable (at least in my field and quite possibly for any professional level job). thinking about how i’ve been underemployed for three years (only a PT job). thinking of all the applications i’ve sent out over the past three or so years.

it makes me want to scream, at times, bc it means that i have a giant student loan and i wasted eleven years of my life getting my degrees.

i’ve been applying for service jobs without mentioning even just my bachelors, in the hopes that the employers won’t think me over-qualified (and thus a risky hire). still no calls (despite also having around 10-15 years of customer service/food industry experience.

everyone really ought to think of me as a cautionary tale. don’t make the same choices i did. do better and be better. i believe in u.

