---
id: 131297450350
slug: now-that-ive-made-my-official-debut-as-real
date: 2015-10-16 18:44:07 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
Now that I’ve made my official debut as real writer in the real world, I figure now is a good time to relate some relevant information.

These are facts known about b. binaohan (penname of nina malaya):

1. ‘nina malaya’ is actually most of my 'real’ name in real life
2. i will continue to write and publish under my penname
3. i made a distinction between my penname and work as editor for biyuti publishing so that i could maintain a clear distinction between the two
4. i am still: autistic, pilipinx mestisa, trans, mentally ill, disabled,etc.
5. once upon a time (eg. sometime last year), i was sued for over a million dollars for defemation. its pretty much why i became depressed and suicidal (and was involuntarily committed earlier this year). it destroyed my professional reputation and credibility – basically my career is dead. i’m now unemployable in my field. all of this also has resulted in more MRA and other harassment for my IRL self than I’ve ever experienced here.
6. no one should ever ever listen to anything i ever have to say about careers or whatever (see above)
7. at this point i’m writing to feed myself and survive (its about the only option i have left bc no one will hire me for a full time job or even another part-time one)
8. i still think that manatees are the cutest animals on the planet
9. i am a failed human
10. but still human
11. i still have zero desire to become an activist or anything remotely resembling it. i can’t say that if ppl offer me money to do things, i’ll turn them down (i’m too poor for that), but i’m not going to seek it out or do any kind of organizing (i think with my relative privileges i should follow, not lead).
12. a forever petty petty princex
13. oh! now that i’ll be integrating my various online selves, expect me to write about some of the other topics i’m interested in: information ethics, tech stuff, that sort of thing.

i think this is it for now.

