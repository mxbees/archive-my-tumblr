---
id: 100693016186
slug: the-other-thing-people-forget-about-trust
date: 2014-10-22 21:01:35 GMT
tags:
- ye olde abuse culture
- classical biyuti
title: The other thing people forget about trust...
---
It is fragile and easily broken.

If you break it, be prepared to spend at least as much time as it took for you to build it in the first place.

Be prepared not to get a second chance, because no one owes this to you.

Be warned that if you break trust, someone may need to protect themselves from you (which may include violence).

My advice? Don’t break trust.

Treat it like the delicate, precious gift that it is. Always.

