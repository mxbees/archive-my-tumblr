---
id: 128272835771
slug: an-adult-trans-womans-awful-parents-are-trying-to
date: 2015-09-03 17:49:42 GMT
tags:
- current events
- discrimination
- legal violence
- child abuse
- ableism
title: An adult trans woman's awful parents are trying to prevent her GCS
---
 **trigger warning bc i find this really upsetting and a lot terrifying**

> A transgender woman whose parents went to court Wednesday to block her gender-reassignment surgery in Pennsylvania said she would rather die on the operating table than continue living with male anatomy.
> 
> Christine Kitzler, 48, said during a break in the emergency hearing that the risk factors her father raised — including complications from her HIV and Hepatitis C diagnoses — were worth enduring to have her body match the gender she’s identified with since growing up in suburban Cleveland, Ohio.
> 
> The surgery, temporarily halted earlier this week by a suburban Philadelphia judge as he considers a longer stay, would also save her from backsliding into alcohol and drug addiction, Kitzler said.
> 
> Her parents, Klaus and Ingrid Kitzler, contend Kitzler is not competent to make an informed decision to have the surgery because of depression and a childhood learning disorder. They want a temporary guardian named.

I’m… actually speechless that this worked and the judge actually stopped the surgery (temporarily).

She’s 48 years old. But wasn’t I just hearing about how the ~popular~ opinion about trans health care is just give us whatever we want?

When in reality, we have so many fucking barriers and, it seems, that even if we manage to get past all the barriers your parents (no matter what age you are) can declare you incompetent and block your surgery.

Awesome.

( [Original Source. Trigger Warnings for legal abuse, child abuse, suicidality, denial of healthcare](https://web.archive.org/web/20150903110359/http://www.oregonlive.com/today/index.ssf/2015/09/parents_sue_to_block_daughters.html))

