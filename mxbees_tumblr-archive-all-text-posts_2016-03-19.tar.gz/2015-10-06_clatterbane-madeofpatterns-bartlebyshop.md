---
id: 130648101014
slug: clatterbane-madeofpatterns-bartlebyshop
date: 2015-10-06 23:50:51 GMT
tags:
- the life of an ordinary bakla
title: 
---
[clatterbane](http://clatterbane.tumblr.com/post/128226697128):

> [madeofpatterns](http://madeofpatterns.tumblr.com/post/128086658667):
> 
> > [bartlebyshop](http://bartlebyshop.tumblr.com/post/128086491225):
> > 
> > > [madeofpatterns](http://tmblr.co/mf9UQGq_96SNSxAMWzRejGg) I felt bad continuing to reblog OP’s post because this is a bit of tangent.
> > > 
> > > I can’t even count the number of people I’ve known who have had the following experience:
> > > 
> > > Person: Begins taking SSRI
> > > 
> > > Person: \*notices side effect like the Remeron munchies, the&nbsp;“they weren’t fucking around about taking venlfaxine at set times!!”, etc.\*
> > > 
> > > Person: \*freaks out, assumes they are imagining things/making it up\*
> > > 
> > > Person: \*looks up SSRI on the internet, discovers this is a known side effect\*
> > > 
> > > Person:&nbsp;“Hello Dr. Fakename, I am experiencing this. Other people do too. Can I switch to something that doesn’t make me feel like a butt?”
> > > 
> > > Psychiatrist:&nbsp;“WHAT HAVE YOU BEEN READING?” \*ups dosage\*
> > 
> > Related:
> > 
> > Doctor: Take x.
> > 
> > Person: I’m already on y. Are there interactions?
> > 
> > Doctor: That’s not a problem with this drug.
> > 
> > Person: \*looks up interactions online, sees big warning about the dangers of combining those drugs\*.
> 
> Also:
> 
> Person: I had this very unpleasant/dangerous reaction(s) to Drug X before. Maybe closely related Drug Y is not the best option?
> 
> Doctor: … (\*condescending looks\*)
> 
> Doctor: \*prescribes Drug X instead, gets insulting when the person tries to repeat that it almost shut their liver down, etc. before\*
> 
> Person: \*afraid to even get the prescription filled\*
> 
> Doctor: (\*finds out the person is not taking Drug X\*) Noncompliance! \*Ups dosage, perhaps adds Drug Y to the mix as well\*
> 
> Person: \*wonders if their mouth is even moving, but is stuck with that doctor anyway\*

omg. the OP is pretty much what happened to me last week.

**me** : so… the insomnia i got when we increased prozac the last time hasn’t gone away.

**doctor** : i think it might be anxiety.

**me** : um………

**doctor** : let’s up your dose and see if that addresses the anxiety.

**m** : \*continues to sleep with multiple wakeups throughout the night and continues to feel like sleep deprived garbage while falling asleep randomly at work and around the house bc i’m so fucking sleepy and tired all the time\*

and the third scenario…

is pretty much why i will try to never, ever get involuntarily committed. bc…

**doctor in psych ward** : we are going to put u on abilify.

**me a month later** : holy shit. i feel fucking terrible and crazy and fatigued and not ‘better’ even in the least. i think i’ll go to the psychiatric emergency room and see what’s happening.

**a different doctor** : oh. so you say that you feel like garbage and delirious and fatigued? maybe we should increase your abilify dose.

**me** : okay.

one month later…

**phone rings and i answer** : hello?

**my family physician calling me at 7pm** : um… so i just got ur lab results and it looks like ur kidneys and liver are kind of dying? idk. i really really think you should _immediately_ stop taking abilify. i think u might have neuroleptic malignant syndrome.

**me** : wat.

and now i worry that if i end up back in the hospital… they’ll try and put me back on an anti-psychotic and my internal organs will melt bc they won’t believe that i had nms (in a different emergency room visit the doctor expressed extreme doubt that it happened to me despite me saying that this what my doctor told me).

i hate doctors bc they really never, ever fucking _listen_.

