---
id: 114833203264
slug: oh-trans-women-who-try-to-popularize-sister
date: 2015-03-28 11:21:06 GMT
tags:
- teh trans community
title: oh, trans women who try to popularize “sister”
---
[fakecisgirl](http://fakecisgirl.tumblr.com/post/114830192382/oh-trans-women-who-try-to-popularize-sister):

> I’ll call you that when y’all quit calling me a man and/or&nbsp;“it”.&nbsp;
> 
> Sisterhood is powerful, but it means accepting all your sisters, even the ones you think are too fat, too ugly, too disabled, too not-white-enough, too not-middle-class enough, etc.
> 
> So get on that, plz handle thx.

Luna had a great post, once upon a time, talking about this (although they were more talking about cis ppl claiming trans ppl as ‘family’)

but i still think that it is relevant.

like. yeah. sisterhood _is_ powerful.

but most of the trans women i’ve met/encountered…

they end up being opponents, not family.

you don’t get to call me 'sister’ if u think i’m subhuman garbage

