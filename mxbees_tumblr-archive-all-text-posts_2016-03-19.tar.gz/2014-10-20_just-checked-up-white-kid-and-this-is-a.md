---
id: 100466011984
slug: just-checked-up-white-kid-and-this-is-a
date: 2014-10-20 02:20:01 GMT
tags:
- able ability
- ye olde abuse culture
title: 
---
just checked, up, white kid.

and this is a classic example of bullshit white thinking

EITHER

a behaviour is abusive

OR

a behaviour is a symptom of mental illness/disability

BUT NEVER BOTH

when reality is always more complex than this

whereas some behaviours are BOTH abusive AND symptoms of a mental illness

WORSE YET

sometimes a person with a mental disability

can have a behaviour that is BOTH abusive AND a symptom of their disability.

it isn’t the behaviour that is one or the other

it is the _person_ that is abusive.

