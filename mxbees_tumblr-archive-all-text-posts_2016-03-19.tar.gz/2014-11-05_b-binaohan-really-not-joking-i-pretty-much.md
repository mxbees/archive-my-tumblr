---
id: 101801781099
slug: b-binaohan-really-not-joking-i-pretty-much
date: 2014-11-05 00:43:57 GMT
tags:
- media musings
title: 
---
[b-binaohan](http://xd.binaohan.org/post/101801619129/really-not-joking-i-pretty-much-only-want-to-see):

> really not joking
> 
> i pretty much only want to see chubby/fat Black and brown people
> 
> cosplaying lumpy space princess
> 
> white people aren’t worthy.

and i’d especially love for Black and Brown trans women to do LSP  
  
seriously.

