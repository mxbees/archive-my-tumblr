---
id: 126578635974
slug: whatabootsecondbreakfast-replied-to-your-post
date: 2015-08-13 09:40:24 GMT
tags:
- epilepsy warning
- whatabootsecondbreakfast
title: 
---
 [whatabootsecondbreakfast](http://whatabootsecondbreakfast.tumblr.com/) replied to your post [“sometimes i do window shopping online and look at all the pretty shoes…”](http://b-binaohan.tumblr.com/post/126552322334/sometimes-i-do-window-shopping-online-and-look-at)> ugh, that’s not fair re: shoes. you deserve cute shoes that fit you! if I was a cobbler I would make you them.

i think this is the most adorable reply i’ve had in a long time. omg.

:3

<figure class="tmblr-full" data-orig-height="281" data-orig-width="500"><img src="https://31.media.tumblr.com/df89058db54f34314e6ebd68a5023f97/tumblr_inline_nt0liqaELa1rdzs46_500.gif" data-orig-height="281" data-orig-width="500"></figure>