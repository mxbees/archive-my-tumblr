---
id: 105921119109
slug: b-binaohan-that-said-korra-was-such-a
date: 2014-12-23 02:04:57 GMT
tags:
- media musings
title: 
---
[b-binaohan](http://xd.binaohan.org/post/105920626814/that-said-korra-was-such-a-fucking-frustrating):

> that said…
> 
> korra was such a fucking frustrating show
> 
> not necessarily bc it wasn’t as good as atla (it wasn’t)
> 
> but bc it had…
> 
> the potential to be SO MUCH better
> 
> i don’t like how the narrative treated korra (esp. in contrast with aang)
> 
> half the time i was watching i wanted to punch my monitor
> 
> overall, the writing was sloppy and unfocused.

like why did all of korra’s growth as a character have to come from her getting beat up over and over again?  
  
(i’m not the first to make this observation)

