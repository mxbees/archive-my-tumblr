---
id: 103078303704
slug: unpopular-opinion-zuko-is-the-most-irritating
date: 2014-11-20 00:01:43 GMT
tags:
- media musings
title: 
---
unpopular opinion:

zuko is the most irritating character on avatar

SO ANNOYING

