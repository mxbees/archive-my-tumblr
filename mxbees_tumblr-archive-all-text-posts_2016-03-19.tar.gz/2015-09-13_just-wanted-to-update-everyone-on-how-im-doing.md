---
id: 129023532699
slug: just-wanted-to-update-everyone-on-how-im-doing
date: 2015-09-13 21:27:52 GMT
tags:
- the life of an ordinary bakla
title: 
---
just wanted to update everyone on how i’m doing…

i think my brain is finally calming down somewhat after increasing my wellbutrin dosage. that shit really messes with my head the first week or so that i start/increase my dosage. definitely feeling a lot more stable.

while the first few days of stepping away from having a continuous/responsive social media presence were difficult, now i find myself enjoying the break.

i miss people, yes, and i’ll come back eventually…

but it has been nice to just… post stuff without worrying about having to respond to inane comments or even just interact with anyone.

its kind of weird to maintain a ‘presence’ bc i can post without actually being logged into the website.

in any case…. i’m going to see about taking another week’s worth of hiatus and see how i feel then.

i hope everyone is doing well. or at least well enough. and if not, on the way to being well.

