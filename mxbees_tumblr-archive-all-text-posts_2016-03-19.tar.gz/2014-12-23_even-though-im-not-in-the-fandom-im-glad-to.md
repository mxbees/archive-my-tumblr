---
id: 105999204824
slug: even-though-im-not-in-the-fandom-im-glad-to
date: 2014-12-23 22:48:14 GMT
tags:
- media musings
title: 
---
even though i’m not in the fandom…

i’m glad to have a few convos about korra

that aren’t about ships

like. yeah. i loved the ending. it was very satisfying to me.

but it in no way absolves bryke of all the crap they did the rest of the series

the show was fucking _terrible_ and frustrating.

