---
id: 128493785085
slug: a-social-media-hiatus
date: 2015-09-06 17:49:34 GMT
tags:
- the life of an ordinary bakla
- op
title: a social media hiatus...
---
hey.

so… i think i need a break from the ‘social’ aspect of social media. while i do want to focus on my writing, i’ve… started some of my old obsessive patterns that lead to me interacting with social media in unhealthy ways.

so i’ve logged off of tumblr and twitter.

however, because i know how to post to tumblr without being logged in (indeed, i think 99% of my posts are posted in this way), this tumblr is going to stay active. i’ll keep writing blog posts and news summaries. but since i’m not going to be logged in, i won’t see any asks or comments on any of the posts.

i’m still trying to figure out a good way for ppl to contact me for accountability reasons (like… if i post something horrendous and oppressive and it needs to go). when i figure out this way, i’ll let you all know.

(i’m hoping if i take this break i can finally finish up my most recent book bc i’m _so close_ to being done. lol. but i haven’t been able to focus on it for a variety of mental health reasons.)

i hope ur all well in the interim.

