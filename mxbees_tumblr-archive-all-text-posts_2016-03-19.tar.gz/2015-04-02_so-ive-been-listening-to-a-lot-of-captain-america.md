---
id: 115254124634
slug: so-ive-been-listening-to-a-lot-of-captain-america
date: 2015-04-02 00:44:05 GMT
tags:
- media musings
title: 
---
so i’ve been listening to a lot of captain america 2 steve/bucky podfics…

and i can’t help but be struck by how very WHITE these narratives of healing and trauma are

like….

maybe i’d feel differently if there were any real… diversity and variety to how these stories presented and talked about trauma… but it is all the same.

the same dramatic and angsty shit.

and while, yeah, sure there are probably ppl with ptsd and trauma who act like bucky does is most of these fics…

but so many of them just sound like what some person imagines it is like based on other stucky fic they’ve read themselve.

but. whatever.

