---
id: 100704062217
slug: i-reserve-a-special-kind-of-loathing-for-those-people
date: 2014-10-22 23:30:54 GMT
tags:
- b loves logic
- classical biyuti
title: I reserve a special kind of loathing for those people who police tone and discussions
---
by asking that people be ‘rational’ or 'logical.’

It almost always is some white, cis, hetero dudebro so deluded by white supremacy that they think they are the pinnacle of what is rational and what is logical.

I always avoid these people like the fucking plague because it is a kind of evil that I have no desire to engage.

People are dying and you want 'rational’ debate or discourse.

Human reason divorced of passion and emotion is monstrous.

Also? I want to know when those people who call for rationality and logic will ever fucking realize that there are more kinds of rationality and logic than what is sanctioned by whiteness.

Traditions of argument and debate and logic that were created outside of whiteness. That just because you are white and deem something logical or illogical, it doesn’t magically make it so.

Your limited, biased view is not actually reality.

你们真的井底之蛙.

