---
id: 113858009284
slug: how-to-make-a-public-but-safe-amazon-wishlist
date: 2015-03-17 07:00:20 GMT
tags:
- tech support
- invisibleblackunicorn
title: how to make a public (but safe) amazon wishlist
---
someone just asked me how i made the amazon wishlist people were using to send me bday gifts

(which thanks everyone, btw, for the presents! i’m enjoying them all very much)

STEP ONE

On your wishlist page click on the ‘list actions’ menu in the top right corner of the list.

![](http://wp.biyuti.com/wp-content/uploads/2015/03/00.png)

STEP TWO

Click on 'Update List Profile’ in the menu.

![](http://wp.biyuti.com/wp-content/uploads/2015/03/01.png)

STEP THREE

Fill in the information. Make sure to check the “Use an existing shipping address” option, so that people can send you things without knowing your address.

![](http://wp.biyuti.com/wp-content/uploads/2015/03/02.png)

(Optional) STEP FOUR

If your list of shipping addresses has a name you don’t want strangers seeing, make sure to add a new shipping address in your amazon settings. You can add any name to your address to help preserve your privacy.

![](http://wp.biyuti.com/wp-content/uploads/2015/03/03.png)

**Warning for Canadian users: be careful which items you select, I’ve heard back from some people that Canada Post, if your package is sent by anything other than regular/free shipping, WILL REVEAL YOUR ADDRESS TO PEOPLE WHO SEND YOU GIFTS IN AN AUTOMATED EMAIL. I haven’t heard this from anyone shipping from the US, so I have no idea if this will apply there.**

