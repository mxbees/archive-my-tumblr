---
id: 129427650709
slug: in-shocking-news-white-trans-lady-is-an
date: 2015-09-19 16:55:18 GMT
tags:
- teh trans community
- op
title: in shocking news, white trans lady is an imperialist
---
Now, I don’t often bother to read anything Sandeen writes, for a few reasons:

1. I don’t care what white trans women have to say about anything ever
2. I especially don’t care about any white US military veteran has to say about anything ever

But when I saw [a recent editorial from her](http://syx.pw/1iEi4xN), I couldn’t help myself. In this piece, she argues against an idea that she erroneously attributes to Jen Richards’ recent _Advocate_ essay on [pluralism](https://gumroad.com/l/mKhgd#). Of course, Sandeen deeply misunderstands what pluralism is actually advocating for, but that’s no matter since she has an imperialist point to make!

> Well, the trans community exists. If I were only to see it in the proliferation of pink, white, and blue flags across the nation, I would know we fly under one flag.

I mean… really. REALLY? Lol. This is one of the most blatant [trans\*nationalist](http://syx.pw/1FmRrXU) statements I’ve seen in a really long time. It also highlights my previous criticism for why having ‘flags’ for communities is entirely fucked up.

One of the things that interests me the most about this, is how Sandeen sees this as a positive thing, rather than as a sign of the ever increasing hegemony of, well, shitty white trans people like her attempting to control the discourse and the community.

But then….

> But, I also see the community in the rallying behind the cause of ending the murders of trans women. I see it every Nov. 20 – the Transgender Day of Remembrance – when we name our dead and mourn them.

Lol. Excuse you? It isn’t 'our’ dead. Most of the people named on TDoR are people who aren’t and never were part of Sandeen’s community. And she’s only interested in us _when_ we are dead and not otherwise.

Remember [how I wrote like two years ago that](http://syx.pw/1gAl7oz):

> that the umbrella is a lie. the ~trans community~ is something that doesn’t, in fact, actually exist.
> 
> and, lest ppl forget, the fiction that there is an ~umbrella~, that there is a ~trans community~
> 
> hurts trans women of colour most
> 
> something to keep in mind as you defend ur castles made of shit

So Sandeen has no problem in defending a myth that harms trans women of colour, something I’ve known for years.

And to answer one of her questions….

> Do we say there is no women’s community because the Concerned Women Of America want to defund and shut down every Planned Parenthood clinic in America?

Lol. Do you know nothing of the history of feminism? Because there are large swaths of women who say exactly this.

The thing that Sandeen takes as a given and provide no real argument for is _why_ there needs to a singular community. What purpose does this serve? Who cares if we have multiple, at times overlapping, communities rather than a single, albeit diverse, unified one?

The answer is, is that if we don’t have a singular community than white trans women like Sandeen no longer get to speak for _all of us_. Instead, her voice is relegated to representing only shitty white trans women like herself. She is no longer the leader she likes to think she is. She is no longer as relevant as she desperately tries to be.

But, in the off chance that Sandeen ever reads this, I want to make it extremely clear: you are not part of my community. You never have been. And no amount of waving your white imperialist hand will change this. Because you aren’t the boss of me.

