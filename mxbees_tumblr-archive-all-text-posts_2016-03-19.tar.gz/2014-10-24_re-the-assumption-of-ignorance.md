---
id: 100823695444
slug: re-the-assumption-of-ignorance
date: 2014-10-24 12:00:40 GMT
tags:
- discussing discourse
- i rebuke thee feminism
title: 're: the assumption of ignorance'
---
I find [the consistent request from cis feminists](http://thesavagesalad.tumblr.com/post/34747867375/im-never-gonna-dispute-the-terminology-of)to trans feminine people to have historical knowledge to be entirely puzzling.&nbsp;

Like beyond the classist implications of telling us we need to understand the entire history of people who oppress us so that we can see the ‘good’ they’ve allegedly given the world…

Why is it that the assumption is that we don’t know? That phrases like 'cis scum’ or 'radscum’ might actually have come about with the full knowledge of just what radical feminism (and non-radical feminism) is?&nbsp;

Why are we assumed to be ignorant of a movement that is unabashedly all about oppressing people?&nbsp;

Is it because we’ve coined the terms 'cis scum’ or 'radscum’? Because we are angry? What?&nbsp;

I see the history of feminism.&nbsp;

It isn’t hard to locate it in a larger white supremacist, colonial framework designed to oppress all poc generally, and in later years especially with radfemninsm, trans woc in particular.&nbsp;

I dislike feminism because I know its history.&nbsp;

But even if I didn’t know of some theoretical good it did 40 years ago…

Tell me why I should care now, when their rhetoric and advocates are responsible for denying necessary services to trans women right now?&nbsp;

