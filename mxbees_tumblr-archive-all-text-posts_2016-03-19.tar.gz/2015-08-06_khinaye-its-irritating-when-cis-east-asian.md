---
id: 126003357074
slug: khinaye-its-irritating-when-cis-east-asian
date: 2015-08-06 10:21:39 GMT
tags:
- yellow peril
title: 
---
[khinaye](http://khinaye.tumblr.com/post/125927795843):

> It’s irritating when cis East Asian women exclude non East Asian women from being victims of fetishizing when the entire sex industry in Thailand and other SE Asian countries came about to cater to western soldiers stationed in those nations in times of war…like, both cis and trans SE Asian women are consistently raped, murdered, and abused by fetishizing western men AND East Asian men so
> 
> 1) don’t pretend that the suffering of SE women doesn’t exist and
> 
> 2) don’t lump East and SE Asian women into the same group when it comes to sex industries because SE Asian sex workers endure a lot of violence from other East Asian men who come to SE Asian countries for sexual tourism

given that if you do a google search (i don’t recommend doing this… it can be triggering since the lists are often made by the sex tourists) for ‘top sex tourism destinations’ most lists will include: cambodia, thailand, indonesia, and the phillipines…   
  
while only \_some\_ list japan as the only east asian country…  
  
anyway. i’m pretty sure that only east asian women are considered to be the 'pure’ ultra feminine types of women, not so much the rest of us.

