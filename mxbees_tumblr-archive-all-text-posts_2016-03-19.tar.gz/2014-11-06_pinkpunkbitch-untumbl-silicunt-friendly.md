---
id: 101919428009
slug: pinkpunkbitch-untumbl-silicunt-friendly
date: 2014-11-06 11:27:03 GMT
tags:
- teh trans community
title: 
---
[pinkpunkbitch](http://pinkpunkbitch.tumblr.com/post/101834073185/untumbl-silicunt-friendly-reminder-that):

> [untumbl](http://untumbl.tumblr.com/post/101650753109/silicunt-friendly-reminder-that-estrogen):
> 
> > [silicunt](http://silicunt.tumblr.com/post/101620242536/friendly-reminder-that-estrogen-doesnt-change):
> > 
> > > Friendly reminder that estrogen doesn’t change your voice so please do not make fun of trans women with non-cis sounding voices vocal training is hard thank you.
> > 
> > This is no joke. So hard. Especially if you’re older.
> 
> Support trans woman who chose not to undertake voice training. Support trans woman with non-cis sounding vocal resonance.

yes….  
  
but  
  
also  
  
can we also just recognize that whatever voice a trans woman has, is a woman’s voice?  
  
like, this is all well an good, but the femininity of my voice isn’t determined by some cis measuring stick.

