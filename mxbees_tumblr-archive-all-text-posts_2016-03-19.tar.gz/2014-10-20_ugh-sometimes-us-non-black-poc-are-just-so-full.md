---
id: 100527807244
slug: ugh-sometimes-us-non-black-poc-are-just-so-full
date: 2014-10-20 21:08:03 GMT
tags:
- antiblackness is real
title: 
---
ugh.

sometimes us non-Black poc are just so full of fail

‘fyi! stop using this symbol by and for Black feminists to represent all feminists!’

but wht about this _other_ symbol?

we suck.

we don’t deserve any of the lovely gifts from the creative and intellectual works that Black women have shared with us.

