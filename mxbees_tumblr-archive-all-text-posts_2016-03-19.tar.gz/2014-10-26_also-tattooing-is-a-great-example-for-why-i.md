---
id: 101025958733
slug: also-tattooing-is-a-great-example-for-why-i
date: 2014-10-26 21:01:32 GMT
tags:
- decolonization nao
- classical biyuti
title: 
---
Also, tattooing is a great example for why I support every call out against every white hipster in a headdress. Or every call out of every single white person with dreads.&nbsp;

Because…&nbsp;

Unless these boundaries are constantly policed, it will become like tattoos (arguable, dreads already are and certainly the ‘mohawk’ style definitely is).&nbsp;

This slow process of trivialization and commodification is exactly how a generally deeply spiritual and culturally meaningful practice like tattooing becomes just the same a 'buying jeans.'&nbsp;

This is how it happens. Look at the history of tattooing in america for a case study in appropriation and cultural colonialism.&nbsp;

Nowadays, basically too late (plus, no one has ever got anywhere telling fiercely individual counter-culture people not to do something).&nbsp;

So, no, I don’t believe there is any point in trying to get white people to stop getting tattoos (although, I’m still willing to battle for culturally appropriative tattoos like Chinese characters, any Indigenous styles, etc.).&nbsp;

But I also don’t think that it serves anyone any good to forget history.&nbsp;

Tattoos are a great cautionary tale.&nbsp;

