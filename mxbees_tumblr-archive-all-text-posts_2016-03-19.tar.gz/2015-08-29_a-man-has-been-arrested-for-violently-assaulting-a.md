---
id: 127877011657
slug: a-man-has-been-arrested-for-violently-assaulting-a
date: 2015-08-29 17:49:34 GMT
tags:
- current events
- transmisogyny
- assault
- violence
title: A man has been arrested for violently assaulting a trans woman in Philadelphia
---
A 53-year-old trans woman is still in the hospital after surviving a violent attack from a man. The same man is thought to have assaulted two other people.

( [Original Source. Trigger Warnings for graphic details of violence, transmisogyny](https://web.archive.org/web/20150829094251/http://www.epgn.com/news/local/9304-suspect-arrested-in-brutal-attack-on-trans-woman))

