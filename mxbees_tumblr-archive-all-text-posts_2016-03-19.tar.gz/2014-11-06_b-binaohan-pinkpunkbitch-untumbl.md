---
id: 101923330014
slug: b-binaohan-pinkpunkbitch-untumbl
date: 2014-11-06 13:16:09 GMT
tags:
- teh trans community
title: 
---
[b-binaohan](http://xd.binaohan.org/post/101919428009/pinkpunkbitch-untumbl-silicunt-friendly):

> [pinkpunkbitch](http://pinkpunkbitch.tumblr.com/post/101834073185/untumbl-silicunt-friendly-reminder-that):
> 
> > [untumbl](http://untumbl.tumblr.com/post/101650753109/silicunt-friendly-reminder-that-estrogen):
> > 
> > > [silicunt](http://silicunt.tumblr.com/post/101620242536/friendly-reminder-that-estrogen-doesnt-change):
> > > 
> > > > Friendly reminder that estrogen doesn’t change your voice so please do not make fun of trans women with non-cis sounding voices vocal training is hard thank you.
> > > 
> > > This is no joke. So hard. Especially if you’re older.
> > 
> > Support trans woman who chose not to undertake voice training. Support trans woman with non-cis sounding vocal resonance.
> 
> yes….  
>   
> but  
>   
> also  
>   
> can we also just recognize that whatever voice a trans woman has, is a woman’s voice?  
>   
> like, this is all well an good, but the femininity of my voice isn’t determined by some cis measuring stick.

ALSO

can we remember that not every trans woman does hormones?

which is why it is even more important to state outright:

every trans woman’s voice is a woman’s voice.

end of story.

