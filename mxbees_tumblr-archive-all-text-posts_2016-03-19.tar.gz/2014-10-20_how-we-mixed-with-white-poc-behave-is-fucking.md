---
id: 100537968424
slug: how-we-mixed-with-white-poc-behave-is-fucking
date: 2014-10-20 23:21:38 GMT
tags:
- race to the bottom
title: 
---
how we mixed-with-white poc behave is fucking embarassing.

we literally act like entitled white ppl. like colonizers.

and \_this\_ too has a history

let’s not pretend for a fucking second like the racial hierarchies set up by our colonizers didn’t explicitely favour those of us who mixed with white ppl

this sort of thing was encouraged and we were rewarded by being given higher social status and material benefits to collude with our colonizers

to literally weild our relative privilege over all the non-mixed poc (or those mixed poc-poc)

this is our history and we’d do well to remember it

