---
id: 106455126989
slug: suddenly-interested-in-thinking-about-the-idea-of
date: 2014-12-28 23:58:20 GMT
tags:
- media musings
title: 
---
suddenly interested in thinking about the idea of werewolves as proxy for autism…

like.

thinking about a lot of the werewolf stories I hear that involve new werewolves and how a lot of their initial problem is all about being overwhelmed and overstimulated by their senses….

and how they have meltdowns and have social problems arising from this….

