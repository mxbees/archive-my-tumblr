---
id: 102642536964
slug: im-so-fucking-mad-about-that-logo-and-the
date: 2014-11-14 22:54:23 GMT
tags:
- teh trans community
title: 
---
i’m so fucking mad about that logo…

and the creator doesn’t really have any info about them on their blog

TDoR isn’t ~trans awareness~ day. gtfo.

and even though the creator of TDoR is a shitty appropriative white trans woman

i’m fucking clinging to it anyway

and no one is going to pry that day

and what it represents

out of my hands.

one day a year for ~teh trans community~

to remember the twoc who died so that

a bunch white assholes can co-opt our oppression

while erasing and ignoring us the other 364 days of the year.

