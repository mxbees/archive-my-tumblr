---
id: 104517568139
slug: seriously-that-chapter-from-whipping-girl
date: 2014-12-06 20:59:34 GMT
tags:
- teh trans community
title: 
---
seriously

that chapter from \_whipping girl\_ today is just….

idk

the fact that she really considers the misrepresentation of indigenous gender systems by white scholars as authoritive is just…

and that she manages to actually claim that, on the basis of these white ppl, that she and other white binary trans ppl are oppressed by the very idea that the binary exists.