---
id: 126537162934
slug: like-that-is-honestly-one-of-the-more-upsetting
date: 2015-08-12 21:58:04 GMT
tags:
- antiblackness is real
- transmisogyny is fun for the whole family
title: 
---
like… that is honestly one of the more upsetting responses i’ve seen to a post in a long long time.&nbsp;

&nbsp;what a fucking way to shit on an elder who’s given her entire life to the community&nbsp;

&nbsp;she fucking got knocked out at stonewall and has been fighting ever since and you know?&nbsp;

&nbsp;there are real reasons why a elder Black trans woman needs ongoing donations.&nbsp;

&nbsp;you think she has ever had enough money to save up for retirement?&nbsp;

&nbsp;jesus fuck.

