---
id: 131451224774
slug: one-of-the-things-i-find-frequently-interesting-is
date: 2015-10-18 23:20:25 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
One of the things I find frequently interesting is how much ppl pushback when I tell them that I’m not an artist. I said this at my first reading, since I was introduced as an artist. I’m not.

By my own standards, I do not think I create art. Nor am I even remotely attempt to create art.

Whatever my writing is, I really don’t think that it qualifies as ‘artistic’. This doesn’t, imo, diminish it or any skills that ppl think I have re: writing. But rather, for me, I don’t write to write, but because I want to communicate.

Writing is just a means to an end.

I consider myself a philosopher. My head is filled with ideas. And I want to share these ideas. Writing is my chosen medium. For all I care, I could be making podcasts, youtube videos, or some other form of communication.

My main goal, when I write a thing, is ensuring that I’ve effectively communicated my ideas.

What I’m saying is that writing is a tool for me, not something I think or care much about otherwise.

