---
id: 117134980839
slug: chrysalisamidst-b-binaohan-like-gay-inc
date: 2015-04-23 02:16:18 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[chrysalisamidst](http://chrysalisamidst.tumblr.com/post/117128960363):

> [b-binaohan](http://xd.binaohan.org/post/117100876414/like-gay-inc-requires-the-labour-and-suffering-of):
> 
> > like Gay Inc requires the labour AND suffering of twoc to maintain itself. they’ll never completely cut us out. not ever. ( [x](http://twitter.com/b_binaohan/status/590945496778301440))
> 
> they need our blood sweat and tears to fuel their shitty 401ks

YES  
  
exactly. twoc are too fucking necessary to Gay Inc for them to entirely cut us out, not when they can exploit us

