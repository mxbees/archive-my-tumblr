---
id: 126541287899
slug: b-binaohan-like-that-is-honestly-one-of-the
date: 2015-08-12 22:58:09 GMT
tags:
- antiblackness is real
- transmisogyny is fun for the whole family
title: 
---
[b-binaohan](http://b-binaohan.tumblr.com/post/126537162934):

> like… that is honestly one of the more upsetting responses i’ve seen to a post in a long long time.&nbsp;
> 
> &nbsp;what a fucking way to shit on an elder who’s given her entire life to the community&nbsp;
> 
> &nbsp;she fucking got knocked out at stonewall and has been fighting ever since and you know?&nbsp;
> 
> &nbsp;there are real reasons why a elder Black trans woman needs ongoing donations.&nbsp;
> 
> &nbsp;you think she has ever had enough money to save up for retirement?&nbsp;
> 
> &nbsp;jesus fuck.

and the saga continues with that piece of shit not even acknowledging how fucked up and shitty that comment was

yes. i’m genuinely upset about this.

i’m not a person who thinks that elders deserve automatic respect.

but Miss Major has earned it.&nbsp;

and some random white person riding on the coat-tails of the revolution she fucking started

being so outright disrespectful and patronizing?

like u actually wrote \_this\_ about one of the stonewall veterans:

> The more you have a desire to make your life feel meaningful and not like an empty shell

you wrote that about a Black trans woman who’s been fighting for us all for over 40 years.

u call urself&nbsp;‘genderflux’&nbsp;

ur ability to be a white enby trash bag is owed directly to HER

she isn’t 73 and still fighting for trans (women of colour) bc she needs to make her life feel meaningful

she’s 73 and still fighting&nbsp;

BECAUSE SHE NEVER STOPPED

she hasn’t made a career out of this. she is literally and purposefully being erased from history and being denied the full weight and power of her legacy.

and ur more concerned with the tone of my reply?

and not feeling the deep shame u should be feeling?

not even recognizing how deeply and utterly u fucked up?

