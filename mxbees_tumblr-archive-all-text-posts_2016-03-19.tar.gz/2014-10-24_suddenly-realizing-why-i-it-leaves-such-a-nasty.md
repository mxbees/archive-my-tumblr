---
id: 100823694469
slug: suddenly-realizing-why-i-it-leaves-such-a-nasty
date: 2014-10-24 12:00:39 GMT
tags:
- ew gross teh menz
title: 
---
suddenly realizing why I it leaves such a nasty taste in my mouth when I read/hear about all these explorations about white masculinity and the crisis of ‘men.’

because beyond the gross as fuck mra shit involved with it and all the zero sum shit it implies

it is always focused on \*white\* men

as if they didn’t already have the most diverse representation in the media

as if they don’t have a wide, wide ranges of self expression and modes of being available to them

as if they aren’t the ones with institutional power to actually change whatever the fuck it is they are bitching about

because these narratives always frame them as 'victims’ of forces larger than them… like capitalism, consumerism, etc, but this is all shit they are actually in charge of.&nbsp;

conclusions? fuck white men’s fucking narcissism and acting as if all the people they are standing on should give a fuck about their problems

