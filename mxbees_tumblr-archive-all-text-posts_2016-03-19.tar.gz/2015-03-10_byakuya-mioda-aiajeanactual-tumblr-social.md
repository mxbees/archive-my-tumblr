---
id: 113260991199
slug: byakuya-mioda-aiajeanactual-tumblr-social
date: 2015-03-10 16:11:28 GMT
tags:
- discussing discourse
title: 
---
[byakuya-mioda](http://byakuya-mioda.tumblr.com/post/112564684992/aiajean-actual-tumblr-social-justice-problems):

> [aiajean](http://aiajean.tumblr.com/post/112457896634/actual-tumblr-social-justice-problems):
> 
> > ## actual Tumblr Social Justice problems:
> > 
> > - antisemitism is often veiled as “combating white supremacy”  
> > - lack of focus on mental illnesses besides depression  
> > - honest mistakes tend to be poorly dealt with  
> > - “callout culture” (people looking for others to mess up, solely in order to defame them)  
> > - in-depth education on terms tends to be scarce, leading to people having only a vague understanding of terms, and using them  
> > - bigots are able to redefine these (poorly-defined) terms in ways that hurt the oppressed  
> > - emotional manipulation / guilt-tripping (“i see my followers ignoring this”; “why is nobody talking about this?”)
> 
> re-reblogging cause i thought of things
> 
> - Excessive and abusive punishment of young teenagers over mistakes made in discourse they don’t completely understand by bloggers much older than they are  
> - US-centrism
> - Reliance on fear of retribution for spread of information (contributes to rapid spread of misinformation)
> - Moral absolutism - the line between “perfect innocent angel” and “disgusting shit trash” can be as thin as one mistake
> - Reliance on followed blogs for education about social issues

ugh. most of the items on this list are garbage.

good points: the anti-Semitism, the reliance on emotional manipulation.

but the rest of it? garbage.

great examole… if u see ‘too much’ stuff on depression and not enough shit about other mental disabilities, at what point do u take responsibility for not following the right ppl? i see plenty of stuff that isn’t about depression. all the time.

99.9% of callout culture critiques are anti-Black and this one is no different.

blaming ppl for being un/der educated. good job. if all u see is shallow analysis then, again, ur following the wrong ppl. what then marks a 'good’ resource? shit off tumblr? something ur professor assigns to you? what? fuck off with this elitism.

teens also don’t get punished excessively. they get punished like anyone else. and this is the problem most ppl have with it. after seeing ppl rally around an abusive, stalking 17 year old just because she was 17 when she was being abusive and literally _stalking_ ppl for _years_ as if her age somehow ameliorates or excuses the harm she caused by her stalking and abuse. someone being 15 doesn’t excuse or give them rights to treat me like sub-human garbage with no consequences.

'us-centric’ again, ur following the wrong ppl if this is true of u.

