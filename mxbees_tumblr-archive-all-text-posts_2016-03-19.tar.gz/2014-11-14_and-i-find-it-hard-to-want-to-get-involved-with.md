---
id: 102641384369
slug: and-i-find-it-hard-to-want-to-get-involved-with
date: 2014-11-14 22:39:00 GMT
tags:
- teh trans community
title: 
---
and i find it hard to want to get involved with what

appears to me to be just petty squabbles between my oppressors

like the ongoing transtrenders/truscum shit that i see

i don’t fucking care, ok?

erica has been pointing out for fucking _years_ that

this is just transsexual seperatism repackaged

or Toni has likewise been great at giving historical perspective

to let us know that this conversation has been happening

over and over and over

again.

so often i see this stuff just bandied about between different white trans ppl

and i’m like….

fuck you all

i hate _both_ sides of this ‘fight’ or whatever the fuck

a PLAGUE on BOTH your HOUSES

