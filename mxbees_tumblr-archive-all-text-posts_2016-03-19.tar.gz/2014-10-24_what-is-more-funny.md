---
id: 100823693489
slug: what-is-more-funny
date: 2014-10-24 12:00:38 GMT
tags:
- i rebuke thee feminism
- race to the bottom
title: what is more funny
---
Is that while [r]dfms try to explain why transmisogyny isn’t a thing or why they should be allowed to be so

In all the things I’ve seen/read/heard about them for the past 30-40 years

has a single one of them&nbsp;

ever actually adequately

addressed early WoC criticisms of their shit being white supremacist?&nbsp;

Because I still haven’t seen any real indication that this is something they’ve tried to address in their movement

It is literally nothing but crickets

(this is also why I rarely bother addressing their transmisogyny myself. it isn’t that it isn’t important – indeed, I do have that post about why their transmisogyny is inherently white supremacist, but that only serves to further highlight that white supremacy is at the very core of what they do and their goals. it is a way for me to address it in ways that side step the arguments already capably made by many an awesome trans woman – their arguments stand and I have nothing really to add to them myself. But also… It almost feels to me like they use transmisogyny as hand waving to distract from their white supremacy. This might also be confirmation bias ‘cause I tend to follow more trans people… but even the tpoc and/or genderescents I follow often address the transmisogyny w/o the white supremacy, even though they are intimately related. but yeah, if anyone can legit point me to a white [r]dfm who even tries to address the white supremacy in the movement, like legit tries w/o invoking 'we are all women’ shit, I will read it. All of it.)

