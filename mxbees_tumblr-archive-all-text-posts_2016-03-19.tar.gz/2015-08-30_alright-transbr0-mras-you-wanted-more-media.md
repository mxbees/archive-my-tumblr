---
id: 127969613306
slug: alright-transbr0-mras-you-wanted-more-media
date: 2015-08-30 20:33:24 GMT
tags:
- current events
- teh trans community
- op
title: 
---
Alright, transbr0 MRAs, you wanted more media attention and now you have it.

Today I read [one story with a trans man in jail for murder](https://web.archive.org/web/20150830101056/http://www.correctionsone.com/corrections/articles/8962358-Maine-county-jail-faces-issues-of-housing-transgender-murder-suspect/) and another [with a trans man accused of attempted murder – of his girlfriend](https://web.archive.org/web/20150830101116/http://denver.cbslocal.com/2015/08/29/transgender-teen-accused-of-attempted-murder-in-car-crash/) (tw: both these stories have some deadnaming and ‘born as’ terminology).

I encourage people to read these stories for themselves.

Read both of them and think about how the media talks about these two trans guys (I’m don’t really want to call a 16 yo a 'man’ since he’s still a kid).

This news coverage isn’t perfect, of course, but…

Anyone else seeing what I’m seeing?

Yeah. These two stories, besides the usual misteps, are more respectful of these trans guys’s genders than most of the stories I’ve seen in the past year about twoc murder victims.

In the first story… do you know how many speculative pieces I’ve read about incarcerated trans women that seriously debate where they should be placed? Lol.

I’m just… so fucking mad about this. I mean. Twoc get less respect and dignity than this when we are murdered. But transbr0s want to talk about how they are being ~erased~ and being rendered ~invisible~.

