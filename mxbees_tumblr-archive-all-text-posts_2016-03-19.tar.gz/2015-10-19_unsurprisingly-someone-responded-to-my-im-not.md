---
id: 131496769415
slug: unsurprisingly-someone-responded-to-my-im-not
date: 2015-10-19 16:55:05 GMT
tags:
- the life of an ordinary bakla
- discussing discourse
- op
title: 
---
Unsurprisingly, someone responded to my ‘i’m not an artist’ post yesterday with a comment that 'art is communication’.

Maybe. Maybe not.

Art can be and is many things. Different people have different understandings of what is and isn’t art.

Note how I phrased my post: **I** don’t think I’m an artist. It isn’t my intent to create and I don’t, in fact, make art.

Do some people create art in order to communicate? Yes. Sure.

But that isn’t me.

Maybe I should get over how much this bugs me, but it does bug me. I don’t want to be an artist because I’m a philosopher. Yes, some people are both, but I am not. And I don’t have to be.

So whatever your personal views about what is or isn’t art, are pretty much irrelevant to me. I get to decide what I do and what I am, not you. What matters is what **my** view of what makes an artist.

Its weird. Whenever people tell me they are artists, I take them at their word. And yet… no one will take me at my word that I’m a philosopher and not an artist.

I don’t get why people are so invested in this (and it isn’t just my unnamed interlocuter). It’s something I bump up against all the time.

