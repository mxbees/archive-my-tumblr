---
id: 102891975854
slug: i-rly-have-to-know-though
date: 2014-11-17 19:32:04 GMT
tags:
- teh trans community
title: i rly have to know though
---
is there _any_ interpretation of

> I wish medical gatekeepers felt a responsibility to also be gatekeepers of community resources.

that isn’t completely shitty?

like

i’m tired and my brain isn’t necessarily being the best info processor right now

but is this as fucked up as it looks to me?????????

