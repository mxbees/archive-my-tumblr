---
id: 103845848309
slug: b-binaohan-er-i-should-keep-my-quiet-re
date: 2014-11-29 00:42:10 GMT
tags: []
title: 
---
[b-binaohan](http://xd.binaohan.org/post/103845637014/er-i-should-keep-my-quiet-re-current-discussion):

> er… i should keep my quiet re: current discussion about Jewish ppl’s oppression
> 
> like i said. too ignorant to discuss it.
> 
> so… yeah.

i try not to open my mouth when i’m ignorant about a thing. i’ll just listen and hold my tongue.

