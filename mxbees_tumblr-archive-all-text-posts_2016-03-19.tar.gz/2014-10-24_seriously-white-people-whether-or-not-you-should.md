---
id: 100823678429
slug: seriously-white-people-whether-or-not-you-should
date: 2014-10-24 12:00:26 GMT
tags:
- race to the bottom
title: 
---
Seriously, white people. Whether or not you should step into any conversation on racism is something you really need to think about.

But in a conversation about and occurring between different PoC groups, you really, really don’t have a place.

And if you are gonna step into the conversation, positioning yourself like you are part of one group or as if you have a right to speak for that group, is pretty gross.

Fucking white people.

