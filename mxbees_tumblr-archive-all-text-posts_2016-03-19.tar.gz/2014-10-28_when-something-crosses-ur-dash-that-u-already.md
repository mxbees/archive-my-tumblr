---
id: 101210789324
slug: when-something-crosses-ur-dash-that-u-already
date: 2014-10-28 23:34:20 GMT
tags: []
title: 
---
when something crosses ur dash that u already wrote a long critique about

and it makes u just as mad as before

but u don’t have the energy to write another critique.

:(

