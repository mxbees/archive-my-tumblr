---
id: 103090613919
slug: omg-how-can-u-say-that-saying-woman-born
date: 2014-11-20 02:46:48 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
omg. how can u say that saying

‘woman born woman’

is trasmisogynist????

r u srs.

:|

