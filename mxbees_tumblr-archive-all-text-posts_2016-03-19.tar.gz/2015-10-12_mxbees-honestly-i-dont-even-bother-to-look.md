---
id: 130986856334
slug: mxbees-honestly-i-dont-even-bother-to-look
date: 2015-10-12 01:04:58 GMT
tags:
- klass with a k
title: 
---
[mxbees](http://mxbees.tumblr.com/post/130983098479):

> honestly. i don’t even bother to look at most of the ‘cruelty free’ ‘ethical’
> 
> makeup/food/whatever
> 
> posts
> 
> it isn’t just that
> 
> ~there is no ethical consumption in capitalism~
> 
> but its just plain exhausting and overwhelming
> 
> beyond the reality that i buy what i can afford, regardless of how ethical it may or may not be
> 
> i simply don’t have the cognitive capacity to remember it all. what do ppl expect us to do when they make a long list of stuff you can/cant buy?
> 
> memorize? print it out?
> 
> are we supposed to see if any/every product we buy can be traced back to some giant conglomerate that is less awful than the others?
> 
> bleh. i’m just a cranky baby tonight.

like. i’m making pretty heavy use of amazon and wish lists these days bc i’m fucking poor and ppl are buying me stuff like allergy pills or shampoo.

amazon is notorious for their unbelievably shitty labour practices.

not even getting into what i do ask for via [my wishlist](http://www.amazon.ca/gp/registry/wishlist/28BSS39ES50S9/)

its helping keeping me afloat.

someone just bought me a year’s supply of my over-the-counter allergy medicine. i think i usually spend about… idk, $30/month on that stuff? on top of the three prescriptions i have for managing my allergies?

like. obviously i don’t want the (mostly likely) poc being exploited in amazon’s warehouses to work under their current conditions. but.

as i was saying before about the instant noodles and destroying the environment thing…

as far as i can tell, these ppl just want me to die so fuck them anyway.

