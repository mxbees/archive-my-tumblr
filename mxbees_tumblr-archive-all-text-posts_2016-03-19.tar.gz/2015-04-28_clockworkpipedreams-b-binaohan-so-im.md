---
id: 117601135129
slug: clockworkpipedreams-b-binaohan-so-im
date: 2015-04-28 13:17:11 GMT
tags:
- antiblackness is real
title: 
---
[clockworkpipedreams](http://clockworkpipedreams.tumblr.com/post/117599425670/b-binaohan-so-im-seeing-a-lot-of-stuff-about):

> [b-binaohan](http://xd.binaohan.org/post/117597982724/is-there-a-reason-why-you-arent-putting-tws-on):
> 
> > so i’m seeing a lot of stuff about baltimore on my tumblr dash… ( [x](http://twitter.com/b_binaohan/status/593023183529385984)) and i have question for non-Black ppl talking about it. ( [x](http://twitter.com/b_binaohan/status/593023245504352257)) is there a reason why you aren’t putting TWs on your lurid, graphic descriptions of how Freddie Gray was murdered? ( [x](http://twitter.com/b_binaohan/status/593023403294105600))
> 
> I do not tag stuff related to police brutality against black people as there were several posts that went around asking people to stop tagging it all, so that white folks would not be able to ignore it being on their dashes by just using tumblr saviour. Though yeah, I do also try to avoid stuff that is particularly graphic (esp. any images of dead bodies) to try and avoid making black suffering into a spectacle but I dunno how well I’m doing at finding the balance on that?
> 
> About half of the black folks I follow tag it and the other half don’t so like, if any black followers have a strong preference either way then do let me know.

i’m not necessarily talking about stuff ppl are reblogging or using tags.

i’m really talking about nonBlack ppl who are _writing_ posts with graphic descriptions of violence against Black people without any kind of trigger warning. doesn’t have to be in the tags.

like… i can partly see the point being made that tagging stuff makes it easier for white/nonBlack ppl to stick our heads in the sand and just tumblr saviour, but

i have to say that prioritizing the mental health and safety of my Black friends (most of whom do ask that graphic images and description are tagged or trigger warned) is more important than using Black bodies as a tool to raise awareness for nonBlack ppl.

and my comment was directed to nonBlack ppl only.

Black people can discuss violence against them however they’d like, with or without trigger warnings. not my place to say anything.

like beyond the fact that nonBlack ppl shouldn’t really be contributing ‘original’<sup id="fnref:p117601135129-1"><a href="#fn:p117601135129-1" rel="footnote">1</a></sup> content when Black ppl are already saying everything that needs to be said, if we absolutely _must_ say something, it should prioritize Black ppl’s health and safety.

like… engaging in the hyper-consumption and sensationalization of Black death (and life) is something that we, a nonBlack ppl, need to be SUPER careful about. _we_ have no need to write graphic descriptions (or post pictures) of violence against Black ppl.

(and like also. i think if ur the kind of asshole nonBlack person who’ll try to tumblr savior urself out of seeing or knowing anything about violence against Black ppl, ur so deeply embedded and complicit with antiBlackness that ur the problem and when the revolution comes, u’ll be up against the wall)

* * *

1. 

of course by 'original’ i mean sanitized and regurgitated&nbsp;↩

