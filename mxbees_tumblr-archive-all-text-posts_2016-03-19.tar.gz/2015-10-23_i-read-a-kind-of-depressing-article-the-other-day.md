---
id: 131754860649
slug: i-read-a-kind-of-depressing-article-the-other-day
date: 2015-10-23 16:43:05 GMT
tags:
- able ability
- the life of an ordinary bakla
- op
title: 
---
i read a kind of depressing article the other day. it pretty much suggests that i’m not going to qualify for disability bc it would be hard to sufficiently demonstrate that i’m disabled enough to need the support.

it was an article about bias and stuff for my specific province. while it was focused on what they called ‘episodic’ disabilities (defined as long-term disabilities that have some periods of flareups and some periods of feeling relatively 'well’ – in comparison to the bad days).

like one of the participants had hep c and cirhosis. and while she had some 'good days’ she also had bad days. and she wasn’t able to qualify for assistance.

in part bc of capitalist bullshit. even though they are supposed to consider you ableness to do work, self-care, and participate in the community, they really only care if you can work. if you can work, even if it means that it is literally the _only_ thing you’re capable of doing, you won’t qualify. heck even if you’re only able to work on your good days, you won’t qualify. doesn’t matter how many times you have bad days/periods that result in a lost job. just go on welfare or whatever.

so i guess that’s that. i mean. i sort of knew that while i have my current job they probably wouldn’t. so. i guess we’ll have to wait until i loose this one and see what happens.

its frustrating bc i know that bc i’ve done certain things and i 'might’ be considered to be high functioning/successful bc of these things…

the state doesn’t care if i ruined my mental health in the process of doing those things. doesn’t care if when i work at that level, i’m pretty much incapable of taking care of myself or 'participating in the community’. the state only cares about the capital in can extract from my labour.

(i shouldn’t be this surprised, tbh.)

