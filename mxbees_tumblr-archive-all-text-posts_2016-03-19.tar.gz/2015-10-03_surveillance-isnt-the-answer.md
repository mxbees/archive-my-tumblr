---
id: 130414819162
slug: surveillance-isnt-the-answer
date: 2015-10-03 17:49:37 GMT
tags:
- teh trans community
- discussing discourse
- op
title: surveillance isn't the answer
---
Recently, Laverne Cox has been in the news for calling out the US Census (I think) for not counting trans people in the US.

It isn’t that I think she’s wrong, exactly, but that ideologically, I don’t think this is the solution to teh communities problems.

Yes, I know that the _Injustice at Every Turn_ report has been massively influential in terms of policy within the US because it provides much needed data for a world increasingly driven by data (and being encouraged to push data-driven solutions). I also understand that data and demographic data is frequently used to justify or provide cause for certain communities to be allocated (artificially scarce) resources.

As a short term, immediate, and pragmatic goal, yes, I agree with Ms. Cox.

However, in a longer term, ‘let’s get free’ sense, I really want to say this:

State surveillance isn’t the answer we are looking for.

