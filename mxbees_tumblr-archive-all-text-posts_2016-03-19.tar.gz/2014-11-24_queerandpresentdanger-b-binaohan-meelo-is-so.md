---
id: 103499957789
slug: queerandpresentdanger-b-binaohan-meelo-is-so
date: 2014-11-24 23:48:18 GMT
tags:
- media musings
title: 
---
[queerandpresentdanger](http://queerandpresentdanger.tumblr.com/post/103497758394):

> [b-binaohan](http://xd.binaohan.org/post/103496519034/meelo-is-so-irritating-i-hate-u-his-misogyny):
> 
> > meelo is so irritating.
> > 
> > i hate u
> > 
> > his misogyny really isn’t cute.
> 
> omg this is all i can think while watching the new episodes  
>   
> especially because like, sokka’s misogyny in a:tla seemed intentional and purposeful and the writers addressed it promptly and continuously??? but meelo’s is apparently just like, endearing and comedic relief???   
>   
> nope fuck u meelo

yeah. like… sokka (esp during the Keyoshi warrior thing) def. gets called out on his misogyny  
  
but meelo is just.. yeah. ‘cute’ and so no one really cares.   
  
like not even his sister’s act like i remember of my big sister… like. literally no way she’d let me get away with that sort of thing as a kid.

