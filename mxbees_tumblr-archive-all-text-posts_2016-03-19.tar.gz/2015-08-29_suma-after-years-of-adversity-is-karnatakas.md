---
id: 127898084435
slug: suma-after-years-of-adversity-is-karnatakas
date: 2015-08-29 23:16:49 GMT
tags:
- current events
- india
- twoc thriving
title: Suma, after years of adversity, is Karnataka's first trans college student
---
> Lot of courage and struggle by Suma M, 26-year-old transgender has finally been fruitful as Suma is in the grounds of St Joseph evening college becoming the state’s first transsexual student. Struggle, hard work, harassment, torture, rape are not mere simple terms for Suma M, who is pursuing a bachelors in Journalism, Political Science and Sociology (J.P.S) at the college in Bangalore.

( [Original Source. Trigger Warnings for rape, abuse, discrimination, bullying](https://archive.is/YBWkM))

