---
id: 103078033429
slug: i-feel-somewhat-conflicted-about-the-whole-phobia
date: 2014-11-19 23:58:10 GMT
tags:
- able ability
- mayo is as mayo does
title: 
---
I feel somewhat conflicted about the whole -phobia is ableism thing

like I get the argument

im just “meh” about it.

for a while I replaced phobia with hate. and it works.

but just meh.

what annoys me more is the general white disability approach of telling me what I can and.cant say.

I remember that white person who tried to call me out over it and I was like… fuck u. I have a debilitating phobia so go away.

