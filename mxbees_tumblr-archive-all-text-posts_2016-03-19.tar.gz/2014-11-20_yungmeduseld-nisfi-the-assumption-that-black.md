---
id: 103147631584
slug: yungmeduseld-nisfi-the-assumption-that-black
date: 2014-11-20 21:29:15 GMT
tags:
- antiblackness is real
- i'm not black
title: 
---
[yungmeduseld](http://yungmeduseld.tumblr.com/post/103147433174/nisfi-the-assumption-that-black-people-need-to):

> [nisfi](http://nisfi.tumblr.com/post/103146815789/the-assumption-that-black-people-need-to-produce):
> 
> > the assumption that Black people need to produce some sort of “evidence” of their abuse from nonblack people of color is inherently antiblack. antiblackness is insidious and oftentimes nuanced. why is it necessary for Black people to always provide us with “receipts”? is it so impossible for us to just take a person’s word for it on their own oppression? which we ourselves expect of others many times?
> 
> No because that means there’s a narrative that y’all ain’t in control of; much like how nonBlack people specifically try to control and feel entitled to Black intellectual property and energy. It would mean admission that they benefit from something that only Black people can define.

note to the anon who asked me about ‘receipts’ for darkmatterrage after i posted the tweet.

