---
id: 127965606464
slug: they-treat-us-like-were-in-prison-there-are-no
date: 2015-08-30 19:38:54 GMT
tags:
- current events
- immigration
- detention
- rape
title: They treat us like we're in prison - there are no human rights here.
---
(tw: rape and abuse by ICE)

> “I have never been in jail before,” Natalia said, her voice trembling as tears fell slowly down the side of her face onto an orange jumpsuit.
> 
> She had been raped by two men near the border in Tijuana only weeks before entering the United States to seek asylum, she explained. But after fleeing to the U.S. after repeated sexual assaults in Mexico, she was detained by Immigration and Customs Enforcement (ICE) at the Santa Ana City Jail in Southern California, in a segregated “housing pod” for gay men and transgender women.
> 
> “I said to God on the day I was raped in Tijuana, the only thing worse that could happen to me now is to end up in prison,” she said. “They treat us like we’re in prison – there are no human rights here.”

( [Original Source. Trigger Warnings for rape, detention, institutional abuse](https://web.archive.org/web/20150830105418/http://www.msnbc.com/msnbc/trapped-detention-transgender-immigrants-face-new-traumas))

