---
id: 127803844647
slug: arianna-evans-the-iconic-child-of-hurricane
date: 2015-08-28 18:44:18 GMT
tags:
- current events
- transmisogynoir
- dead naming
- born as
title: Arianna Evans, the iconic child of Hurricane Katrina, ten years later
---
Arriana Evans was 9 years old when her plea for aid in Katrina put a human face on the suffering and destruction left in the hurricane’s wake.

Ten years later, at age 19, Ms. Evans has stepped into herself as a young Black trans woman. Her story and life continue to inspire.

( [Original Source. Trigger warnings for deadname, sensationalist reporting, transmisogynoir, transmsiogyny, Hurricane Katrina, abuse, video in link](http://www.nbcnews.com/storyline/hurricane-katrina-anniversary/hurricane-katrina-10-years-later-part-i-charles-evans-tragedy-n415256?cid=sm_tw&hootPostID=01c00cc4f7d95958f1a058471cec9200))

