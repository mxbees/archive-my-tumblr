---
id: 131955437329
slug: im-thinking-about-putting-up-a-picture-of-me-from
date: 2015-10-26 15:44:26 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
i’m thinking about putting up a picture of me from 7 years ago or something.

one where i’m at my most butch, as far as gender presentation.

maybe making it my avatar for a while just to see how many ppl will invalidate my identity.

but also.

bc now that i’m sharing pictures of myself.

i can use the side-by-side thing that some ppl do (you know the ‘before’ and 'after’) as a way illustrate one of the points i’ve been making for some time now.

bc one of the things i’ve said is that for me, being bakla, encompasses me at every stage of my life. from me with a beard to me now. that i’ve never 'come out’ bc i’ve always been my 'authentic’ self.

hmm….

