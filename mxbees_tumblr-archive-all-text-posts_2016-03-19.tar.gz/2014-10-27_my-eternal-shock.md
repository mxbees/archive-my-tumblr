---
id: 101113474395
slug: my-eternal-shock
date: 2014-10-27 21:01:40 GMT
tags:
- decolonization nao
- classical biyuti
title: my eternal shock
---
I don’t know why it keeps surprising me, but I’m only human I guess.&nbsp;

But the lengths people will go not to acknowledge one really basic fact: we are human.&nbsp;

White people always want these programmatic set of rules to follow so that they can approach us, hang with us, work with us, know us.&nbsp;

But…&nbsp;

There are no rules. We are individuals. Approach us as such. We aren’t mysterious, strange, wondrous creatures beyond your understanding (well, not all of us :P).

We are human.&nbsp;

WE ARE HUMAN!!!!

Fuck.&nbsp;

Once you take this radical step and acknowledge our humanity.&nbsp;

You’ll realize that. You don’t need a complicated ritual to get to some of us. Some you might.&nbsp;

It is almost always easy to tell which white people actually think we are human. They are the ones that let us be flawed, complex people. They understand this. This means you cannot know us all.&nbsp;

Stop trying to figure us out. Make \*friends\* not comrades. I’m terrible at making friends but I still have a few. And I know that the path I took with each of them was as unique as two people creating something new and beautiful can be.&nbsp;

sigh

