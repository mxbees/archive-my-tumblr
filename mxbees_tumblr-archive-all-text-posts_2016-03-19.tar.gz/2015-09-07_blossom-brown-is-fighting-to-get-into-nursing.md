---
id: 128587566493
slug: blossom-brown-is-fighting-to-get-into-nursing
date: 2015-09-07 21:27:49 GMT
tags:
- current events
- nursing
- education discrimination
title: Blossom Brown is fighting to get into nursing school
---
> Blossom Brown said she’s been unfairly rejected six times.
> 
> “People always say, ‘You’re going to confuse the patients,’ or, 'We don’t want your kind here,’” Brown said.
> 
> Brown said the fact that she’s a transgender woman has held her back.

( [Original Source. Trigger Warnings for systemic discrimination](http://web.archive.org/web/20150907142732/http://www.wapt.com/news/central-mississippi/transgender-woman-fights-to-get-into-nursing-school/35133822))

