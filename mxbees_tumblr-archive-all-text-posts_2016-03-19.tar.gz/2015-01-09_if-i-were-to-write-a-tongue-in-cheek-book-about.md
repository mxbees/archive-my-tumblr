---
id: 107590103479
slug: if-i-were-to-write-a-tongue-in-cheek-book-about
date: 2015-01-09 11:51:13 GMT
tags: []
title: 
---
if i were to write a tongue in cheek book about racism, i might do something like _how the Filipin@s became Asian_ or something of that sort

