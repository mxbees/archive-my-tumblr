---
id: 102735950714
slug: actually-considering-making-this-for-the-first
date: 2014-11-16 00:40:15 GMT
tags:
- life of an ordinary bakla
title: 
---
actually considering making this

(for the first time ever)

my ‘main’ blog

…

we’ll see!

