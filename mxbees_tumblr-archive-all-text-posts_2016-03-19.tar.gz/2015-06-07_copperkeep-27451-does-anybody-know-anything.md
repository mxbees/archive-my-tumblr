---
id: 120942026094
slug: copperkeep-27451-does-anybody-know-anything
date: 2015-06-07 15:55:39 GMT
tags:
- tech support
title: 
---
[copperkeep](http://copperkeep.tumblr.com/post/120937518176/27451-does-anybody-know-anything-about):

> [27451](http://27451.tumblr.com/post/120937409238/does-anybody-know-anything-about-indexhibit-or-web):
> 
> > does anybody know anything about indexhibit or web hosting i am so out of my depth it is amusing
> 
> Anyone?

what sort of questions do you have?  
  
i know about hosting and stuff, not so much indexhibit.

