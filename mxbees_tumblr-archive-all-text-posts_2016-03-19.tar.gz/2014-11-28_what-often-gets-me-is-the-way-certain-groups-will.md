---
id: 103800747234
slug: what-often-gets-me-is-the-way-certain-groups-will
date: 2014-11-28 12:54:00 GMT
tags:
- discussing discourse
- epilepsy warning
- gif warning
- gifset
title: 
---
what often gets me is the way certain groups will frame their oppression as racism

even though their oppression actually predates racism

as if racism is the only/most valid oppression

how do i history?

![](https://38.media.tumblr.com/091c50d748ad9743b761353dfbea193e/tumblr_inline_nfr2kdRgeU1rdzs46.gif)

