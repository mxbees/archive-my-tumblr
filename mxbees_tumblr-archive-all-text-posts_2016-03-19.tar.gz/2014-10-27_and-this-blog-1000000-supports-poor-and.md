---
id: 101044084524
slug: and-this-blog-1000000-supports-poor-and
date: 2014-10-27 00:44:09 GMT
tags:
- surviving is a communal activity
title: 
---
and this blog 1000000% supports poor and struggling iaopoc

who seek donations for fun ‘frivolous’ things like gameboys

manicures

chocolate

whatever the fuck

i would buy u all pizza or comfort food of choice if i could

