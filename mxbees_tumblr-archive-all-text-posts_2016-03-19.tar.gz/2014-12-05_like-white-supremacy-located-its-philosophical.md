---
id: 104443235824
slug: like-white-supremacy-located-its-philosophical
date: 2014-12-05 23:25:15 GMT
tags:
- race to the bottom
title: 
---
like…

white supremacy located its philosophical , political, and historical roots in Greece

like, literally the cradle of white civilization

and they did this, in part to, because they didn’t want to credit Arabic ppl with bringing them out of the dark ages

Greeks are white

whitest of the whites

white supremacy isn’t about skin colour and Greeks have been more than happy to claim the privileges of whiteness

