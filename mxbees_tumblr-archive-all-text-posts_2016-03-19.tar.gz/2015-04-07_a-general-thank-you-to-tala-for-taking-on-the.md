---
id: 115794692899
slug: a-general-thank-you-to-tala-for-taking-on-the
date: 2015-04-07 21:58:46 GMT
tags:
- yungmeduseld
- accountability post
- antiblackness is real
title: 
---
a general thank you to Tala for taking on the emotional labour of calling me out for anti-Blackness re: appropriating aave.

thanks so much.

you’re a really treasured friend and i appreciate you.

