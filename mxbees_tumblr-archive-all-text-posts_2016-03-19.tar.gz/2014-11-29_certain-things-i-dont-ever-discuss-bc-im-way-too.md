---
id: 103844578589
slug: certain-things-i-dont-ever-discuss-bc-im-way-too
date: 2014-11-29 00:23:20 GMT
tags:
- the life of an ordinary bakla
- accountability post
title: 
---
certain things i don’t ever discuss bc i’m way too fucking ignorant on the subject to even want to make even the smallest comment

things like antisemitism?

i know pretty much nothing beyond that Jewish people are oppressed.

that is the full extent of my knowledge tbh

