---
id: 102412115929
slug: im-really-tired-of-stalwart-stoic-heroes
date: 2014-11-12 01:59:01 GMT
tags:
- media musings
title: 
---
im really tired of stalwart, stoic heroes

(always played by white men of course)

im tired of that torture trope where the white hero is tortured but holds out and stays strong and doesnt break or appear to suffer any serious effects.

it isn’t just that I want vulnerable heroes.

(and heroes who arent white men, of course)

i want heroes that are more than just vulnerable.

i want human ones that break, struggle to recover, relapse, and maybe just stay broken but find triumph, victory, and maybe some love.

essentially…

i want heroes i could actually identify with once in a while.

