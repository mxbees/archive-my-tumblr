---
id: 105201849429
slug: yungmeduseld-b-binaohan-yungmeduseld-a
date: 2014-12-14 20:30:17 GMT
tags:
- teh trans community
- mayo is as mayo does
title: 
---
[yungmeduseld](http://yungmeduseld.tumblr.com/post/105193308504/b-binaohan-yungmeduseld-a-lot-of-times-i):

> [b-binaohan](http://xd.binaohan.org/post/105189361304/yungmeduseld-a-lot-of-times-i-read-these-trans):
> 
> > [yungmeduseld](http://yungmeduseld.tumblr.com/post/105187062684/a-lot-of-times-i-read-these-trans-posts-and-am):
> > 
> > > A lot of times I read these trans posts and am left with the hollow feeling of “This sounds like something a white woman would write….”
> > 
> > hahahaa  
> >   
> > this is me
> 
> Like people forget that there’s white transgender feminism, and it’s just as toxic to PoC (especially those who experience transmisogyny) as ever.

how’s this for white transfeminism???

i just found out a little while back that ‘trans feminism’ was actually coined by Emi Koyama, who is you know _not_ a white trans woman.

but she also gets super bullied in the community (as well as just generally ignored)

but i don’t think i’ve seen a single white trans feminist ever mention who they even owe that framework to

