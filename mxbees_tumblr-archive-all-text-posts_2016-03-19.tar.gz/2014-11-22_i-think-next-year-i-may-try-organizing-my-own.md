---
id: 103280163974
slug: i-think-next-year-i-may-try-organizing-my-own
date: 2014-11-22 14:09:48 GMT
tags:
- the life of an ordinary bakla
title: 
---
i think next year… i may try organizing my own tdor thing. something super small but make it a potluck so we can provide a seriously awesome feast for the departed.

i’d want to make it entirely unlike any other tdor thing i’ve seen. idk.

we’ll see…

