---
id: 103496519034
slug: meelo-is-so-irritating-i-hate-u-his-misogyny
date: 2014-11-24 23:03:11 GMT
tags:
- media musings
title: 
---
meelo is so irritating.

i hate u

his misogyny really isn’t cute.

