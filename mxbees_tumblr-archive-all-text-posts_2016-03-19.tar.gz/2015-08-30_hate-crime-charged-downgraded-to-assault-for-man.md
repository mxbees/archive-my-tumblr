---
id: 127901436841
slug: hate-crime-charged-downgraded-to-assault-for-man
date: 2015-08-30 00:11:16 GMT
tags:
- current events
- transmisogyny
- racialized transmisogyny
- assault
- violence
title: Hate crime charged downgraded to assault for man who attacked Nicole
---
> McFadden is accused of attacking a transgender woman named Nicole on Monroe Avenue. Nicole told us she was targeted because she is transgender and a person of color.

However, McFadden claims that Nicole started the argument.

( [Original Source. Trigger Warnings for transmisogyny, violence, racialized transmisogyny](https://web.archive.org/web/20150829101601/http://www.whec.com/article/stories/S3889479.shtml?cat=12713))

