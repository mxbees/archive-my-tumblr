---
id: 128420921313
slug: according-to-dana-beyer-only-white-ppl-matter-in
date: 2015-09-05 18:44:18 GMT
tags:
- current events
- history
- white trans women being garbage
title: according to dana beyer, only white ppl matter in history
---
She asks this question in the subtitle “who gets to dictate the story of trans history?” and her clear answer is: white women like her.

She’s responding to a profile of a different crusty white trans woman, like her, and the… ommissions of history and nuance or somethat that she perceives:

> Not because it’s inaccurate in its details; because it is grossly incomplete in its roll call of players and the diversity of the movement, and a product of what today we would call the trans establishment

So far I’m like… I still hate this lady but maybe this article won’t be complete garbage and then…

> An exemplar of such a whitewashing is an earlier gross co-optation of trans history, in this case by the gay establishment

I’m still going ‘ok, sure’ and thinking that just _maybe_ she’ll go on to discuss the recent outcry against the erasure of twoc and tpoc in the Stonewall movie’s trailer….

Alas. No. It appears that by 'white washing’ she actually means gays coopting the story of a white trans woman. That’s a super _fascinating_ conception of white washing.

She goes on to praise and locate 'tran history’ in the doings of various trans\*nationalist organizations and leaders. Also mentions how great and important TDoR is……

> Finally, what was arguably (I admit as a physician I’m a bit biased) the most important advance in trans history, the re-categorization of being transgender in the DSM 5 from a mental illness to a natural variation

Um… this is more than a 'little’ biased. This is pretty much bullshit.

And then we delve into the territory of bitter irony…

> my experience in Maryland, where the gay community often undeservedly claimed credit for trans work, has already shown that remaining silent while certain segments of the community raise their voices to claim credit when it’s not due can lead, by neglect, to an ossified narrative that’s hard to repair

lolsob. i can’t I just… can’t. even. fucking. deal. with. this. level. of. cognitive. dissonance.

You know who she never _once_ mentions in this recounting of ~important~ trans history? Sylvia Rivera, Marsha P. Johnson, Rita Hester, Janet Mock, Laverne Cox or _any_ person of colour of any kind. She thinks that the DSM change is more important, historically, than _stonewall_. Like… wtf are you even on lady? Literally every contemporary 'victory’ in trans rights (and gay rights) starts from there.

Which is interestingly, the most galling example of “the gay community often undeservedly claim[ing] credit for trans work” resulting in an “ossified narrative that’s hard to repair”. Lololololol.

> They say – to paraphrase Orwell, Benjamin, Nkrumah, Napoleon, Pliny, etc. – that history is written by the victors. We’re all winning, so let’s get it right from the start.

And then this… What I take away from this article and how she concludes it is that 'we = white trans women (or men, I guess)’ and that since 'we’re all winning’ this is why white trans women like her get to write history and erase the contributions of twoc/tpoc? How very fucking convenient.

(especially since, i don’t think by _anyone’s_ honest estimation can trans women of colour be said to be 'winning’ atm. like. fuck you entirely)

( [Original Source. Trigger Warnings for erasure, white supremacy](http://web.archive.org/web/20150905103428/http://www.huffingtonpost.com/dana-beyer/history-is-written-by-the_b_8084404.html))

