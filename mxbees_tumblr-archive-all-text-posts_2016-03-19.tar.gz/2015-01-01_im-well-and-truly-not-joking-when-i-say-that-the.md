---
id: 106758198369
slug: im-well-and-truly-not-joking-when-i-say-that-the
date: 2015-01-01 01:50:42 GMT
tags:
- the life of an ordinary bakla
title: 
---
i’m well and truly not joking when i say that the response i’m seeing to Leelah’s death is making me feel crazy

like.

i m

depressed. i struggle with other mental illness. i’ve been abused.

this feels like some kind of… mass gaslighting bc barely anyone is seeing things that i’m seeing

(except for the few. and u know who u are)

like.

is this all real?

i hope when i wake up tomorrow the world makes a little more sense.

bc. fuck.

is this ever not a world i want to be living in myself.

