---
id: 114078423909
slug: ill-say-it-as-much-as-needed-though-trans
date: 2015-03-19 22:18:02 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
I’ll say it as much as needed though.

Trans women, should we have penises, are not privileged because of them. Not ever.

Not even a little bit.

So be careful when trying to talk about “people with penises” as if cis men and trans women with penises EVER share some common privilege.

Now \_that\_ is classic transmisogyny.

