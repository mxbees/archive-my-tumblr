---
id: 105764531589
slug: amazighprincex-the-fact-that-the-gender-binary
date: 2014-12-21 09:58:06 GMT
tags:
- decolonization nao
- antiblackness is real
- misogynoir
title: 
---
[amazighprincex](http://amazighprincex.tumblr.com/post/99131174501/the-fact-that-the-gender-binary-is-a-european):

> the fact that the gender binary is a European invention that was forced on the rest of the world through colonialism and unspeakable violence means that it’s pretty much impossible for people of colour to be cis / benefit from cisness as a structure in the same way or to the same extent that white people do, and if you’re a white trans person you really need to keep your race at the forefront of your mind when discussing transness

the way this works, imo, is that ‘binary’ iaopoc are only privileged over nb/trans iaopoc.   
  
bc as we can note from the way, for example, that 'binary’ Black women are ungendered ALL THE TIME as part of their experience of having a 'binary’ gender  
  
we start to see the impact of this colonial imposition, since even 'binary’ iaopoc genders are less legitimate than white ones (binary or not)

