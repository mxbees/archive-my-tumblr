---
id: 131891491619
slug: hoodoodyke-thisisantiasianracism-mxbees
date: 2015-10-25 17:49:54 GMT
tags:
- accountability post
title: 
---
[hoodoodyke](http://hoodoodyke.tumblr.com/post/131831431084):

> [thisisantiasianracism](http://thisisantiasianracism.tumblr.com/post/131827445165):
> 
> > [mxbees](http://mxbees.tumblr.com/post/131818304564):
> > 
> > > [mxbees](http://mxbees.tumblr.com/post/131804021754):
> > > 
> > > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131795136292):
> > > > 
> > > > > [j-aeflawless](http://j-aeflawless.tumblr.com/post/131794797266):
> > > > > 
> > > > > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131793955202):
> > > > > > 
> > > > > > > [tenacious-dingo](http://tenacious-dingo.tumblr.com/post/131793597080):
> > > > > > > 
> > > > > > > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131791261662):
> > > > > > > > 
> > > > > > > > > [thisisnotpilipinx](http://thisisnotpilipinx.tumblr.com/post/131790682622):
> > > > > > > > > 
> > > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131788837004):
> > > > > > > > > > 
> > > > > > > > > > > [wandamaxifuckoff](http://wandamaxifuckoff.tumblr.com/post/131787741317):
> > > > > > > > > > > 
> > > > > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131732201999):
> > > > > > > > > > > > 
> > > > > > > > > > > > > [wandamaxifuckoff](http://wandamaxifuckoff.tumblr.com/post/131719498987):
> > > > > > > > > > > > > 
> > > > > > > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131627684869):
> > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > [glowingnectar](http://glowingnectar.tumblr.com/post/131624043727):
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > [luvallstuff](http://luvallstuff.tumblr.com/post/131383472032):
> > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > [slanteyechink](http://slanteyechink.tumblr.com/post/131375159539):
> > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > even media that is SUPPOSEDLY&nbsp;“”&nbsp;“”&nbsp;“””””&nbsp;“”&nbsp;“”””&nbsp;“&nbsp;“’ proggressive”””&nbsp;“””””&nbsp;“””” has no fucking clue how to write asian people
> > > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > steven universe? fucking tiger mom stereotype whose shy daughter wants to BREAK FREE!!!! from ((also i get a real weebish vibe from this show which is partially why i couldn’t get into it…. like connie isn’t even japanese and yet she says&nbsp;“itadakimasu” before a meal??? not cute.))
> > > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > how to get away with murder? yah oliver’s a little cinnamon roll but why is he the hacker genius.
> > > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > brooklyn 99? again, hacker genius asian episode (and there was one that had a&nbsp;“filipino bieber” joke like ?? ????? ok??)
> > > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > orange is the new black? this is the show that had an episode titled&nbsp;“ching chong chang” i don’t think i have to explain any further (there’s also numerous articles about its anti asian racism but you get the idea)
> > > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > i’ve explained the issues with mulan and bh6 more times than i can count like i honestly should be compensated for this.
> > > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > > i mean it’s really fucking annoying how deep rooted in anti asian racism a lot of media is even the ones tumblr loves to hail as progressive, the pinnacle of DIVERSITY!!!!!!!!!!!!!!! !!! !!!!!!! and people just ignore it. even asian-americans for whom it’s IMPOSSIBLE to even be visible. like we literally cannot find asian characters that don’t have some glaring stereotype attached to them and i’m done with it.
> > > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > > Sense8 even. Sun is a Korean martial artist suffering at the hands of patriarchy. Very stereotypical
> > > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > > Should I even mention Dong’s role in The Unbreakable Kimmy Schmidt?
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > a lot of people have added comments like this to my post or left me asks like “oh man i didn’t realize” and it’s kind of jarring how obviously racist things to us didn’t occur to others until they read this
> > > > > > > > > > > > > > > 
> > > > > > > > > > > > > > > like this isn’t me being mad (because i definitely don’t recognize a lot of stereotypes from other groups im not a part of) but it’s super telling how prevalent this kind of racism is
> > > > > > > > > > > > > > 
> > > > > > > > > > > > > > i thought oliver was filipino tho
> > > > > > > > > > > > > 
> > > > > > > > > > > > > yes  
> > > > > > > > > > > > >   
> > > > > > > > > > > > > now if you look closely at a world map, on what continent would you find the philippines?
> > > > > > > > > > > > 
> > > > > > > > > > > > wow, mon ami, i just meant its normally considered a part of oceania, which some consider different. but go ahead keep criticizing people for making mistakes because that will FOR SURE get people to listen to your opinions.
> > > > > > > > > > > 
> > > > > > > > > > > [@thisisnotpilipinx](http://tmblr.co/muyXrURuizuGZbpEMcrNodw) if you can take this
> > > > > > > > > > 
> > > > > > > > > > wandamaxifuckoff The philippines aint a part of oceania… Its part of Asia. Its part of southeast asia to be specific. We’re not pacific islander/micronesian/macronesian…   
> > > > > > > > > > -admin Kim Celine
> > > > > > > > > 
> > > > > > > > > [@wandamaxifuckoff](http://tmblr.co/m-rk12PgPXcvIm_5mvMr9Kw) i want u to see this because i want u to know that u are terribly terribly wrong… I’d like to know who u know that considers the philippines as part of oceania because i’d like to correct them too.
> > > > > > > > 
> > > > > > > > Papua New Guinean citizen of Filipino heritage here. The Philippines is Asian. We’ve always considered it Asian. I’ve gotten points off for writing about the Philippines when asked to write about current events in Oceania. All my geography classes in PNG had the Philippines down as an Asian country. I still remember getting side-eye from my PNGean friends for implying the Philippines was a Pacific nation. And if nothing else, I live in the Philippines and here it’s also considered Asian.
> > > > > > > > 
> > > > > > > > I actually never heard about the&nbsp;“it’s a Pacific Island/part of Oceania/Polynesia/etc” argument until a few years ago and it’s still kinda baffling. I mean, Southeast Asia is a thing.
> > > > > > > 
> > > > > > > Thanks for the commentary!  
> > > > > > > -admin Kim Celine
> > > > > > 
> > > > > > as a filipino citizen born and raised and currently living in the philippines, yes, filipinos are asians, specifically south east asians. we are part of a group with other south east asian nations called ASEAN. we share the same ethnic roots as other SE countries, from our skin to our dialects. our population and other neighboring countries consider us as asians. we are asians.
> > > > > 
> > > > > I think it /is/ a diasporic thing tbh. I heard it when I first came to this country (10yrs ago). And yes i agree with your tags, i think that it comes from self hate etc etc  
> > > > > -admin Kim Celine
> > > > 
> > > > i hate getting involved in this discussion but…
> > > > 
> > > > can we not pretend like this is some… ongoing stable reality? today, yes, we are considered asian. but this really actually hasn’t always been true.
> > > > 
> > > > and this isn’t just a ‘diaspora’ thing. one of the things, though, that you can learn in the diaspora is that white ppl have not always considered filipinxs to be ‘aisan’.
> > > > 
> > > > take american policy, for example, as best as i can tell we made the transition from ‘malayan’ to ‘asian’ sometime in the 1930s. prior to this point in time the world (bc the US occupied us at the time so what they said about us basically was global in impact), considered most of the asian island nations **AND** oceania to be what was known as the ‘east indes’. the philippines, particularly, was part of the spanish east indes.
> > > > 
> > > > basically, the malay peninsula and all the pacific islands between it the the US were considered as one geographic zone populated by a distint race white ppl called ‘malay’.
> > > > 
> > > > we’ve only been asian for about a hundred years. we were malayan for about a hundred and fifty years before that. and before that we were 'indians’ for a few hundred years. before _that_ we were ourselves and free.
> > > > 
> > > > this isn’t a stable reality. 'pacific islander’ as a distinct thing is fairly new, comparatively. so is filipinxs being asian.
> > > > 
> > > > also… it doesn’t matter if other asians think we are asian or not (some don’t). because _white_ people invented this racial classification system. it only matters what race _they_ think we are. and right now that’s asian.
> > > > 
> > > > we aren’t 'pacific islanders’ bc that term didn’t exist when we were racially grouped in with oceania. we (and pacific islanders) can and could call ourselves 'malayan’ or 'east indian’ if we want, though.
> > > > 
> > > > i think its important to acknowledge this history bc the changing status of our race actually made a _big_ difference for how colonization happened. and how white ppl treated us.
> > > 
> > > a kind friend pointed out to me that OP uses the language 'anti-Asian’ which i missed bc i only really read the comments about PI vs Asian.  
> > >   
> > > in any case: Black ppl have repeatedly said that 'anti Asian’ appropriates the framework of anti-Blackness. while i know it appears to be a neutral construction, i t really isn’t.   
> > >   
> > > engaging in (and ignoring as i did) this kind of anti-Black appropriation/co-opting is… not really something we ought to be doing.  
> > >   
> > > something to note for the future.
> > 
> > This was one of the main things that bothered me before I joined the blog. I had seen nonblack ppl talk about this before, but I had no real opinion on it so I went with thinking that it was co-opted. Then I asked another Asian person who is mixed w/ Black, and they disagreed, and I tend to agree with them now, because:
> > 
> > “Anti Asian racism” does not in any way co-opt the framework for antiblackness. It’s important for different marginalized groups to be able to talk about the racism that effects them specifically because not all racism operates the same- there are different stereotypes and people are treated differently throughout different groups. It’s also important for people to be able to talk about the distinctions between antiblack racism and other types of racism, because they can both exist within the same community. For example, there are black monoracial and mixed Asians who are effected both by antiblackness and anti Asian racism.
> > 
> > There are other marginalized groups who have used the prefix -anti in their discussions abt racism specifically against them. For example:  
> > Antiziganism/ anti Rromani racism.   
> > Antisemitism  
> > Anti Latinx racism
> > 
> > I just think it’s ridiculous when nonblack ppl say things like this as if They have any say, just because they’ve seen black people say that. This is basically doing the “I have a black friend who says-” thing to speak over and for Black ppl, specifically, Black Asians like me who have to deal with both worlds.  
> > And spreading that statement out over a huge amount of people, when you’re nonblack urself, is antiblackness in itself.
> > 
> > I have only ever seen nonblack ppl say that the term is piggybacking off of/ stealing the framework of the term antiblackness, like right now. If you have links to Black people who’ve said this, that would be another thing. but unless they are also pointing out the&nbsp;‘appropriation’ of the terms that other marginalized groups have been using, then they would be wrong in saying that&nbsp;‘anti Asian’ is piggybacking off of&nbsp;‘antiblackness’
> > 
> > - mod NJ
> 
> Anti-asian IS piggybacking off the framework of antiblackness. It came into use directly as a result of scholar work on antiblackness being more accessible on the internet. You did not see this until non-Black people began using anti-RACE as a stand in for when they were being called out on antiblackness.
> 
> As for antiziganism and anti-latinx: same thing as anti-asian. You cannot just take a term, fill in a new race or ethnicity, and have it mean the same thing without any of the theory and labor to back it up. Black people created the backbone for this type of discourse, as we use it today, in English.&nbsp;
> 
> With antisemitism, that is completely different in that its origins did not spring from Black discourse, but actually has a completely different and independent timeline. It stands alone and holds itself up as its own theory. IE, if you look up the term, you will find a historical trail for its conceptualization. You cannot say this for anti-latinx, anti-asian, antizigamisn,etc.- when you look up the terms you do not have a long history of theory behind the terms. Do not confuse that sentence for saying their oppression does not exist because it’s not in an ivory tower. What I am saying is that the terms are not independent of antiblackness as a theory, and that they themselves do not have a development of theory behind the term independent of antiblackness.
> 
> &nbsp;You would see for those, they actually had appropriative precedessors: like Brown/Chicano Power and Yellow Power, in response to Black Power. These terms bother me less, because at least then non-Black PoC made more of an effort when it came to solidarity with Black people.
> 
> What else has its own theory? Orientalism. Orientalism was developed as a theory around the same time as antiblackness, and it does not co-opt the manifestation of Black theory in its namesake, unlike anti-asian/race-to-fill-in-the-blank.&nbsp;
> 
> > “ but unless they are also pointing out the ‘appropriation’ of the terms that other marginalized groups have been using, then they would be wrong in saying that ‘anti Asian’ is piggybacking off of ‘antiblackness’ “
> 
> Lastly, it is honestly silly to think that Black people have to admonish all forms of anti-X in order for their critique of anti-X appropriation of language to be valid. Black people have the ability to pick and choose where they’re okay with usage, and as you know we are not a monolith. Some other Black person’s approval (yours) is not mine, nor does it invalidate mine. It also does make it just for non-Black people to continue calling their own out for this appropriation.
> 
> The only time they (non-Black people) have no business doing so is when another Black person (such as yourself) has a different opinion. That’s not their conversation to have. Likewise, just because you think it’s fine, does not mean it is not antiblack.&nbsp;
> 
> [http://strugglingtobeheard.tumblr.com/post/80113181463/antiblackness-v-intersectionality](http://strugglingtobeheard.tumblr.com/post/80113181463/antiblackness-v-intersectionality)
> 
> [http://strugglingtobeheard.tumblr.com/post/63484851614/ok-so-i-did-it-i-kept-it-5-minutes-for-tumblrs](http://strugglingtobeheard.tumblr.com/post/63484851614/ok-so-i-did-it-i-kept-it-5-minutes-for-tumblrs)&nbsp;(I am linking this specifically for the quotes on the origins of antiblackness as a theory, in which Blackness is posited as anti-humanity, while other races are considered subhuman or inhuman, you cannot say they are, as Black people are, considered the antithesis of humanity, as Black people are in every group they occupy. And in case it wasn’t obvious: the author is Black American, white (including Jewish), and the context was about whether racebending Sailor Moon as Black is anti-asian).