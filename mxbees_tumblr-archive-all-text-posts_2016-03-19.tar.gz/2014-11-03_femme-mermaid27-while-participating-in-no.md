---
id: 101629729484
slug: femme-mermaid27-while-participating-in-no
date: 2014-11-03 00:06:33 GMT
tags: []
title: 
---
[femme-mermaid27](http://femme-mermaid27.tumblr.com/post/101619660869):

> While participating in “no shave November” remember that there’s trans women and non binary folks who literally have to shave regularly, most of the time everyday, or their lives are at risk. So putting down folks for not participating/making it some sort of ~feminist~ must-do is harmful. It’s 100% possible to have autonomy and not be a transmisogynst while doing it.

feeling incredibly grateful that i don’t know the kind of feminists who would ever tell me to stop shaving for feminist solidarity for a month.  
  
fu.  
  
trying to get me killed?

