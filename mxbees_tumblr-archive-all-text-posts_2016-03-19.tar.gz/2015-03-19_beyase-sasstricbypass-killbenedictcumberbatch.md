---
id: 114063126989
slug: beyase-sasstricbypass-killbenedictcumberbatch
date: 2015-03-19 19:02:41 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[beyase](http://beyase.tumblr.com/post/114060764886):

> [sasstricbypass](http://sasstricbypass.tumblr.com/post/114059958787/killbenedictcumberbatch-didishy):
> 
> > [killbenedictcumberbatch](http://killbenedictcumberbatch.tumblr.com/post/114055962048/didishy-youbelongwithmes-rissaaburr):
> > 
> > > [didishy](http://didishy.tumblr.com/post/109823503641/youbelongwithmes-rissaaburr-youbelongwithmes):
> > > 
> > > > [youbelongwithmes](http://youbelongwithmes.tumblr.com/post/109535428542/rissaaburr-youbelongwithmes-its-2015-why-do):
> > > > 
> > > > > [rissaaburr](http://rissaaburr.tumblr.com/post/109535200620/youbelongwithmes-its-2015-why-do-women-still):
> > > > > 
> > > > > > [youbelongwithmes](http://youbelongwithmes.tumblr.com/post/109044321172/its-2015-why-do-women-still-have-to-pay-for):
> > > > > > 
> > > > > > > its 2015 why do people who menstruate still have to pay for tampons and pads
> > > > > > 
> > > > > > because people with dicks still have to pay for condoms ok fuck, stop wanting special treatment.
> > > > > 
> > > > > condoms are given out for free at clinics and schools. we dont want special treatment i want fundamental human rights.
> > > > 
> > > > You can refrain from having sex.
> > > > 
> > > > You can’t refrain from having a period.
> > > 
> > > is it just me or is this post extremely transmisogynistI thought that this post was pretty okay considering the commenters said ‘people who menstruate’ not like ‘girls’ or even ‘people with vaginas’ like nobody said anything about gender, they were speaking specifically about sexual organs so idk??? Can someone send me an ask about this?
> 
> The post originally said&nbsp;“women” and the second comment originally said&nbsp;“guys”. So. No

Still transmisogynist…

‘ppl with dicks’ indicates trans women have free, easy access to condoms and this somehow priveleges us….

Despite the fact that even having a condom can get a twoc arrested on suspicion of solicitation….

