---
id: 105918934734
slug: when-u-have-a-thought-about-a-fandom-u-arent
date: 2014-12-23 01:36:10 GMT
tags:
- media musings
title: 
---
when u have a thought about a fandom u aren’t really in

and decide to keep it to yourself bc u have zero desire

to get into a discussion with anyone about it.

