---
id: 131118466289
slug: still-shaking-my-head-at-that-post-that-claimed
date: 2015-10-13 23:17:26 GMT
tags:
- race to the bottom
- op
- antiblackness is real
title: 
---
still shaking my head at that post that claimed the whites in the appalachian mountains were descending from ‘celtic, irish, and scottish slaves and indentured servents’

like. u get that indentured servitude isn’t, in fact, slavery? that there were no white slaves in america?

its funny. i read an article not too long ago that examined the historical claim that there were white irish slaves at any point in US history. the conclusion:

no.

what do have is a bunch of fucking white ppl (who were always white) trying to pretend like their experiences were equivalent to chattel slavery.

smells like anti-Blackness to me.

