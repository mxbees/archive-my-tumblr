---
id: 103895001794
slug: i-just-sent-another-book-update-to-the-email-list
date: 2014-11-29 15:59:05 GMT
tags: []
title: 
---
i just sent another book update to the email list XD

