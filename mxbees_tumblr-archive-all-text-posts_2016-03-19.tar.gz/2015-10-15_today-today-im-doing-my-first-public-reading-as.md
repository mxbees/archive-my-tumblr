---
id: 131230471196
slug: today-today-im-doing-my-first-public-reading-as
date: 2015-10-15 17:49:36 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
Today. Today I’m doing my first public reading as a writer. I’m still feeling super ambivalent about the whole thing.

But. Hopefully today really will be my first step onto the path my ancestors want me to walk (at least if I undertand their intentions). I’m really hoping that this will stop any… um, extreme interference with my life so that I don’t have to be pushed into this.

I think I’ve picked out the parts of _decolonizing trans/gender 101_ that I’m going to read (but I need to practise them this morning to see how much time they take up and make adjustments based on that).

I’m incredibly grateful to my patrons for… not abandoning me when I was really vulnerable in my last personal essay (where I finally talked about the shit that happened to me in the past year and how I ruined my life and rendered myself forever unemployable in my field). I don’t think you (and perhaps everyone else once they get this info too) understand how worried I was that my toxic irl reputation would hurt my ability to write.

Writing is pretty much the only thing I have left.

If anyone in Toronto wants to see me read from my book, I’ll be at the Glad Day Bookshop. The event starts at 20:00.

In any case, after my official ‘debut’ tonight, expect things on this blog to get a little more open and personal. I’m talking things like selfies and whatever.

