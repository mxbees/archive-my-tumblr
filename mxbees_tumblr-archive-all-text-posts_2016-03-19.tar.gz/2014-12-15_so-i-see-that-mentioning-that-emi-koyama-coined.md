---
id: 105260565089
slug: so-i-see-that-mentioning-that-emi-koyama-coined
date: 2014-12-15 11:29:01 GMT
tags:
- teh trans community
title: 
---
so i see that mentioning that emi koyama coined the term ‘trans feminism’ yesterday brought about the rumours that she isn’t a trans woman….

thus far, i’ll i’ve seen is people asserting that she isn’t without any actual evidence (other than stuff she wrote 10+ years ago that isn’t even about her, specifically).

does anyone have better proof than “i heard this from someone else” (ie, 'hearsay’)?

bc like. i need something more compelling to disregard her autonomy and agency of self-identification.

funnily enough, i see in the notes of the post one person who vigourously defended a friend who was accused of the _same_ thing (ie, not being a trans woman despite IDing as such) and i was willing to believe this same person’s word that their friend is, indeed, a trans woman without any ~proof~ for the same reason that i believe emi.

and… yeah. like. i read through parts of the transfeminist manifesto and cringed at the dated language and discursive frameworks. it was written in _2001_. like i still see ppl fucking quoting serano’s 2005 book like it is the fucking bible and it is just as full of shitty oppressive garbage.

i suppose i can look forward to, in ten years or so, ppl doing the same with _decolonizing trans/gender 101_, which i have zero doubts will be dated and oppressive in ways that i can’t currently imagine. discourse and frameworks shift and evolve over time as we push boundaries and create new knowledge.

last… if it does turn out that emi isn’t a trans woman, this doesn’t actually make the historical fact that she coined 'transfeminism’ untrue, you know.

as far as i’m concerned, giving credit to a trans woman of colour for what she’s done is something we all should be trying to do.

