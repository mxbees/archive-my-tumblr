---
id: 100513205389
slug: believe-u-me-when-u-arent-white-as-in-when
date: 2014-10-20 17:48:42 GMT
tags:
- race to the bottom
title: 
---
believe u me

when u aren’t white

(as in when most ppl u encounter code u as something other than white)

u know.

U KNOW

saying this as a light-skinned poc who frequently coded as white in the city i lived in before

when u aren’t white

ppl tell u every fucking day that u aren’t

sometimes by words but also by deed.

in how they look and treat u.

