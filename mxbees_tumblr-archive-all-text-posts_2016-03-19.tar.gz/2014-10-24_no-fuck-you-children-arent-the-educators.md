---
id: 100823691599
slug: no-fuck-you-children-arent-the-educators
date: 2014-10-24 12:00:35 GMT
tags:
- teh trans community
title: no, fuck you, children aren’t the educators
---
Time for a rage post, unfortunately.

So there is this article “ [Trans children the education of educators](http://bit.ly/Pdngbo)“, to which I reply “You are a fucking monster”

This blogger further writes:

> (I want to note before continuing that one of the&nbsp; unspoken benefits for the other children in her class is the lesson of accepting individuals regardless of identity or orientation_.&nbsp;_These children will grow up with a much wider view of their world than many of us did.)

Now, some of the conclusions, I agree with. That all schools should currently already have some educational initiatives for teachers to learn about trans people and students. That there needs to be widespread infrastructure so that all these kids can be supported.

Yes. Good.

But, no, children are \*not\* the education of cis educators. And they shouldn’t be. It should not require a drawn out court battle and a massive media circus just so that cis educators are forced to accommodate. Note: they are \*forced\* to accommodate. They are already not seeing this girl (or other trans people) as human beings. This isn’t an educational experience for them.

And any person who needs ‘education’ from \*children\* to see their humanity is just…. no. And if you read about this story and were thought “wow! everyone in that school/town/whatever will be so much more aware/educated/knowledgeable about trans people and our struggles.”

Especially when you keep calling this child (grade 3 is, what, 8 or 9?) ‘young lady’.

SHE IS A CHILD YOU GIANT TURD!!!! YOU ARE NOT ONLY USING HER BODY AND SELF AS A RHETORICAL POINT TO EDUCATE CIS PEOPLE BUT ARE FURTHER TO BE PART OF THE PROCESS AND INSTITUTIONS THAT ARE SYSTEMATICALLY STRIPPING HER OF HER CHILDHOOD.

(I’m too mad about all of this to be super coherent. why is this — and so many other article — so fucking focused on this girl’s body? IT ISN’T RELEVANT.)

CHILDREN ARE NOT EDUCATIONAL TOOLS FOR CIS ADULTS

CHILDREN ARE NOT EDUCATIONAL TOOLS FOR CIS ADULTS

CHILDREN ARE NOT EDUCATIONAL TOOLS FOR CIS ADULTS

Framing it in this way is so absurdly dehumanizing that I can’t fucking even.

