---
id: 103409384134
slug: writers-always-make-the-sheriff-out-to-be-this
date: 2014-11-23 23:04:57 GMT
tags:
- media musings
title: 
---
writers always make the sheriff out to be this super moral guy

but he’s a cop.

and cops are assholes

