---
id: 106757394399
slug: everyone-sucks-and-i-hate-u-all
date: 2015-01-01 01:38:08 GMT
tags:
- teh trans community
title: everyone sucks and i hate u all
---
[theroguefeminist](http://theroguefeminist.tumblr.com/post/106754743553/in-a-lot-of-ways-those-this-stretches-beyond):

> In a lot of ways those, this stretches beyond otherkin. It’s also the nature of this website. We teach people that all that matters is being “problematic” or not and call outs and it’s just fucking inhuman and sick. Holding people accountable for their mistakes and striving to be a better person and not hurt marginalized people is definitely super important. But EVERYONE slips up and it’s never an excuse to completely dehumanize another person. But people on this site do it all the time.
> 
> In this case, it doesn’t even look like Leelah did anything that was actually “problematic” or wrong—but even if she had, this would be so disrespectful and cruel. But the environment on this site fosters that kind of behavior. This is why I have continually stood up against it when I can. If we do not connect with each other as humans or allow people to be imperfect or even make up for their mistakes we won’t get anywhere. What kind of world do you want to create in place of an oppressive one? I don’t want to be in a world where the suicide or death of someone is mitigated because they weren’t perfect. Where a person is reduced to a bullet list of fuck ups. But that’s the kind of environment many of us bloggers have fostered.
> 
> So what are you going to do about it? Keep it as is? Or work against it? And strive to actually&nbsp;_be_ a better person? Beyond the SJ-rule following sense of the word?

i’m sure there is context i’m missing here……..

but. meh.

the amount of…

“wow. are they really using Leelah as a rhetorical point to push respectability politics”

i’m feeling is…..

“don’t reduce a person to a bullet point of fuckups”

but let me reduce a teen girl to a rhetorical point because that is

SO MUCH BETTER

i hate everyone today.

all of u.

