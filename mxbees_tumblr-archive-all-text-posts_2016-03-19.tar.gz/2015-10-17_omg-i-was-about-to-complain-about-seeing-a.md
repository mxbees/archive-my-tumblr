---
id: 131370025439
slug: omg-i-was-about-to-complain-about-seeing-a
date: 2015-10-17 20:27:07 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
omg. i was about to complain about seeing a certain white trans woman that i hate on my dash

(on one of her posts)

until i remembered that my irl identity is now tied to this pseud and i don’t want to get sued again. :D

just as a heads up: from this point on, if i have something ‘shitty’ to say about someone, it’ll be vague blogging.

like. i know i’ll find ways to still get my points across, but i am not opening myself up to another lawsuit.

once was more than enough.

