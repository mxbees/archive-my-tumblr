---
id: 101135343214
slug: and-today-is-the-day-that-some-capitalism
date: 2014-10-28 01:30:15 GMT
tags:
- able ability
title: 
---
and today is the day that

some capitalism stan

said that bc they work with disabled ppl they couldn’t possibly be ableist

