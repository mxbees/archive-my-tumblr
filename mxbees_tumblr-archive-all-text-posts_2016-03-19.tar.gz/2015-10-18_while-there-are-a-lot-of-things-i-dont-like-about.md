---
id: 131385787364
slug: while-there-are-a-lot-of-things-i-dont-like-about
date: 2015-10-18 01:17:00 GMT
tags:
- fandom musings
- op
title: 
---
while there are a lot of things i don’t like about many fandoms (see racism and transmisogyny)

the thing i absolutely love the most is the meta.

(okay, i really like the fic and podfic too but this post is about meta)

like the fact that ppl will seriously spend LOADS of time thinking deeply about these… mainstream/popular things that are supposed to be less meaningful and artistic than, like, idk classical literature.

and instead of talking about classical literature or some junk, people will write a 2000 word essay about the symbolism of colour in glee or whatever.

its fucking awesome.

bc (at least for me) classical literature is fucking boring and filled with crusy white men i don’t care about.

however, i do care about someones thinkpiece on what they think fusion actually represents in gem culture.

