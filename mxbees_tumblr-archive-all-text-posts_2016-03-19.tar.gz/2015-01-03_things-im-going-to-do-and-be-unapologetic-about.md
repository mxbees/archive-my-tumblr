---
id: 107023685969
slug: things-im-going-to-do-and-be-unapologetic-about
date: 2015-01-03 18:25:46 GMT
tags:
- the life of an ordinary bakla
title: 
---
things i’m going to do and be unapologetic about in 2015.

by and large. i’m only going to be boosting fundraisers by twoc. and maybe other qtpoc at my own discretion.

but especially twoc fundraisers. stuff for white trans ppl often gets thousands of notes while twoc get few and rarely meet funding goals.

i’m not sorry.

when the entire world cares as much about twoc as i do, then i’ll start caring about the rest of the world more.

