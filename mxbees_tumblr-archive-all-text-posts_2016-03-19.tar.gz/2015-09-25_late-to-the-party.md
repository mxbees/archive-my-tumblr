---
id: 129866453723
slug: late-to-the-party
date: 2015-09-25 20:33:19 GMT
tags:
- current events
- usa
- hiv
- medical discrimination
title: Late to the party
---
Baltimore City just got a $20 million grant from the CDC to “target young gay and transgender individuals with new preventive and treatment strategies that reduce their risk of contracting the disease”. Which is awesome.

The article also mentions how new infection rates also correlate with race (being Black) and poverty in Baltimore. Talks about how because many trans women are forced to do survival sex work, we are particularly vulnerable to HIV. But then…

> From experience, health workers know such behaviors are extremely difficult to change.

Wat. They go on to talk about how the focus will be on preventing new infections (which, when has this ever not been the case???). But.

Look. What is difficult to change isn’t the ‘behaviour’ of the social groups mentioned in this article (gay men and trans women) but the social and economica and racial circumstances in which they live.

Like. Okay. So these trans women sex workers 'change their behaviour.’ And then what? Die of starvation in the streets? But, hey, they aren’t going to get HIV so that’s a win????

The whole point of survival sex work is that you do it to survive. Give these women a viable alternative for survival and they’ll probably do that.

( [Original Source. Trigger Warnings for medical discrimination](http://web.archive.org/web/20150925101010/http://www.baltimoresun.com/news/opinion/editorial/bs-ed-hiv-20150924-story.html))

