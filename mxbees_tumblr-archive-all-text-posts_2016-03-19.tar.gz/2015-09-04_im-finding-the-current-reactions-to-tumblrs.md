---
id: 128354051017
slug: im-finding-the-current-reactions-to-tumblrs
date: 2015-09-04 20:33:15 GMT
tags:
- able ability
- op
title: 
---
i’m finding the current reactions to tumblr’s update for how to display ‘comments’ and/or additional reblog stuff kind of interesting.

bc for some ppl, it has made tumblr less accessible.

for others, though, it has made tumblr more accessible.

so i’ve seen one group asking for the changes to be reverted, while the other group is thanking tumblr.

i’m not quite sure how to resolve genuine accessibility conflicts (where the accommodations needed are mutually exclusive) but this isn’t actually the case with this update.

the way tumblr was before was inaccessible. the way it currently is is inaccessible.

what ppl should be asking from tumblr staff isn’t to keep what we have or to go back, but for them to actually spend more than a fucking minute trying to implement actual universal design principles to maximize accessibility, rather than this ad hoc garbage they keep throwing at us.

