---
id: 129501750516
slug: hey-just-letting-everyone-know-that-im-ending-my
date: 2015-09-20 16:55:13 GMT
tags:
- the life of an ordinary bakla
title: 
---
Hey. Just letting everyone know that I’m ending my hiatus and will be resonding againg to comments and asks.

So. yeah.

Talk to me and i might talk back. :P

