---
id: 101020430174
slug: i-tip-my-hat-to-all-the-relatively-popular
date: 2014-10-26 19:56:42 GMT
tags:
- race to the bottom
- discussing discourse
title: 
---
i tip my hat

to all the relatively ‘popular’ white bloggers

who talk about oppression

but get SUPER FUCKING DEFENSIVE

whenever ur like

‘y u no mark ur race?’

lol.

fuck u all the most

