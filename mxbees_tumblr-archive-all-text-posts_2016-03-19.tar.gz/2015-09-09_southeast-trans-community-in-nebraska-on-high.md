---
id: 128718219038
slug: southeast-trans-community-in-nebraska-on-high
date: 2015-09-09 17:49:42 GMT
tags:
- current events
- nebraska
- warning
title: Southeast trans community in Nebraska on high alert
---
> The transgender community of Southeast Nebraska has been put on alert after a group fielded reports that a man is arranging to meet transgender individuals online and assaulting them when they arrive.

For any trans people in Nebraska, be safe and alert!

Re: the rest of this story…

> So far, Lincoln police don’t have information to confirm anyone is committing these crimes, Chief Jim Peschong said.

Lol. Why would anyone tell the police? Like. This is absolutely the worst place to look for confirmation that this is happening.

> Transgender community leaders say the tips they’ve received indicate some victims may not have reported what happened, fearing their identity may be made public.

I mean… also? The police don’t care. At all.

( [Original Source. Trigger Warnings for violence, police crap](http://journalstar.com/news/local/911/community-leaders-urge-caution-after-reports-of-assaults-on-transgender/article_a60b6516-c338-51c3-980e-b5880bd91e04.html))

