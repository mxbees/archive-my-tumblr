---
id: 104196933404
slug: you-all-missed-my-rant-yesterday-about-some-post
date: 2014-12-02 23:50:21 GMT
tags:
- teh queer community
title: 
---
you all missed my rant yesterday about some post talking about how aromantics and others not being included in ~teh queer community~ and just how, at its most fundamental is transmisogyny

because these assholes are always taking about how they are entitled to space created by twoc but purposefully is maintained by cis gatekeepers to ensure that we are excluded from what we created

and still exploits our labour and oppression

but I never see these same assholes ever talking about how their transmisogyny informs their entitlement

anyway. I hate u all.

you all deserve each other

not a single one of these assholes has ever ever explained why they can’t build up their own community.

instead u want to join the assholes who stole a movement from twoc.

