---
id: 105919633689
slug: although-i-am-happy-although-irritated-by-the
date: 2014-12-23 01:45:24 GMT
tags:
- media musings
title: 
---
although, i am happy (although irritated by the necessity)

that korrasami was confirmed as canon

like.

literally one of the gayest endings to a kids tv show

EVER

