---
id: 106468790459
slug: ugh-why-im-struggling-so-hard-rn-to-express
date: 2014-12-29 02:42:12 GMT
tags:
- the life of an ordinary bakla
title: 
---
ugh.

WHY

i’m struggling so hard rn to express the debt of gratitude i owe to the Black ppl in my life

for gracing me with their friendship/thoughs/existence

like. i have no real words.

but thanks to you all.

