---
id: 100763732857
slug: and-yeah-i-did-have-a-white-person-say-i-was-lazy
date: 2014-10-23 18:30:52 GMT
tags:
- b loves logic
- classical biyuti
title: And, yeah, I did have a white person say I was 'lazy' in my rejection of white
  rationality and logic.
---
Lazy.

I suppose that means that Chan and Zen Buddhists are lazy, since there is a tradition of anti-rationality in their philosophy.

But tell me this:

Why should I value rationality?

No. Really. Why?

I do value truth. And facts. But neither of these things have to do with rationality or logic.

In my hierarchy of values rationality scores really low. I prefer love, loyalty, truth, sincerity, kindness, compassion, and I’m sure I could think of a lot more things I care much, much more about than I care about being perceived to be rational by white people (especially when, being a femme PoC, I’m incapable of ever meeting this standard).

But, hey, I’m lazy.

Lazy because I care more about people than I care about logical arguments. Because I’m on tumblr to make friends and not get into endless arguments with white people to prove I’m human.

So. Damn. Lazy.

