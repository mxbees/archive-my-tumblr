---
id: 101943702714
slug: after-a-lifetime-of-hearing-brown-eyes-are
date: 2014-11-06 19:23:10 GMT
tags:
- transmisogyny is fun for the whole family
- teh trans community
title: 
---
after a lifetime of hearing

‘brown eyes are ugly’

'asians are too flamboyant’

'ur geting fat’

'girls don’t look that way’

'testosterone poisoning’

you all fucking sound the same to me

but i’m not listening anymore

except to note who gets put on the

'ur an unsafe asshole’

list and who doesn’t.

