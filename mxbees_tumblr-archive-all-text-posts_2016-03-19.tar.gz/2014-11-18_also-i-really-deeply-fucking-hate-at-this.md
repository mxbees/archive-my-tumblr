---
id: 102918238604
slug: also-i-really-deeply-fucking-hate-at-this
date: 2014-11-18 01:09:55 GMT
tags:
- antiblackness is real
- transmisogyny is fun for the whole family
title: 
---
also…

i really deeply fucking _hate_ at this point

the way that a lot of ~progressive~ news related info type posts

on tumblr will

with zero TW or other indication

just list the graphic details of the murder of a marginalized person

(the one i’m seeing is about Tanesha Anderson…)

while this is something i see most often (because of what i read)

on stories about twoc who’ve been murdered

this is just as bad whenever it is the murder of any black person

(not just Black trans women, is what i’m saying)

WHY ARE YOU POSTING THE GRAPHIC DESCRIPTIONS OF PEOPLE’S MURDERS WITHOUT A WARNING?

why do u need to include one _at all_?

the fact that the police have just killed another Black woman should be enough to feed any outrage or disgust or horror that you might feel about this.

i read a lot of news about trans women

and i swear, every single time i have to read about a twoc’s death

it is literally with graphic, sensationalist descriptions

i expect this stuff from regular media…

but if ur posting a link on tumblr

why is it so difficult to put a TW on your story?

or just leave out the graphic description???

