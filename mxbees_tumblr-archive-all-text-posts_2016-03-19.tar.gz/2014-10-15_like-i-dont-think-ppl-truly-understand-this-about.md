---
id: 100039206359
slug: like-i-dont-think-ppl-truly-understand-this-about
date: 2014-10-15 01:10:00 GMT
tags:
- discussing discourse
title: 
---
like i don’t think ppl truly understand this about all the ppl who might be considered the Big Names in our little corner of tumblr

like.

my friends and the ppl i care about how have thousands of followers…

built this following by getting harassed, triggered, stalked, threatened, and so on.

all for talking about their lives

and trying to connect with ppl

and many have somewhat abandoned their platforms bc of above but also plagiarism, media exploitation, academic abuse and the like

(a lot of these ppl are Black/queer/trans)

this is really the formula for getting tumblr famous as a marginalized person:

1. talk about your life 2. get harassed 3. respond to harassment instead of just letting ppl abuse them

sure. making ~quality~ posts helps, but it isn’t enough.

i also know lots of ppl who make quality posts but don’t have a following bc they don’t do the other stuff.

the rage of the oppressed is theatre for our oppressors

our sorrow and tears their dessert

