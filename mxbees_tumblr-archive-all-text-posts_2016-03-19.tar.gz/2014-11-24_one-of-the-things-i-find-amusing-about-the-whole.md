---
id: 103418586569
slug: one-of-the-things-i-find-amusing-about-the-whole
date: 2014-11-24 01:03:27 GMT
tags:
- decolonization nao
- teh trans community
title: 
---
one of the things i find amusing about the whole

‘doctors need to know about ur ~biological~ sex’

is that my health card has an F on it now

i’m not on hormones. and i’m not doing surgery.

how do these ppl

(who obvs live somewhere you need surgery to get the change of gender marker, but um… like this isn’t true in every context anymore)

actually think that this works?

like.

ur wrong. end of stroy. laws and stuff are changing to accommodate the reality that ~biological~ sex is irrelevant

argentina allows anyone to change their birth certificate on their own word.

i (partially) live in a jurisdiction where i can change gender markers without surgery.

as far as my health system is concerned

i’m female.

end of story.

and all u assholes who’re like

'doctors need to know’

can go fuck urself bc, well, this is actually factually incorrect.

or rather, my doctors (and any future medical practitioner i deal with in my country)

know my gender/sex.

and it is the one i say it is.

so. what.

