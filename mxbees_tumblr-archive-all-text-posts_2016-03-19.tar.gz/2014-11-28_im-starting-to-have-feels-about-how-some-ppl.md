---
id: 103797181999
slug: im-starting-to-have-feels-about-how-some-ppl
date: 2014-11-28 10:51:36 GMT
tags:
- discussing discourse
title: 
---
i’m starting to have feels about how

some ppl who don’t experience a type of oppression

(eg. the oppressors)

will. in their attempts to appear ‘cool’ or 'down with the struggle’

make clever little quips and soundbites on social media

that end up getting popular and boosted

why did u write this?

how do u feel about ur clever quip being boosted and amplified

far above the voices of the ppl u oppress?

