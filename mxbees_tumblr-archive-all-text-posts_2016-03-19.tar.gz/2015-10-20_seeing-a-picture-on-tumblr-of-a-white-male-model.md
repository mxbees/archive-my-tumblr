---
id: 131562335632
slug: seeing-a-picture-on-tumblr-of-a-white-male-model
date: 2015-10-20 16:55:05 GMT
tags:
- decolonization nao
- mayo is as mayo does
- op
title: 
---
Seeing a picture on tumblr of a white male model with tattoos on his face and hands and I’m mad….

Long time followers will know that I get pretty… idk, sensitive about tattooing and tattoo culture.

Insofar as I accept that white ppl getting tattoos isn’t something that anyone can do anything about, it really really bugs me when I see them with hand/face tattoos.

Because. By and large, white people are the only ones who can get away with tattoos on these areas. Tattoos, in general, are still not considered ‘professional’ in a lot of contexts, but getting them on your hands or face is even more limiting.

And so… there are entire Indigenous ppls who aren’t getting their own traditional tattoos bc they have to navigate a white supremacist society that already hates them.

Then I see some white d00d with tattoos all over his face being paid to model? Angry making.

