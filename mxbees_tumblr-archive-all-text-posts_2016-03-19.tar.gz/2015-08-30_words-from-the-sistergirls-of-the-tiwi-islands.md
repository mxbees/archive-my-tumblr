---
id: 127957886338
slug: words-from-the-sistergirls-of-the-tiwi-islands
date: 2015-08-30 17:49:33 GMT
tags:
- current events
- australia
- indigenous
- sistergirls
- op
title: Words from the sistergirls of the Tiwi Islands
---
So… by and large I hate the tone and way that this article is writen. It feels too much like ‘exotic anthropology’ stuff. So what I’m going to do is put all the direct quotes from the sistergirls themselves and just let them speak.

(tw: suicide)

> Between poses Laura Orsto, 31, says she told her parents that she was a sistergirl in primary school. “Age 10 I knew I was a sistergirl. It was really, really, very hard for me to come out because my parents are really strict and didn’t want me to be out there as a sistergirl. They wanted me to be saved,” she says.
> 
> As a 16-year-old, Orsto began living her life as a female and had to “fight and fight and battle hard to be accepted”.
> 
> It was an older yimpininni who gave Orsto courage and strength as she came to terms with living life as a woman. “There were plenty of sistergirls back then; I used to go out with them and talk about things, like how to act like girls you know and be ladylike. One lady, I use to call her Mum, she was like a mother to me, and she told me, ‘You just have to be who you want to be, baby, just like me. I’m always here for you, you got me here.’”
> 
> Today Orsto is a much-loved and respected member of the community. “I love to talk to everyone, and everyone has been nice to me and they don’t put me down, they put me up the top. Everyone says, ‘Wow, you have a nice personality, Miss Laura,’” Orsto said.
> 
> Nyarli Kerinaiua, 34, points out two graves adorned with beautiful tutinis reaching for the sky, covered in intricate ornate Tiwi design…Both had killed themselves 15 years ago. “It was really sad because we didn’t have any support back then. It was a bit of an aggressive ride,” says Kerinaiua as she straightens a bunch of plastic flowers on one of the graves.
> 
> “We had a community meeting and one of the families wanted to know how the suicides happened, and basically they were all too blind to see that it was name-calling, that it was discriminating against her sexuality. As the years go by we have slowly worked our way up, building our confidence and just basically being out and living life as the Tiwi sistergirls.”
> 
> “The local store, the council, the police station were shut. Everyone attended, including our families and classmates. I was quite young and about 20-30 of us sistergirls raised our voices there. We said we’ve had enough of what had happened to these girls who committed suicide.”
> 
> “What we really need now is some specialised services to deal with sistergirl issues. We [older sistergirls] just want up-and-coming sistergirls to go straight forward with no problems, no struggles. We don’t want them picking up the pieces.”<sup id="fnref:p127957886338-1"><a href="#fn:p127957886338-1" rel="footnote">1</a></sup>

( [source. tw: exotification, weird creepy anthro language, suicide](https://web.archive.org/web/20150830102559/http://www.buzzfeed.com/allanclarke/sistergirls-of-the-tiwi-islands).)

* * *

1. 

Okay… so in the article I can’t even tell who is saying those last three _direct_ quotes. Ridiculous.&nbsp;↩

