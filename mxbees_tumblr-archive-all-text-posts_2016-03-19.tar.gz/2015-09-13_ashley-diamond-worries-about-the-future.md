---
id: 129015673702
slug: ashley-diamond-worries-about-the-future
date: 2015-09-13 19:38:49 GMT
tags:
- current events
- ashley diamnond
- usa
- black trans women
title: Ashley Diamond worries about the future
---
 **As with before, I’m just going to try and share as many direct quotations as possible. TWs for incarceration, transmisogynoir, discrimination.**

> Diamond said she first told her family that she was a girl when she was 6 years old. After a suicide attempt at age 15, she was diagnosed with gender dysphoria, the medical term for wanting to live as a gender other than the one assigned you at birth.
> 
> Her father kicked her out, and she was taken in by friend’s families. Looking for work as a teenager, she ran into resistance immediately. Diamond remembers applying for a job at a McDonald’s.
> 
> “When they asked me for my Social Security card and my ID, she looked down at it and said, ‘Oh this must be a mistake.’ And I said, 'No ma'am.’ And she said, 'Oh, I’m absolutely sorry. We don’t do that here,’” she said. “That. Here.”
> 
> Finding and keeping work did not get easier. More rejections followed, and Diamond began stealing.
> 
> “The crimes, you know, I accept full responsibility. I’m very sorry for the people I’ve hurt. I needed the money to survive,” she said.
> 
> As she speaks, Diamond dips in and out of a deep pool of horrifying experiences she faced in prison. In her lawsuit, she said she was raped seven times in Georgia prisons. Before incarceration, Diamond said she’d only ever had three boyfriends.
> 
> “I went from that to multiple partners that I had no say over. I think you lose a part of you. And so much of me is lost,“ she said.
> 
> Diamond said it’s been incredible to see transgender activists like Laverne Cox and Janet Mock raising awareness of these and other issues. But in reality, the world she’s returning to in Rome, Georgia, is largely the way she left it. Except now she has a felony conviction, and the accompanying physical and emotional damage of her time in prison.
> 
> "Right now I am as worried as anybody about what the next step is going to be,” said Diamond.
> 
> Wilson said she knows her sister loves fighting for other people, and that for now, it’s that sense of mission that’s keeping Diamond going. But she has serious fears about her surviving life in her hometown.

( [Original Source. Trigger Warnings for rape, incarceration, employment discrimination, video in link that I didn’t watch and can’t TW](http://syx.pw/1M4VQ1e))

