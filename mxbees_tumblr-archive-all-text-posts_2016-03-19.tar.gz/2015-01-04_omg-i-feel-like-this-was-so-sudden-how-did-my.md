---
id: 107157923859
slug: omg-i-feel-like-this-was-so-sudden-how-did-my
date: 2015-01-04 23:51:38 GMT
tags:
- the life of an ordinary bakla
title: 
---
omg. i feel like this was so sudden.

how did my blog get to the point (again)

where my substantive posts are getting (regularly) hundreds of notes?

having things quiet was nice for a while.

but. i guess 2015 is the year that i get ‘big’ again or something

