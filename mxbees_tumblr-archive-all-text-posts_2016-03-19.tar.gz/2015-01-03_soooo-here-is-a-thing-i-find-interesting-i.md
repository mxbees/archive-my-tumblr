---
id: 107004390929
slug: soooo-here-is-a-thing-i-find-interesting-i
date: 2015-01-03 13:27:56 GMT
tags:
- antiblackness is real
title: 
---
soooo…

here is a thing i find interesting. i reblogged two posts by disabledqueerdyke today about Rita Hester.

one mentions that TDoR was created in response to her murder

and the other notes that we need to recognize that the Black community has a lot to do with knowledge of her life and death

_one_ of these posts has 200+ notes and the other? 28 (at this moment)

can u guess which one?

i hope all the ppl who’re reblogging one, but not the other recognize that their anti-Blackness is showing.

could u be more transparent?

