---
id: 129857301126
slug: almost-human
date: 2015-09-25 17:49:36 GMT
tags:
- current events
- usa
- medical discrimination
title: Almost human...
---
I honestly don’t know how to feel about this blog post. Because it is clear that the doctor is at least trying. But it all sounds awful to me. He basically starts of with how a fellow wouldn’t give him the ‘sex’ of the patient…

Then goes on to describe his inner monologue and 'struggle’ with how to deal with his patient.

And he finishes the post with:

> I edited his description of our patient, changing all the “hes” to “shes,” all the “his” and “hims” to “her.” I also chatted with my fellow about our patient. Medicine can be a rigid discipline that makes us all slaves to rules: of biology, of how to talk to our patients and discuss them with each other, and of how to write about them. It is certainly within our patients’ rights to upend those rules and push us to conform to their reality.
> 
> Even if it makes us uncomfortable sometimes.

Which is a step in the right direction. But. This also makes me want to scream because, really????? REALLY!? It shouldn’t be this fucking difficult for medical professionals to figure out.

( [Original Source. Trigger Warnings for transmisogyny, misgendering, medical discrimination](https://archive.is/KR2ip))

