---
id: 114079609434
slug: like-the-idea-that-naming-ppl-with-penises-is
date: 2015-03-19 22:32:55 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
Like the idea that naming ‘ppl with penises’ is somehow not transmisogyny is interesting….

Like equating cis men and trans women isn’t transmisogyny?

Tell me more about all the privileges I share with cis men just bc we have the same junk…

Pls. Tell. Me. More.

