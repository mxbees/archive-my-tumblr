---
id: 100117630439
slug: hey-so-im-totally-doing-the-thing-i-have-a-few
date: 2014-10-16 00:11:18 GMT
tags:
- the life of an ordinary bakla
title: 
---
hey. so i’m totally doing the thing. i have a few of my ‘classic’ posts queued up.

will consistent tagging and i’ll revamp my theme tomorrow or something

(for easier site navigation)

maybe even put a custom url again… we’ll see….

