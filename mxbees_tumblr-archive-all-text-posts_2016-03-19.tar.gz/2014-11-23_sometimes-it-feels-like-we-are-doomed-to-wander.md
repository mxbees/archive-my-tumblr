---
id: 103324830519
slug: sometimes-it-feels-like-we-are-doomed-to-wander
date: 2014-11-23 00:43:55 GMT
tags:
- teh trans community
- antiblackness is real
title: 
---
sometimes…

it feels like we are doomed to wander around in the same circle over and over again

with nothing substantive changing.

originally i hadn’t wanted to say anything about the callouts of anti-Blackness i’ve seen re: darkmatterrage

bc ppl should really REALLY listen to the Black ppl who’ve done the calling out.

and, tbh, i feel like

why haven’t u been in a position to hear these criticisms before?

same with the ppl asking ‘what do we do?’

why aren’t you already listening to Black ppl?

Black ppl have been telling us for a long time what they want from non-Black ppl.

i mean. i suppose i could’ve just stuck with personal experience and the ways that they’ve repackaged some of my ideas.

but i’d rather ppl pay attention to the anti-Blackness

