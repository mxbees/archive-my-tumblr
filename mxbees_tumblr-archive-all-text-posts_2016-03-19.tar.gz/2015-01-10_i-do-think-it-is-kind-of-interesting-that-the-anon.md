---
id: 107718295884
slug: i-do-think-it-is-kind-of-interesting-that-the-anon
date: 2015-01-10 20:36:02 GMT
tags:
- race to the bottom
title: 
---
i do think it is kind of interesting that the anon i had earlier formulates ‘ndn’ as entirely restricted to north american even though….

like. my people were called ‘indians’ by the spanish anyway….

but also the anti-Blackness… it still itches at my skin

even as, yes, i don’t get space — but i also wasn’t asking for it — in discussions of american Indigenous discourse.

