---
id: 128070716484
slug: a-focus-on-women-isnt-the-erasure-of-men
date: 2015-09-01 01:04:02 GMT
tags:
- discussing discourse
title: 
---
a focus on women isn’t the erasure of men

