---
id: 131913930464
slug: was-just-realizing-that-i-think-ive-really-come
date: 2015-10-25 23:46:16 GMT
tags:
- able ability
- the life of an ordinary bakla
- op
title: 
---
was just realizing that i think i’ve really come to accept that this world wants me dead.

like. i think it was really abstract before. i know that i sit at a not-so-comfy place as far as oppression goes… but idk. i think it really is the disability stuff that is the last fucking straw.

i think a part of me, deep down inside, still really thought that despite all the barriers, i could succeed. i could make it. that some day, some magical future day, my life wouldn’t be so fucking hard all the time.

if only i worked hard and followed all the advice…

but i did all of these things. i worked as hard as i could. i did all the things they say ur supposed to do in order to be a successful adult.

and here i am. realizing that by doing those very things (and sacrificing my mental health in the process), i probably won’t qualify for disability. bc now i look good on paper.

that’s the thing, though. on paper, there literally is no reason why my life is the shithole it currently is. it shouldn’t be.

but it is. bc systemic oppression is a thing. bc i have actual limits to what i can do. and the limits of what i can actually do are below the threshold for doing anything other than survive.

one way or another. the world wants me dead.

i’m still here.

