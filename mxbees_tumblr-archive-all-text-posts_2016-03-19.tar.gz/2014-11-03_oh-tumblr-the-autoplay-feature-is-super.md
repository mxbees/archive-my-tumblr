---
id: 101665815729
slug: oh-tumblr-the-autoplay-feature-is-super
date: 2014-11-03 11:03:12 GMT
tags: []
title: 
---
oh tumblr

the autoplay feature is super annoying

but then i go to watch a video i actually want to see….

and it won’t load.

