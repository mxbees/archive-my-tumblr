---
id: 117799973459
slug: copperkeep-b-binaohan-bc-so-much-aave-is
date: 2015-04-30 21:30:35 GMT
tags:
- antiblackness is real
title: 
---
[copperkeep](http://copperkeep.tumblr.com/post/117781427166/b-binaohan-bc-so-much-aave-is-appropriated-that):

> [b-binaohan](http://xd.binaohan.org/post/117780843524/bc-so-much-aave-is-appropriated-that-we-commonly):
> 
> > bc so much aave is appropriated that we commonly lose the origins of the words/expressions. ( [x](http://twitter.com/b_binaohan/status/593814102449004544))
> 
> how often have i said exactly this. y’all don’t even know the words are ours because we get erased as soon as they come out of our mouth. i don’t even call half of you on it bc its so second-nature to you and i do not have the time

_nods_

this is why i’ve started to try and call ppl out on it, since a friend asked and this kind of this is so commonplace that i can imagine it being fucking _exhausting_ to have to call out.

also why nonBlack ‘allies’ (like me) need to work extra hard not to engage in this kind (but really all kinds) of antiBlack appropriation.

