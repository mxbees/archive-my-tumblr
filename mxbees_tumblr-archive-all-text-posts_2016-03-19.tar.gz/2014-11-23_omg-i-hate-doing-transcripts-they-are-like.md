---
id: 103373552614
slug: omg-i-hate-doing-transcripts-they-are-like
date: 2014-11-23 15:40:01 GMT
tags:
- the life of an ordinary bakla
title: 
---
omg. i hate doing transcripts they are like instapress buttons for my excessive daytime sleepiness.

i feel like crap now.

why is this something that is so hard on my brain????

