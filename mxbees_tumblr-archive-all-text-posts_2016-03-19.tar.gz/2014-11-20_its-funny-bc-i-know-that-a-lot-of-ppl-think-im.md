---
id: 103084192244
slug: its-funny-bc-i-know-that-a-lot-of-ppl-think-im
date: 2014-11-20 01:22:42 GMT
tags:
- the life of an ordinary bakla
title: 
---
its funny. bc i know that a lot of ppl think i’m more ‘popular’

or something

than i really am. even at my old tumblr…. i probably had a fraction of the followers that ppl thought i did.

when i deleted that account, i think i had just gone over 1k?

this blog has less than 400. my twitter account has about the same.

it isn’t like i’ve made thousands and thousands of dollars from my book.

i’m poor.

i’m unknown.

i don’t get invited to give talks at places.

