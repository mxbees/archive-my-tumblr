---
id: 130777722784
slug: remembering-why-i-dont-often-try-to-do-research
date: 2015-10-08 23:25:08 GMT
tags:
- ye olde abuse culture
- op
title: 
---
remembering why i don’t often try to do research into child neglect.

why the fuck is it _so_ hard to find articles/books/resources that are _specifically_ about neglect rather than the resource saying

“child abuse and neglect”

only for the entire fucking thing to be about abuse.

like. my issue with folding neglect into abuse isn’t necessarily about trying to force a hard boundary between the two.

its just…

when you read stuff title ‘child abuse and neglect’ (and i have)

invariably, it’ll talk about various kinds of about and if they mention neglect at all, its like… a tiny fraction of the entire thing.

moreover, it is super easy to find specific articles about the many other kinds of child maltreatment.

you want stuff on emotional abuse? easy. physical abuse? easy. sexual abuse? easy. there’s piles and piles of research and resources about this.

after poking around my library, i have 11 citations to look up and things to read. _eleven_. and i have access to one of canada’s largest research libraries.

this is why i think maintaining a distinction is important. bc sure. maybe neglect is a kind of abuse. by why doesn’t get as much attention as the others then?

