---
id: 130784056589
slug: tonight-im-remembering-that-all-i-really-want-to
date: 2015-10-09 01:24:28 GMT
tags:
- the life of an ordinary bakla
title: 
---
tonight I’m remembering that all I really want to do is write stuff and share with no barriers. not charge money. and just keep sharing, thinking, and discussing.

