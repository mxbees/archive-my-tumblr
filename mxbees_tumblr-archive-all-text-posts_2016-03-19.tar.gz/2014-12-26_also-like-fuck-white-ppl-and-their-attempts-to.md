---
id: 106261733429
slug: also-like-fuck-white-ppl-and-their-attempts-to
date: 2014-12-26 22:28:40 GMT
tags:
- decolonization nao
title: 
---
also like.

fuck white ppl and their attempts to enforce their hegemonic ideas about what is or isn’t butch/femme

no one cares about how u use those words in ur bland mayo and whitebread discourse

NO ONE CARES

