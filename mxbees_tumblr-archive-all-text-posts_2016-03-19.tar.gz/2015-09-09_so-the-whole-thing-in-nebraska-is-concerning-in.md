---
id: 128730638611
slug: so-the-whole-thing-in-nebraska-is-concerning-in
date: 2015-09-09 21:27:54 GMT
tags:
- teh trans community
- discussing discourse
- op
title: 
---
So the whole thing in Nebraska is concerning. In part because the community ‘leaders’ are engaging in some interesting… victim blaming. Well, the media too.

I’m see a lot of “if ur trans and meeting someone from online, then meet them in a public place! tell friends where you are!”

And the cognitive dissonance of saying _this_ while at the same time noting that many trans people are likely not reporting their experiences because they are afraid of being outed.

Look. The internet has been around for a while now. So has online dating/hookups. Most of us know the very basic safety protocols around meeting people online and shifting that the irl. We know. We get it.

But if you’re a closeted trans person and online is the only place you currently have to express yourself, you might not be comfortable meeting people in a 'public space’. Because you’re in the closet and maybe in a vulnerable state. Scratch that, you’re definitely in a vulnerable state. All trans women (of colour) are.

Maybe you’re out of the closet and have basically been alienated from most people and are feeling desperate and lonely. And you meet someone online that appears to enthusiastically embrace you as you are. But they are worried about the stigma that comes along with dating a trans person, so they don’t want to meet in public. You’re lonely and want some human contact. You want to feel desirable, even if it is just for a moment. So you decide its worth the risk….

The problem with all of this? Isn’t the supposed dangers of meeting ppl online. It is the fact that there are a lot of various factors that make trans women vunerable. And that this leaves us open to many different kinds of predators, not just the ones who might be catfishing us.

