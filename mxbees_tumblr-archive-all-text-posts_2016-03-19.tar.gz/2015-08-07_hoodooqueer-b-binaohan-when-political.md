---
id: 126112706414
slug: hoodooqueer-b-binaohan-when-political
date: 2015-08-07 19:00:30 GMT
tags:
- epilepsy warning
- teh trans community
title: 
---
[hoodooqueer](http://hoodooqueer.tumblr.com/post/126108127054):

> [b-binaohan](http://b-binaohan.tumblr.com/post/126087276279):
> 
> > When Political Correctness Hits Below the Belt [http://t.co/nIp3DsjcPv](http://t.co/nIp3DsjcPv)
> > 
> > eject her into space. she’s so utterly missed the point. ( [link to tweet](http://twitter.com/b_binaohan/status/629605879596339200))
> 
> What the fuck did I just read.
> 
> <figure data-orig-height="245" data-orig-width="245"><img src="https://33.media.tumblr.com/4b10f9f591d4c3efa4971fd26de208cc/tumblr_inline_nsq3zzY5Uy1qfzb2v_500.gif" data-orig-height="245" data-orig-width="245"></figure>

apparently… not wanting ppl to ask about our genitals is ruining Teh Discourse.

