---
id: 100465073789
slug: like-these-ppl-think-that-some-bullshit-call-of
date: 2014-10-20 02:08:59 GMT
tags:
- able ability
- ye olde abuse culture
- the life of an ordinary bakla
title: 
---
like these ppl think that some bullshit call of ‘ableism’

gives them a right to decide which victim/survivor narratives are valid or not?

SO HAPPPY

i have ppl who aren’t me

and who didn’t have to grow up with my dad

ready to fucking decide

that no, in actual fact, my dad didn’t use mood swings as a method of abuse

i guess this will cure my generalized anxiety

and hyper vigilence

borne out of a childhood living in an environment of quiet terror

bc i never knew what kind of mood my dad might be in next.

