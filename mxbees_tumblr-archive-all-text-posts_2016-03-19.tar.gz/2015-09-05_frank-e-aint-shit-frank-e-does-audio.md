---
id: 128431083395
slug: frank-e-aint-shit-frank-e-does-audio
date: 2015-09-05 21:27:56 GMT
tags: []
title: 
---
[frank-e-aint-shit](http://frank-e-aint-shit.tumblr.com/post/127864472360):

> [frank-e-does-audio](http://frank-e-does-audio.tumblr.com/post/125173214692):
> 
> > [frank-e-does-audio](http://frank-e-does-audio.tumblr.com/post/124419544452):
> > 
> > > Hey everyone, I recently lost my food benefits and could use a little help feeding myself. If you can, please donate to me on paypal. My email address there is cinginrevlushon@hotmail.com. If you can’t donate, boosting also help. And thank you to those who have already donated via the other post. Since it wasn’t allowing some folks to reblog I set up a new one.
> > 
> > Thank you to those who have donated so far. I would still appreciate all the help I can get, either from boosting or donating!
> 
> I’m hoping this is temporary, but in addition to loosing the benefits last month, I am now down to just the one job. I’m hoping that work will pick back up, but that was a big chunk of my income.  
>   
> If you can, please donate, if not please boost.