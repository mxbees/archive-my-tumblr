---
id: 103845637014
slug: er-i-should-keep-my-quiet-re-current-discussion
date: 2014-11-29 00:38:59 GMT
tags:
- the life of an ordinary bakla
title: 
---
er… i should keep my quiet re: current discussion about Jewish ppl’s oppression

like i said. too ignorant to discuss it.

so… yeah.

