---
id: 118038866894
slug: numbwreck-please-remember-to-forgive-yourself
date: 2015-05-03 17:37:34 GMT
tags:
- able ability
title: 
---
[numbwreck](http://numbwreck.tumblr.com/post/116225509158/please-remember-to-forgive-yourself-for-the-years):

> please remember to forgive yourself for the years your mental illness took away from you

ok. maybe.  
  
but i’ll never forgive the world for being a relentlessly cold, unaccommodating place so that i lose/lost years of my life to disability

