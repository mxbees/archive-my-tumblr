---
id: 100624114604
slug: one-thing-ive-noticed-about-those-who-can-code-as
date: 2014-10-21 23:59:28 GMT
tags:
- race to the bottom
- mixed with white feefees
title: 
---
one thing ive noticed about those who can code as white

is that those of us who arent generally entitled white acting asshats

grew up \_not\_ being coded as white.

i really do think this history makes for a very, very important difference

u dont grow up with everyone treating u like ur white.

u dont grow up thinking ur shit smells like roses.

and this leads to, um, us actually being able to really and truly empathize with those poc who will never code as white.

bc this kind of experience is in our past and, more importantly, it could be our future too.

(or, like me, my present)

