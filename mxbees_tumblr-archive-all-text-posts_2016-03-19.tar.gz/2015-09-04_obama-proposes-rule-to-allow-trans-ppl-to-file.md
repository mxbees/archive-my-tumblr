---
id: 128344765776
slug: obama-proposes-rule-to-allow-trans-ppl-to-file
date: 2015-09-04 17:49:36 GMT
tags:
- current events
- trans healthcare
title: Obama proposes rule to allow trans ppl to file civil rights violations against
  medical ppl who deny care
---
> Today, after pressure from LGBT advocacy groups, the U.S. Department of Health and Human Services proposed a new policy that will enable transgender Americans to file claims of civil rights violations against physicians, insurers, and hospitals that fail to provide trans-affirmative healthcare care.
> 
> The policy clarifies the scope of the Affordable Care Act’s nondiscrimination clause, Section 1557. The proposed policy forbids insurers from denying transgender patients transition-related health care like hormone therapy, counseling, and surgical procedures that that have previously been considered aesthetic.

( [Original Source](http://web.archive.org/web/20150904101252/http://www.advocate.com/transgender/2015/09/03/new-hhs-rule-could-change-game-trans-healthcare))

