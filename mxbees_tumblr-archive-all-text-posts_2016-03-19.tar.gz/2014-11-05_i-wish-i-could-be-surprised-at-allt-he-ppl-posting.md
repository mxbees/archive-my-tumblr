---
id: 101801974919
slug: i-wish-i-could-be-surprised-at-allt-he-ppl-posting
date: 2014-11-05 00:46:26 GMT
tags:
- i rebuke thee feminism
title: 
---
i wish i could be surprised at allt he ppl posting quotes and shit from that book

by awful femninisnit i’m not going to name at the moment

without a trigger warning

‘cause it just isn’t about what she wrote

like. 95% of the discussions i’ve seen about it are super fucking triggering.

all these ppl wanted to ‘debate’ this……..

i just.

no

