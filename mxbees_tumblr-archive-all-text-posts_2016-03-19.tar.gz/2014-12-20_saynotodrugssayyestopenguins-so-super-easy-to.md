---
id: 105654353794
slug: saynotodrugssayyestopenguins-so-super-easy-to
date: 2014-12-20 02:35:58 GMT
tags:
- ferguson
- antiBlackness
- Black lives matter
title: 
---
[saynotodrugssayyestopenguins](http://saynotodrugssayyestopenguins.tumblr.com/post/95172654544/so-super-easy-to-get-desensitized-about-whats):

> So super easy to get desensitized about what’s happening in Ferguson if you’re behind a screen miles and miles away. But please, don’t stop caring, don’t forget about the crimes that have been committed there, and above all else stay angry. Scream with the people in Ferguson, amplify their voices.