---
id: 131946541684
slug: does-everyone-like-how-cheerful-im-being-this
date: 2015-10-26 12:07:17 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
does everyone like how cheerful i’m being this morning?

lol

i really meant it yesterday that i’m reaching (i have reached) a place of acceptance that they world simply wants me dead.

its funny. one of my most cherised dreams when i was younger was the idea that one day i’d get to relax, breathe, take time. that maybe i’d have a stable home. enough money to live (i aspired to be middle class). that i could live quietly and just… fade away.

i deferred a lot of necessary self-care and healing with this hope in mind. that someday i’d have the space, time, and resources to actually make myself a little less broken.

now? i’m just broken and i’ve given up.

