---
id: 129004424219
slug: honestly-ive-said-before-that-im-not
date: 2015-09-13 16:54:58 GMT
tags:
- teh trans community
- op
title: 
---
honestly? i’ve said before that i’m not particularly concerned about cis actors playing trans characters.

bc. i want trans people to be able to play cis (and any other kind of) characters. trans people playing trans characters just isn’t good enough for me.

what does bug me when cis actors play trans characters, though, is the way that the media suddenly thinks like they have a valid opinion on trans experiences.

(note: i feel the same way when straight people play gay characters… yes, i’m looking at you Darren Criss and the way you’ve capitalized on the very thing i’m critiqueing here)

like. the media will interview these cis actors and honestly treat them like they have real insight into what it means to be trans.

and that’s what fucking kills me at the end of the day. bc no.

