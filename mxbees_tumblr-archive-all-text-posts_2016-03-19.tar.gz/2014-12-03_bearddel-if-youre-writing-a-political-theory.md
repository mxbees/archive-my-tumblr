---
id: 104280823544
slug: bearddel-if-youre-writing-a-political-theory
date: 2014-12-03 23:45:08 GMT
tags:
- discussing discourse
title: 
---
[bearddel](http://bearddel.tumblr.com/post/104135402909/if-youre-writing-a-political-theory-about):

> If you’re writing a political theory about something, and you can’t put it into words that would be comprehensible to the people the theory describes, get a new theory.

i get where this is going and i generally agree…

BUT

i have (as usual) some problems with the framing here

since i know that i’ve occassionally been charged with having dense academic-ish writing that can be inaccessible to some

like, this framing assumes that if ur writing a political theory about a group you don’t belong to and it is incomprehensible to that group. then it is a problem. which is something i totally agree with…

my issue here, though, is how this falls apart when oppressed ppl are talking about ourselves.

while, yes, i would dearly love that my writing is accessible to every single person who is going to read it, given the reality of neuro-pluralism, i’m unclear how this is at all an expectation that is even remotely realistic

moreover…

there are sincere and real problems with this assumption that you can actually speak for ‘the people’. who are you? did someone elect you the representative of 'the people’?

in white philosophy, every so often there is a movement towards 'plain language’ or colloquial approaches to doing philosophy. these (in this case white men) with a great deal of education assume that they know what 'plain’ language would be like for someone without a phd in philosophy and the results are always … interesting.

who decides what is comprehensible to 'the people’?

why are we assuming that 'the people’ are a monolith and that there exists a kind of theorizing that is comprehensible to ~the people~ and kinds that are not?

why do the people who do comprehend a style of theorizing unimportant in this case?

yeah… a lot of people will claim that academic style writing is classist and too opaque for the 'average’ person to access….

and this problem does exist

but so does the problem of privileged ppl assuming the cognitive abilities of other people

i’ve met a lot of ppl on tumblr without university degrees who are perfectly able to understand the most dense academic prose and, yes, articulate themsevles likewise.

i also know ppl with degrees who can’t/don’t do this.

who are these people?

what gives you the authority to make claims about what they do or do not understand?

