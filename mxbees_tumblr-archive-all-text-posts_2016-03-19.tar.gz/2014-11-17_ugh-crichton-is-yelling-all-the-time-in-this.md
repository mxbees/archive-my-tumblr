---
id: 102909122799
slug: ugh-crichton-is-yelling-all-the-time-in-this
date: 2014-11-17 23:10:34 GMT
tags:
- media musings
title: 
---
ugh

crichton is yelling all the time in this season and i can’t fucking stand it.

ahhhhh

he is literally yelling right now and he is just so human-centric and insists on judging everyone else’s culture by his terrible white man moral code.

