---
id: 128857376856
slug: autistic-mom-manages-to-be-both-ableist-and
date: 2015-09-11 17:49:32 GMT
tags:
- current events
- autism
- trans
title: Autistic mom manages to be both ableist and transmisogynist, click to find
  out how!
---
Yes. I know that this is basically a tabloid rag. But. This fucking headline did its job:

> My autistic son watched transgender surgery online and now wants to be female

And this is her question:

> My son, who is 11 years old and has mild autism, has been watching male to female surgery procedures on YouTube. I’ve asked him why and he says he thinks there’s something wrong in his head. He also says he wants to be like me – he seems to think he wants be female.
> 
> I really don’t know what to do. Please help.

I’m not going to get into the answer which seemed somewhat reasonable. But.

Its pretty clear that this woman thinks that being autistic someone means her child is incapable of knowing their own mind or gender. The response also notes that kids at 11 are pretty ‘impressionable’. Except that many studies show that just a little older than 11 is when many ppl settle into the gender ID that is the one they’ll have, more or less, for life.

The thing that gets me, is that she never _once_ considers that maybe her kid actually knows their own gender.

Bleh. I hate everything about this.

( [Original Source. Trigger Warnings for ableism, autism mom, transmisogyny](https://web.archive.org/web/20150911114719/http://www.mirror.co.uk/lifestyle/sex-relationships/relationships/dear-coleen-autistic-son-watched-6420585))

