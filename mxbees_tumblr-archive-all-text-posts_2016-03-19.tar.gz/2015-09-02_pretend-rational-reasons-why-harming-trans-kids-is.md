---
id: 128201328357
slug: pretend-rational-reasons-why-harming-trans-kids-is
date: 2015-09-02 18:44:01 GMT
tags:
- current events
- transmisogyny
- medical industrial complex
title: pretend rational reasons why harming trans kids is great
---
Soo… I caught wind of this on my twitter TL but also in my RSS reader. And… sigh. The writer of this also an Asian woman so I actually feel somewhat compelled to deal with this mess.

The problem with this stuff is that, yes, actual doctors (or in her case a PhD student) are pushing this. They selectively refer to some of the literature on medical transition and kids. Obviously, the studies they refer to exist but they rarely tell the whole story.

Worse yet, articles like this one appear reasonable bc of certain elements of liberal discourse. Especially as pertains to media. We are always told to ‘look at both sides of the story’ and so…

> Now, as a cisgender woman in my thirties and a sex researcher, I follow the current discourse on transgender children’s issues. The predominant narrative is imbalanced and this must be addressed—for the sake of trans children, their families, and medical decision-making.

See? This cis Asian woman _needs_ to speak out to correct the imbalance of ~popular~ opinion. What is this popular opinion?

> Popular opinion suggests that early intervention is the necessary approach in order to remedy a child’s gender dysphoria. This consists of early social transitioning followed by hormone blockers to prevent the otherwise irreversible changes of puberty, contra-sex hormones, and, if desired, eventual sex re-assignment surgery. Denying a child these interventions is viewed as antiquated and cruel.

Speaking of imbalances… wtf is she reading that she thinks _this_ is the popular opinion? I mean… I read a lot of trans news and commentary by people within teh ~community~ and people outside (ie, cis ppl). The depth of which she needs to have her head up her ass to think that the ~popular~ opinion on trans kids is to get them appropriate medical and social care.

This is how we know she’s being disingenuous. Because… to believe the premise of her article, you need to actually think that the majority of people think that the above is the appropriate way to care for trans kids.

But it simply isn’t true. Yes. Amongst advocates and people in the community, this is the prevailing opinion. Yes. Amongst _some_ specialists in the field this is the prevailing opintion. But to call this popular? In any definition or understanding of the word? We all know how small the trans community is. We all know just how fucking hard it is to find adequate medical care. So… if this were the ~popular~ opinion, then us trans adults should be having significantly fewer problems, no? But we know that this isn’t true.

Various jurisdictions aren’t having to legislate against reparative therapy bc its fringe and dying practice. They have to do it because its actually really common. They have to do it because if they don’t _force_ people to stop, they’ll keep forcing their children into it and harming them.

Popular. Fuck u.

> Waiting until a child has reached cognitive maturity before making these sorts of decisions would make the most sense. But this is an unpopular stance, and scientists and clinicians who support it are vilified, not because science—which should be our guiding beacon—disproves it, but because it has been deemed insensitive and at odds with the current ideology.

Okay… but again as noted above. She only refers to _some_ of the medical literature on trans kids and healthcare.

But again, there is a rhetorical sleight of hand here. 'This is an unpopular stance’… really? The funny thing is, is that the stance she credits with being popular – that trans kids have competent access to health care, is _not_ popular? But this is a false dilemma. Because the actual popular opinion is that trans people shouldn’t exist at all. That we are confused. That we need mental help. That none of us should be allowed to transition. _This is what is popular_. Only in a world where trans people aren’t oppressed does her statement actually make any fucking sense.

> I was lucky in that my parents were never troubled by my gender non-conformity. They allowed me to dress how I pleased and to pursue the interests I enjoyed. The only thing they remained firm about was my sitting down to use the toilet, but that was more about the mess I would otherwise make than any socially reinforced gender norms.

How nice. And fuck you.

( [Original Source. Trigger Warnings for medical abuse,transmisogyny,child abuse](https://web.archive.org/web/20150902120956/http://www.psmag.com/health-and-behavior/why-transgender-kids-should-wait-to-transition))

