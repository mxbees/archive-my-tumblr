---
id: 99766348419
slug: watched-the-pilot-for-how-to-get-away-with-murder
date: 2014-10-11 23:20:07 GMT
tags:
- htgawm
- media musings
- racism
title: 
---
watched the pilot for _how to get away with murder_ tonight

and. um….

kind of super annoyed at all the ppl blogging that scene between gay white d00d and hot filipino guy

like. okay. i guess. gay sex! super exciting

or something

anyway.

the scene where filipino guy gets picked up was kinda triggering for me

bc of having to see him preyed on by a conventionally attractive skinny white d00d with beard

the framing that bc he is Asian and, thus, the bottom of the ladder when it comes to attractiveness in the gay world

he TOTES obvs would be super flattered and grateful to receive this attention

his complete resignation about the fact that he figured that white d00d was obviously just using him…

and ppl are all like ‘super hot!’

when the interaction invokes so much of what is fucked up and racist in the gay dating scene.

like.

i don’t think u understand how being a gay asian guy makes u vulnerable to predatory white men.

white men who have this orientalist vision of smooth, docile asian boys

who’ll worship their big white dick

and filipino guys is preyed on. and OF COURSE shown to be sexually 'submissive’.

i don’t think u get it.

when i was in the gay dating scene

i totally let myself get used like this

bc sometimes i’d get desperate for some human contact. you know. feel lonely.

and a lot of the times the only gay men who’d pay any attention to me were predatory, older white men looking for a china doll.

and sometimes ur weak. and all u want is to feel attractive for a few seconds. some artificial/fleeting intimacy. but you know

you _know_

that this white man is ugly and beneath u. u know that all he can see is a fantasy of white supremacy dancing in his eyes….

u **know**

and still…

u do it.

bc it might be a year before anyone who might actually care bothers to talk to you again. and tonight. tonight ur sad and lonely.

anyway.

fuck that scene. and fuck all the ppl watching this show who’re fapping themselves to cute white gay guy

when there is about a million more interesting characters on the show.

