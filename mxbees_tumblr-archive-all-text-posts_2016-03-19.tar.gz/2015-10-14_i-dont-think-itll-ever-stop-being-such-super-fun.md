---
id: 131125113214
slug: i-dont-think-itll-ever-stop-being-such-super-fun
date: 2015-10-14 01:18:50 GMT
tags:
- klass with a k
- op
title: 
---
i don’t think it’ll ever stop being such super fun thing to see whites continuously attempt to frame class as equivalent to race (or sometimes worse).

like i get why they are so invested in this line of argument…

but. god. i get tired of it.

like reading that one professor at harvard who swore that poor white ppl were the most disadvantaged when it came to admissions.

anyway. i hate u all.

