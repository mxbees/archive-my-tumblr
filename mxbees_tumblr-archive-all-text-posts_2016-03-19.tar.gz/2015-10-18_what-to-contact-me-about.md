---
id: 131416469129
slug: what-to-contact-me-about
date: 2015-10-18 13:53:29 GMT
tags:
- the life of an ordinary bakla
title: what to contact me about…
---
I updated my ‘about’ page, now that I am doing public appearances, I’m willing to do more in the future. But only if they meet the following criteria.

Now that I am doing public appearances, I will consider doing a thing depending on what that thing is. I’m still agoraphobic and generally don’t like travelling. Getting me to push past this will, at the very least, require airfare, accommodation, and an honorarium (I also live in Canada, so flights will be more expensive to the US).

As a general principle, as well, I tend to think things like this are wasteful and unsustainable. I’m fairly certain that wherever you’re thinking of inviting me, there is a twoc there who’d _love_ the opportunity and could use the money. Given my relative privileges if I know of someone local to you who is awesome, I’ll likely tell you to contact them and turn down the invitation Alternatively, if you really really insist on me being there and there is a twoc I know who lives in the area, I’ll expect them to be invited and given my honorarium (I’ll do it for travel expenses and accommodation).

If you want me to write something on a specific topic, support my patreon, since one of my milestones there was content requests. I won’t do interviews or write for mainstream publications. Otherwise, feel free to contact me about stuff. I’ll answer to the best of my abilities (and within some time frame between a few days and never). I’m not great at actually doing social… so I may not become your best friend.

