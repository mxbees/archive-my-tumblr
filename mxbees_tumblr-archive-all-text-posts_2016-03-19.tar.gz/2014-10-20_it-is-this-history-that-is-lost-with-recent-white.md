---
id: 100538264734
slug: it-is-this-history-that-is-lost-with-recent-white
date: 2014-10-20 23:25:37 GMT
tags:
- race to the bottom
title: 
---
it is this history that is lost with recent white media coverage about mixed-with-white poc

this history where we’ve existed for centuries

and

for centuries

we’ve been systematically privileged over full poc

this is our history.

