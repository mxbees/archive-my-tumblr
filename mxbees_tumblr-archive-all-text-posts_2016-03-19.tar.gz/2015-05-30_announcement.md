---
id: 120285907009
slug: announcement
date: 2015-05-30 18:57:29 GMT
tags:
- transmisogyny is fun for the whole family
title: Announcement
---
[chrysalisamidst](http://chrysalisamidst.tumblr.com/post/120284575233):

> [joyceanfartboner](http://joyceanfartboner.tumblr.com/post/120284151016/announcement):
> 
> > [the-fourth-baudelaire](http://the-fourth-baudelaire.tumblr.com/post/120283995952/announcement):
> > 
> > > [joyceanfartboner](http://joyceanfartboner.tumblr.com/post/120283647551/announcement):
> > > 
> > > > [the-fourth-baudelaire](http://the-fourth-baudelaire.tumblr.com/post/120283006917/announcement):
> > > > 
> > > > > I am a woman. I would like to exercise my right to freedom of speech and say in no uncertain terms I would feel at risk and unsafe in a unisex toilet. I do not want to share a bathroom with anyone with a penis. It is not wrong that I feel this way nor is it transphobic.
> > > > 
> > > > actually it is transphobic. why do you think you get to decide what is and isnt transphobic. jw
> > > 
> > > Because babe, it has nothing to do with whether it not a someone is trans or cis. Its purely about women feeling safe. And you don’t get to decide it’s wrong for a woman to express these concerns.
> > 
> > youre transphobic. just an fyi for ya. youre a transmisogynist and i pray you never have a trans child.
> 
> And infantilizing as hell.

i can’t stop laughing at this

‘i am a woman and i would like to exercise my right to free speech’

ok.

you said your piece. and it and you are transmisogynist. this is my exercising my right to free speech.

we’ve now both said what we’ve wanted.

democracy!

