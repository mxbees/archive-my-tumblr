---
id: 130983098479
slug: honestly-i-dont-even-bother-to-look-at-most-of
date: 2015-10-11 23:57:36 GMT
tags:
- klass with a k
- op
title: 
---
honestly. i don’t even bother to look at most of the ‘cruelty free’ 'ethical’

makeup/food/whatever

posts

it isn’t just that

~there is no ethical consumption in capitalism~

but its just plain exhausting and overwhelming

beyond the reality that i buy what i can afford, regardless of how ethical it may or may not be

i simply don’t have the cognitive capacity to remember it all. what do ppl expect us to do when they make a long list of stuff you can/cant buy?

memorize? print it out?

are we supposed to see if any/every product we buy can be traced back to some giant conglomerate that is less awful than the others?

bleh. i’m just a cranky baby tonight.

