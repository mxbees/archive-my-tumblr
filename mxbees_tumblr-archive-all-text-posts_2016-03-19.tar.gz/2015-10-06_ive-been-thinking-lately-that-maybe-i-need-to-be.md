---
id: 130647330414
slug: ive-been-thinking-lately-that-maybe-i-need-to-be
date: 2015-10-06 23:36:31 GMT
tags:
- the life of an ordinary bakla
- discussing discourse
- op
title: 
---
i’ve been thinking lately that maybe i need to be more sympathetic to ppl in the closet.

i mean. it isn’t that i’m not sympathetic to actual human beings in the closet, but i do spend a lot of time mocking the mega-butch-masc men in teh closet in the mm books i read.

i don’t really have a lot of sympathy for a white, cis, butch man in the closet. i literally don’t get it.

actually. on reflection it isn’t that i don’t have sympathy, i just really really cannot understand it. i can understand why qtpoc often need to stay in the ‘closet’. i can understand why ppl living in rural areas or with conservative parents. i can understand why youth of any kind might stay in the closet until they are more independent.

what i can’t understand is adult men who are privileged in pretty much every other way (than their sexuality) staying in the closet.

i just don’t get it.

although, even with the stuff i do get, i can’t really identify with any of it.

i never really had to 'come out’. all my life i’ve been femme and ppl have been asking me if i was gay. my dad first asked me when i was like eight or something. i got bullied for it. then i started wearing skirts and makeup and whatever in highschool and that was that.

the closet is like this… conceptual construct in my brain. i can understand its function and how it works, but i don’t really know what its like on the inside.

omg i just googled it. 'national’ coming out day is on october 11. lol. i’m a little premature here.

i’m not trying to set up a value system here, though. me not understanding something is not me condeming. you don’t owe coming out to anyone, esp. not a 'community’ that is more likely to toss you under the bus than provide any real, substantive support. i also don’t think that being in the closet is… dishonest or whatever the fuck.

live ur life, do what you want, and stay safe.

