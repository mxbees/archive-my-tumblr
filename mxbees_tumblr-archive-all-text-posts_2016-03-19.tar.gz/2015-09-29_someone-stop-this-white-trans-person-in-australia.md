---
id: 130146117994
slug: someone-stop-this-white-trans-person-in-australia
date: 2015-09-29 18:44:24 GMT
tags:
- current events
title: Someone stop this white trans person in australia
---
I actually got clued into this story via reading some random pro-life white woman’s anti-trans garbage. And while I normally would’ve focused on that, she quotes this part of this story:

> The 43-year-old, who is biologically female but identifies as gender diverse, has grown used to it.
> 
> “I identify with the concept of a walker, which is a Native American term for someone who walks between genders. At any point people will call me male, or sir, which is great when you’re buying a car,” she joked, “But I’m just as comfortable in a group of women.”

Oh. I see.

Don’t do this white people. Just don’t.

( [Original Source. Trigger Warnings for appropriation, racism, homophobia, reparative therapy](http://web.archive.org/web/20150929102813/http://www.theage.com.au/victoria/fighting-for-equality-meet-victorias-new-sexuality-and-gender-commissioner-20150828-gj9zo3.html))

