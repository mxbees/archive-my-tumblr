---
id: 128863238977
slug: im-somewhat-miffed-by-that-white-trans-woman
date: 2015-09-11 19:38:34 GMT
tags:
- race to the bottom
- op
title: 
---
i’m somewhat miffed by that white trans woman getting a settlement for being asked ‘what are you?’ in a job interview

not bc i don’t think she deserves it or whatever

its just that white ppl have been asking me that fucking question ever since i can remember

in the story, she mentions that it was like a punch to the gut

for me?

this question is so mundane that it barely registers

indeed, i think it was only a few years ago that i really realized just what a shitty dehumanizing question that is

and i know that i’m not the only poc whose been asked this question over and over and over again.

whatever.

i’m a bitter petty petty princex.

