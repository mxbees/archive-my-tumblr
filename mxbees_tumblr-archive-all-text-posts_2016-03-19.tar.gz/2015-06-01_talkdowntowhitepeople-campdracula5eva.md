---
id: 120432257979
slug: talkdowntowhitepeople-campdracula5eva
date: 2015-06-01 10:35:22 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[talkdowntowhitepeople](http://talkdowntowhitepeople.tumblr.com/post/114953547625/campdracula5eva-softgender-the-reason-people):

> [campdracula5eva](http://campdracula5eva.tumblr.com/post/54277880576/softgender-the-reason-people-think-that):
> 
> > [softgender](http://softgender.tumblr.com/post/54207104794/the-reason-people-think-that-only-mostly-gay-men):
> > 
> > > the reason people think that only/mostly gay men are pedophiles is that **the only time pedophilia is really demonized in the west is when its towards boys** ; _**sexual attraction towards young girls (or bodily features/clothing used to indicate youth like pigtails and school girl uniforms) by straight men is encouraged and seen as healthy and normal**_
> > 
> > Wow. Never heard that connection made before. Seems obvious now.
> 
> WHOA

this sounds like a meaningful observation…..  
  
but doesn’t actually explain why the current bathrooom panic about trans women using women’s restrooms or change rooms.

