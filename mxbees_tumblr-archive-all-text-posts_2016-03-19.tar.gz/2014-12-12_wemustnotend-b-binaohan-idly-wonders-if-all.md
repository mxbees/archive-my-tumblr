---
id: 105009311279
slug: wemustnotend-b-binaohan-idly-wonders-if-all
date: 2014-12-12 15:03:23 GMT
tags:
- race to the bottom
- epilepsy warning
title: 
---
[wemustnotend](http://wemustnotend.tumblr.com/post/105004299115/b-binaohan-idly-wonders-if-all-the-rebellious):

> [b-binaohan](http://xd.binaohan.org/post/104958653094/idly-wonders-if-all-the-rebellious-body-modders):
> 
> > \*idly wonders if all the rebellious body modders realize that the counter-culture nature is bc of the cultural iaopoc roots of body mods\*
> 
> I hope that if anyone thinks this about me, that they would take the time to educate me on any information I may not have about the origins of my body mods, so I can appreciate them better and in turn, better inform the people around me!

![](https://38.media.tumblr.com/74d720148ef406c2edcda8f8e65eb322/tumblr_inline_ngh5q2vE3a1rdzs46.gif)

um…

maybe u should educate urself before getting body mods?

or at least recognize that there are literally _zero_ body mods that white ppl can get that don’t have their roots in iaopoc culture?

and the idea that, even if it were our job to educate you, that we would do so so that you can better ‘appreciate’ your stolen piece of culture is just….

special

