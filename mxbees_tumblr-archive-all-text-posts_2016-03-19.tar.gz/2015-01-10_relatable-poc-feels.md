---
id: 107717490314
slug: relatable-poc-feels
date: 2015-01-10 20:26:26 GMT
tags:
- race to the bottom
title: 'relatable poc feels '
---
[quagsires](http://quagsires.tumblr.com/post/107593740619/relatable-poc-feels):

> when u take food of your culture to school abd every white kid is like EWWW WHAT THE FUCK IS THAT

only to grow up and then have white ppl u don’t know try and tell u all about ur food

