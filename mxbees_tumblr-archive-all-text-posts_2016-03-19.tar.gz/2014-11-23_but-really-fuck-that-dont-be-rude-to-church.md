---
id: 103365817729
slug: but-really-fuck-that-dont-be-rude-to-church
date: 2014-11-23 13:25:00 GMT
tags:
- decolonization nao
title: 
---
but really

fuck that

‘don’t be rude to church member who would let u freeze to death’

gee

let me look in my emily post book for how to deal with oppressors

\*searches index\*

hmm…

the only mention i can find is

404 'fuck not found’

