---
id: 101044192189
slug: glob-remember-that-time-some-awful-girl-told-me
date: 2014-10-27 00:45:29 GMT
tags:
- the life of an ordinary bakla
title: 
---
glob.

remember that time some awful girl told me that

i had

~begging for money privilege~

remember that shit?

BEGGING for money PRIVILEGE

