---
id: 103719046084
slug: i-have-to-be-sooo-careful-about-which-teen-wolf
date: 2014-11-27 13:08:48 GMT
tags:
- media musings
title: 
---
i have to be sooo careful about which teen wolf podfics or stories i listen to these days. after pretty much getting fucking fed up with the unrelenting racism of the fandom and how much i _hate_ stiles as a result…

my tolerance is pretty low. even as i can still enjoy some sterek stuff, despite how much i hate stiles.

and my beef really is with stiles. like. i don’t understand why most sterek stuff is written from stiles’s point of view or is stiles-centric. of all the teen wolf characters he is probably the least compelling. but whatever.

what is getting me from last night’s story is the way that a lot of fic writers will inject stiles with their faux-progressive outlooks on sexuality/gender.

‘stiles is bi! so much more progressive than gay’

or whatever. like i don’t even care that they make him bi. that isn’t the issue.

the issue is how in the future/college fic i listened to yesterday, he gets all hopped up on queer activism and queer theory

and is all 'i get how safe space works. but whatever my gender performance i still have a dick and this doesn’t make me feel safe’ re: a space for women…

like. fuck u all and ur fucking transmisogyny (see also all the stories involving stiles and drag/crossdressing).

i like how, in ur imaginations, stiles is progressive because he shits on transwomen.

lol.

i hate u.

