---
id: 113154293554
slug: tw-transmisogyny
date: 2015-03-09 09:40:57 GMT
tags:
- gif warning
- epilepsy warning
title: 'tw: transmisogyny'
---
[dyspear](http://dyspear.tumblr.com/post/113149137836/blucantrellvevo-dyspear-blucantrellvevo):

> [blucantrellvevo](http://blucantrellvevo.tumblr.com/post/113148938751):
> 
> > [dyspear](http://dyspear.tumblr.com/post/113148865126/blucantrellvevo-buckwheatrye-blucantrellvevo):
> > 
> > > [blucantrellvevo](http://blucantrellvevo.tumblr.com/post/113148769526):
> > > 
> > > > [buckwheatrye](http://buckwheatrye.tumblr.com/post/113148698339/blucantrellvevo-traumatized-by-penis-im-out):
> > > > 
> > > > > [blucantrellvevo](http://blucantrellvevo.tumblr.com/post/113146790551):
> > > > > 
> > > > > > “traumatized by penis” i’m out&nbsp;
> > > > > 
> > > > > i don’t know how you can disregard and shit on rape victims like this
> > > > > 
> > > > > you should be ashamed of yourself
> > > > 
> > > > dfjsgsdfhgsjnbsdfg why are you all pressuring me to relive my own trauma idk why yall are so obsessed with harassing trans women to our breaking points?&nbsp;
> > > 
> > > WHAT DOES YOU BEING A TRANS WOMAN HAVE TO DO WITH THIS ITS ABOUT YOU SHITTING ON RAPE VICTIMS NOT BECAUSE YOURE A TRANS WOMAN SHUT UP
> > 
> > I HAVE A LOT OF RAPE RELATED TRAUMA MY ENTIRE SEXUAL LIFE HAS BEEN A LONG CHAIN OF TRAUMATIC EXPERIENCES AND I DONT WANT TO TALK ABOUT IT&nbsp;
> > 
> > STOP FUCKING TALKING TO ME BEFORE I LOSE IT&nbsp;!! IM SICK OF YOU FUCKERS MAKING SHIT UP ABOUT WHAT I CARE ABOUT!&nbsp;
> 
> okay same buddy that doesnt change that fact that youre saying anyone repulsed by penises is transmisogynistic (^: which is gross and disgusting

![](http://g.nmp.pw/index.php?album=FU&image=FU_GloryHitByTruck.gif)

