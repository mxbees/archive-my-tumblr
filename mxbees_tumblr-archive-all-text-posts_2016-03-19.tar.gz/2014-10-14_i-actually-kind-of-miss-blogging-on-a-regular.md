---
id: 100031215544
slug: i-actually-kind-of-miss-blogging-on-a-regular
date: 2014-10-14 23:22:19 GMT
tags:
- the life of an ordinary bakla
title: 
---
i actually kind of miss blogging on a regular basis.

life has me so buzy. busy enough that what time i have for writing, i try to spend it on my books.

except that i remember that i started biyuti publishinig bc i wanted to try and make money off of my already existing posts by compiling them into ebooks.

but now i’m just not blogging and only working on my books.

which kind of suck bc i actually want my target audience to read my stuff for free.

(also still struck by the notion that some ppl still don’t know who i am re; my previous ‘brand’ name. like. i’m glad i did what i did. and i had my reasons for it. but i also still feel like i’m trying to rebuild my audience)

i still like having a distinct blogging space outside of tumblr, but i’m now considering migrating my blog content back into tumblr. in part bc this is the space where ppl really look for me first. and i could put some of my older posts back into rotation…. which would be really strange.

