---
id: 101500472064
slug: um-so-i-cant-tell-if-i-just-received-a-sign
date: 2014-11-01 16:40:58 GMT
tags:
- the life of an ordinary bakla
title: 
---
um…

so i can’t tell if i just received a sign that i shouldn’t leave an offering for my lolo and lola tonight

or if they are mad that i haven’t done it sooner

i was posting something to tumblr about the day of the dead and how i was going to leave an offering

and my computer crashed

(i use linux, and i swear this is the first time i’ve crashed the entire thing and i wasn’t even doing anything particularly impressive)

