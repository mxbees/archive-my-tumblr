---
id: 128364554084
slug: omg-why-wont-tumblr-let-me-write-in-markdown-on
date: 2015-09-04 23:27:20 GMT
tags:
- the life of an ordinary bakla
title: 
---
Omg. Why won’t tumblr let me write in markdown on mobile or change the editor on a post that already exists.

