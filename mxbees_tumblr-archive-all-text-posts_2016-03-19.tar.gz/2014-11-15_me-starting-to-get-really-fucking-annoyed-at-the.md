---
id: 102657008874
slug: me-starting-to-get-really-fucking-annoyed-at-the
date: 2014-11-15 02:22:36 GMT
tags:
- teh trans community
title: 
---
me: starting to get really fucking annoyed at the puberty blocker post going around…

why?

well….

the assumptions of the post

like. yes. obviously all trans ppl (young or old) should have easy and sufficient access to healthcare (trans related or not)

what irritates me is the subtle reification of the white, medical model of transness

that being trans necessarily is all about access to medical interventions

that _this_ is what will make the key difference in the experience of trans kids

but nothing about how dismantling harmful structures of transmisogyny

would not only help trans kids

but trans adults

the trans experience is larger and more vast than what medical interventions we seek or do not seek

look. i have a trans niece and i definitely hope she is able to access puberty blockers if this is what she wants.

but i also want to let her know that her womanhood is not contingent or even related to the container that is her body

i also want to fight for a world where (racist) transmisogyny is dismantled so that however she ends up embodying her womanhood

she’ll be safe, secure, and supported

i want her to know that it isn’t white medical procedures that make her a girl/woman

i want her to know that our ppl have a history of #girlslikeus

that is also spiritual and cultural and social

and that she’ll be cherished and valued

just for existing

