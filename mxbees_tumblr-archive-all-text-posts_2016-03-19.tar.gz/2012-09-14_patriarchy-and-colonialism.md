---
id: 127936535304
slug: patriarchy-and-colonialism
date: 2012-09-14 04:00:00 GMT
tags:
- i rebuke thee feminism
title: patriarchy and colonialism
---
I remember what I was going to write!

Not too long ago I wrote a post about the inherent white supremacy of [r]dfmnism and had a condescending ask (from someone with \*years\* of research) about what I considered a non-patriarchal&nbsp;society.&nbsp;

Interesting question and one I actually address. Well, kinda.

Because the question itself, beyond the baiting, asks me to come up with an example and prove that it wasn’t patriarchal… which presupposes the primacy and supremacy of the ‘patriarchy’ as a lens through with to view societies in the first place. It presupposes a binary gendered system that (even in counterexamples of matriarchies or whatever) presupposes that societies with genders must always (always!) be organized in some oppressive manner.&nbsp;

So. Yeah, in part, as far as I’m concerned non-patriarchical societies = any society that existed outside of the colonial white hetero-patriarchy. A theoretical perspective that claims otherwise is only asserting the supremacy of white academic shit and I don’t actually give a fuck about what the white academy has to say about anything.&nbsp;

Let us use an example that white people \*love\* to trot out when talking about the barbaric ‘patriarchy’ of poc cultures: foot binding in the Qing Dynasty. A terrible practice for many reasons. But is it an example of white heteropatriarchy? Is it? Can the gender relations of a Dynasty that ended a century ago and start about four hundred years ago only be intelligently understood using european models of gender relations?&nbsp;

So. I’m gonna take the asshole route and shift the burden of proof.&nbsp;

Prove to me that the Qing Dynasty was patriarchical \*without\* relying on \*any\* anachronistic and white theory of gender relations and power. Moreover, prove it to me without resorting to 100% liberal cultural relativism (which is also a bullshit white theory).&nbsp;

I will never, ever accept that white theories and white critical perspectives are the only way by which history and humankind can be understood. I will never accept them as default nor as defacto truths, for lack of something better.&nbsp;

(bonus points for anyone who can make a clear case for patriarchy in societies that include more than two kinds of gender without relying on any white ideas — note: this also includes all of Imperial China).&nbsp;

(note: I’m most certainly not trying to say that the women of the Qing Dynasty were oppressed or not. Not at all. this is more about drawing attention to the notion that ‘patriarchy’ as commonly used is a product of anthropology, gender studies, feminism, etc,… all white disciplines and often accepted as universal truth about humanity. if anyone ever wants me to disprove their ‘universal’ notion — patriarchy — i want proof, real proof, that this is a universal idea that applies to all societies (or a sufficient amount) and all times (or a sufficient amount) that doesn’t rely heavily on white academic colonial theories).&nbsp;

