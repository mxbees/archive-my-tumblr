---
id: 128120980423
slug: 200-of-lila-perrys-classmates-walk-out-to-protest
date: 2015-09-01 17:49:39 GMT
tags:
- current events
- trans bathroom panic
- trans youth
title: 200 of Lila Perry's classmates walk out to protest how she's being treated
---
> Until recently, she’d been changing for gym class in the girl’s bathroom. She says concerns about her safety and threats from other girls led her to drop gym class and quit changing in the girls locker room.
> 
> Close to 200 students walked out of class Monday morning, some voicing support for Perry, others expressing their displeasure.

( [Original Source. Trigger Warnings for transmisogyny, surgery mention, racist analogy, anti-Blackness](https://web.archive.org/web/20150901124858/http://www.kspr.com/news/local/missouri-students-walk-out-over-transgender-locker-room-dispute/21051620_35029886))

