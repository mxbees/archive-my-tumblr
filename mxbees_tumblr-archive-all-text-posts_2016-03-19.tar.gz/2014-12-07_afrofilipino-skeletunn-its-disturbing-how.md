---
id: 104571789954
slug: afrofilipino-skeletunn-its-disturbing-how
date: 2014-12-07 11:30:12 GMT
tags:
- epilepsy warning
- gif warning
- gifset
title: 
---
[afrofilipino](http://afrofilipino.tumblr.com/post/104569629326):

> [skeletunn](http://skelet0n.net/post/104569427278/its-disturbing-how-easily-people-will-ignore-the):
> 
> > its disturbing how easily people will ignore the fact that we, as trans men, are not suddenly immune from misogyny because we identify as men.&nbsp;
> > 
> > ~ null
> 
> So what youre saying is. you get misgendered

![](https://33.media.tumblr.com/f56c2791314e1622812a2b607e884668/tumblr_inline_ng7mm4z8rQ1rdzs46.gif)

