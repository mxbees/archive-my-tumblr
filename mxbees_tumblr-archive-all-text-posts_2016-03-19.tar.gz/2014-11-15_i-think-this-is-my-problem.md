---
id: 102684698739
slug: i-think-this-is-my-problem
date: 2014-11-15 11:51:49 GMT
tags:
- transmisogyny is fun for the whole family
- teh trans community
title: 'I think this is my problem. '
---
[sofriel](http://sofriel.tumblr.com/post/102664396579/i-think-this-is-my-problem):

> Helping kids pass for cis via early hormones and thus avoid transmisogyny because no one knows they’re trans does not _solve_ transmisogyny.&nbsp;
> 
> This isn’t to condemn the kids themselves—I am 100% for trans kids doing whatever they need to do to survive. But the adults promoting medical solutions as the Ultimate Answer to trans issues without bringing up anything else? They are giving cis people an easy out by refusing&nbsp;to make them challenge the cissexist (and racist/colonial, too) definitions of gender that are systematically enforced on every person.&nbsp;
> 
> This is issue with the Harry Benjamin people, the truscum, whatever they are calling themselves, it’s the same ideology—they are just as invested in upholding that cissexist system. They know that the system can’t bend enough to accept everyone it currently rejects, but if they make themselves as acceptable to its standards as possible, they can beg it to bend just enough to let them in. But this requires them to denigrate the people who can’t reach that almost-cis-acceptable level, to draw and emphasize the distinction between themselves and those _other_ ones.
> 
> That’s why they’re so obsessed with the idea of “limited resources” and “being taken seriously.” The rest of us know that we will never be sufficiently acceptable to the system as it stands, and HB/truscum know it too—and they are terrified of being categorized with us, because if cis people associate them with us, then they will lose whatever privilege they managed to grab a hold of.&nbsp;
> 
> For the rest of us, the only real hope is to completely destroy and transform the system itself. To make all people acknowledge that trans womanhood is as genuine an expression of womanhood as cis womanhood is. As it stands, even most ‘sympathetic’ cis people still understand trans women as ‘aspiring to be cis women’; their womanhood is only deemed valid as it relates to ‘true’, cis womanhood.&nbsp;Medical model advocates cater to this attitude by&nbsp;claiming they want to conform to cisness as much as possible, there’s just a few barriers in the way, letting cis people feel they can safely leave their trophy of cissexism unchallenged.&nbsp;
> 
> Actually destroying cissexism, of course, is a hell of a job, and it would require also questioning the systems of racism, colonialism, misogyny, economic oppression, etc that are twisted up in it. It’s so much easier, isn’t it, to pretend that making hormones available to a young white girl from a financially stable family at a well-funded school is the only thing necessary to liberate her, rather than address those of us facing a more tangled kind of oppression.&nbsp;

ack!

so eloquently (and succinctly) expressing my feels about this

bc yes.

this is an assimilationist strategy

and HBSers are totally unashamed about this

(what with their insistence that after all the surgeries and hormones that they aren’t trans anymore and they also usually cut themselves off from the community – unless it is to try and control the rest of us)

