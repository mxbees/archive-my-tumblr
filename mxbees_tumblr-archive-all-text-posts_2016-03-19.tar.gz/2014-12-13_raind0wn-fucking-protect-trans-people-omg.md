---
id: 105080779864
slug: raind0wn-fucking-protect-trans-people-omg
date: 2014-12-13 11:30:05 GMT
tags:
- teh trans community
title: 
---
[raind0wn](http://raind0wn.tumblr.com/post/103132935155/fucking-protect-trans-people-omg-like-a-fucking):

> fucking protect trans people omg
> 
> like, a fucking life expectancy of 30 fucking years is shameful
> 
> this is not some “overdramatic tumblr shit” i literally do not care about your feelings but fucking protect trans people, fuck hate crimes fuck bigots.
> 
> call your friends out on their anti trans shit, call your friends out on their fucked perception of gender.make your spaces trans accepting and safe, don’t invade trans spaces
> 
> FUCKING PROTECT TRANS PEOPLE

clicking on the OP shows that they are probably white and not a trans woman of colour

so….

let’s talk about the erasure of _who_ exactly is dying from trans\_misogynist\_ violence?

especially since her original tags include #tdor2014

so….

how do you make a tdor post and _not_ recognize that it is **trans women of colour** who are dying???

(globally: the list is half Brazillian twoc which most likely means: mostly Black Latina trans women……..)

it isn’t trans ~people~

who need to be protected

but

trans _women of colour_.

fucking get it right asshole

