---
id: 129091533784
slug: laverne-cox-on-trans-is-beautiful
date: 2015-09-14 19:38:46 GMT
tags:
- current events
- laverne cox
- Black trans women thriving
- twoc thriving
title: Laverne Cox on trans is beautiful
---
> “I started a hashtag earlier this year called #transisbeautiful,” she said. “And I started that because years ago, at the beginning of my transition, I would walk down the street and I would hear people yell, ‘that’s a man.’ And I would be devastated. Because here I was, I had finally accepted my womanhood, and the world was not reflecting that back on me and I was devastated.
> 
> "It took me years to fully internalize that someone can look at me and tell that I am transgendered and that is not only okay, but beautiful, because trans is beautiful. All the things that make me uniquely and beautifully trans—my big hands, my big feet, my wide shoulders, my deep voice—all of these things are beautiful. I’m not beautiful despite these things, I’m beautiful because of them.”
> 
> She ended by encouraging everyone else to join in on the #transisbeautiful movement. “I would like to encourage every single one of you in this room to join with me in showing the world that trans is beautiful, in terms of how we cover trans stories and diverse stories in general,” said Laverne. “There are so many different kinds of beauty in the world that I want to celebrate and I know you want to celebrate it, too.”

( [Original Source. Trigger Warnings for](http://syx.pw/1QclHoM))

