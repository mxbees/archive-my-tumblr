---
id: 103579828044
slug: wow-going-through-tumblr-at-work-and-with
date: 2014-11-25 21:16:12 GMT
tags: []
title: 
---
wow. going through tumblr at work and with safedash on and realizing just how… inaccessible tumblr must be for anyone who can’t see. i mean. everything is images now. even like, screencaps of text, rather than actual text. :(

