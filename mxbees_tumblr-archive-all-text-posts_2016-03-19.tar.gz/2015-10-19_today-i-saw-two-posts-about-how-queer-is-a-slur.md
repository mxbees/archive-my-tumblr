---
id: 131502008439
slug: today-i-saw-two-posts-about-how-queer-is-a-slur
date: 2015-10-19 18:37:02 GMT
tags:
- teh queer community
- op
title: 
---
today i saw two posts about how queer is a slur and ppl should act accordingly…

of course, both posted after i wrote about this and got harassed over it.

(yes, i just spent 15 minutes looking through my archives to verify this before writing about it. i mentioned this on twitter and tumblr at least as early as april of this year. the two posts i saw where in the first week of august.)

i don’t know anything about the OPs.

i’m just pointing out that i see how this is.

i wonder if the OPs have gotten as much harassment over their posts as i have. (i hope not bc no one deserves it).

and, sure, i’m not the first person to point out that queer is, in fact, a slur.

just find it interesting that mere months after i talked about the thing, i’m seeing popular tumblr posts about it.

