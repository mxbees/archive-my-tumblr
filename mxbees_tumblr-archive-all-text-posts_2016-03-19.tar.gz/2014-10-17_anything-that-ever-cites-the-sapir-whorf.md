---
id: 100265582827
slug: anything-that-ever-cites-the-sapir-whorf
date: 2014-10-17 21:01:27 GMT
tags:
- linguistic determinism can suck it
- classical biyuti
title: 
---
anything that ever cites the sapir-whorf hypothesis is immediately suspect to me.

re: that quote i just saw on ‘nice guys’

seriously?

This hypothesis is constantly used to justify some of the most ridiculous scholarship on IaoPoC cultures.

I literally have read \*books\* fucking \*BOOKS\* claiming that Chinese philosophy (and, thus the people really) have no concept of truth because there is no single character/word that is easily or straightforwardly translated as 'truth’ (as far as english is concerned).

linguistic determinism is fucking bullshit. and, from my experience, often Orientalist or racist.

it is a garbage hypothesis created by bullshit linguists

(and no, i odon’t care what they 'meant’ with this hypothesis, not when i see how much damage its interpretations has done)

