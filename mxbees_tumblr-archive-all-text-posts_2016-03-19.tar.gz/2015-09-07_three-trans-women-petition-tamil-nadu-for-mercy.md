---
id: 128583642982
slug: three-trans-women-petition-tamil-nadu-for-mercy
date: 2015-09-07 20:33:14 GMT
tags:
- current events
- discrimination
- transmisogyny
- mercy killing
title: Three Trans Women petition Tamil Nadu for mercy killing
---
> Three Indian transgender women have begged for mercy killing rather than live lives of discrimination. Frustrated with the government assistance and job opportunities, Grace Banu, Living Smile Vidya and Angel Glady submitted their petition to Tamil Nadu state on Friday (4 September).
> 
> ‘If we are considered third rate citizens, if we can’t sustain our livelihood with dignity, then let us die with dignity,’ Vidya wrote on Facebook.
> 
> ‘I tried to get financial assistance from the government to lead my life with dignity,’ Banu, who is studying engineering, told The Hindu newspaper.
> 
> ‘I do not want to beg or carry on with the other tasks traditionally associated with transwomen in society. I have never thought of doing such work for a living.’

( [Original Source. Trigger Warnings for violence, discrimination, transmisogyny, mercy killing](http://web.archive.org/web/20150907112200/http://www.gaystarnews.com/article/trans-indians-beg-for-mercy-killings-rather-than-lives-of-discrimination/))

