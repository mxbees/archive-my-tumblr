---
id: 102626888784
slug: fiendangelical-painfullysober-know-whats
date: 2014-11-14 19:16:14 GMT
tags:
- decolonization nao
- may is as mayo does
title: 
---
[fiend–angelical](http://fiend--angelical.tumblr.com/post/102624486941/painfullysober-know-whats-really-willfully):

> [painfullysober](http://painfullysober.tumblr.com/post/102623887776/know-whats-really-willfully-ignorant-assuming):
> 
> > Know what’s really “willfully ignorant?” Assuming that past mistakes by anthropologists and other researchers were SOLELY the result of sexism and clinging to gender norms and not at all the result of technology and resources that were far less advanced than what we have now.
> 
> This just in; destroying evidence en masse and deliberately stealing from women’s discoveries and inventions is technology’s fault.

okay…  
  
supposing this argument is true…  
  
what is the excuse for the rampant racism, white supremacy, and misogyny of (white) anthropologists today??????  
  
how is it that in this technologically ‘advanced’ context we’ve managed to create whole new disciplines to help cover the ground of anthros of old?  
  
(see evo psych, cultural psych, etc)  
  
maybe it is bc teh white academy is less invested in 'discovering’ knowledge and more about re/producing colonial hetpatriarchical power structures…

