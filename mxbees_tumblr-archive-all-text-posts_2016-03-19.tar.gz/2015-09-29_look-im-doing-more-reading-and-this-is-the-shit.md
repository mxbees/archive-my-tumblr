---
id: 130133146459
slug: look-im-doing-more-reading-and-this-is-the-shit
date: 2015-09-29 14:26:45 GMT
tags:
- race to the bottom
title: 
---
look. i’m doing more reading and this is the shit i’m reading:

> Historians such as Quinn, Jones, Canny and Muldoon argue effectively that racism amont Europeans is not limited to the relations with non-Europeans, but that it can exist in the most extreme form between one European nation, such as England, and another, such as Ireland.<sup id="fnref:p130133146459-1"><a href="#fn:p130133146459-1" rel="footnote">1</a></sup>

the _most_ extreme form of european racism is between white ppl?

not, say, idk, the race of ppl they decided were property?

like. this is scholarship today?

* * *

1. 
  1. Racism : Essential Readings. London, GBR: SAGE Publications Ltd, 2001. [http://site.ebrary.com/lib/alltitles/docDetail.action?docID=10715709.](http://site.ebrary.com/lib/alltitles/docDetail.action?docID=10715709.)

↩

