---
id: 130893020144
slug: its-weird-i-know-some-ppl-who-think-that-saying
date: 2015-10-10 18:24:21 GMT
tags:
- discussing discourse
- op
title: 
---
its weird. i know some ppl who think that saying ‘u can’t say x word, bc its ableist’ is a really white thing. and i agree to a certain point.

but i also think it is a privileged and/or white thing for ppl to say that words don’t matter bc there are ~real issues~.

bc. like. as a person who is the target of several racial/gender slurs.

sure. no. insisting that ppl don’t call me racial slurs doesn’t 'solve’ racism. and not calling me a slur is about the bare minimum of human decency.

but you know. it just so happens that not being called slurs actually improves the quality of my life.

who knew??

