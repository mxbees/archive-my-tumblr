---
id: 107809854214
slug: quick-reminder-for-the-ppl-whore-finding-this
date: 2015-01-11 18:48:33 GMT
tags:
- race to the bottom
title: 
---
quick reminder for the ppl who’re finding this page after medievalpoc reblogged that post on scientific racism…

relaying historical information does not mean i’m endorsing it or asserting its truth.

saying ‘zomg! there were/are totes non-white Jewish people’

is meaningless when i never said anything to the contrary.

yeah. some fucking german d00d from the 1800s said Jewish people are caucasian/white.

and in one shitty thesis manages to erase the real differences in a huge, diverse group of people and flatten them and reduce them to some pretty disgusting stereotypes and misconceptions.

but. like.

u realize that this is also true of Black people, Yellow people, Red people, and Brown people?

how do u read a post like that

which is 100% about how race is a reductive mechanism

but ur only issue is how it applies to Jewish people?

not with how this same system arose out of a need to rationalise the enslavement/unhumanity of Black people?

not with how the system arose as a way to justify the ongoing Indigenous genocides in the americas?

but the real and only issue u appear to have is the way that this crusty german d00d erased some Jewish people while ensuring that others would be able to settle on stolen land and own Black people?

_that_ is your one and only problem u can think to mention about scientific racism???

