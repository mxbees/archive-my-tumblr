---
id: 100823690714
slug: look-any-credibility-you-may-have-had-flies
date: 2014-10-24 12:00:34 GMT
tags:
- discussing discourse
title: 
---
Look.&nbsp;

Any credibility you may have had flies out the window when you 1. start harassing someone to ‘prove’ your point and 2. when you encourage other people to harass the same person.&nbsp;

&nbsp;more proof that even a gentle call out only has the same result as a non-gentle one

