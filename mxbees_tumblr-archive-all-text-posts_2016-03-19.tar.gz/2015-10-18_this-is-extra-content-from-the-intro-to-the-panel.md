---
id: 131426572757
slug: this-is-extra-content-from-the-intro-to-the-panel
date: 2015-10-18 16:55:14 GMT
tags:
- discussing discourse
- op
title: 
---
(this is extra content from the intro to the panel i am preparing for)

All of this is also why I think the post-modernist push to call anything and everything a ‘text’ is a problem. It embeds this white supremacist worldview wherein texts and textual culture are the only proper objects of critical discourse. It elevates textual culture even higher than what it was before, which is sort of impressive too all things considered.

This recalls to me this presentation I saw from a white, cis gay man who was trying to get his body 'catalogued’ into a library collection because it he considers it a 'text’ and/or 'book’. It was such a strange and bizarre thing for me to hear because I spend so much time struggling against regular and systemic dehumanization that the idea of trying to reduce my body to something like a book isn’t at all appealing.

I know so many types of people who are actually _dying_ just to be seen as human, while this guy is seriously trying to reduce himself to an object.

Sure, when I heard him talk about it, it was all 'post-modern blah blah blah’ and I was just like: why are u so divorced from reality and actual human beings.

Bleh. White academics…

