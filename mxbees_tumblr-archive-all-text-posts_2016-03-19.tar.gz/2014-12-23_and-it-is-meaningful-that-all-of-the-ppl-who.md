---
id: 105955575484
slug: and-it-is-meaningful-that-all-of-the-ppl-who
date: 2014-12-23 11:45:43 GMT
tags: []
title: 
---
and it is meaningful that all of the ppl who noticed the

~brown woman getting beat up all the time trope~

are poc.

like… all the white ppl seem to have missed out on this majorly problematic part of the show

