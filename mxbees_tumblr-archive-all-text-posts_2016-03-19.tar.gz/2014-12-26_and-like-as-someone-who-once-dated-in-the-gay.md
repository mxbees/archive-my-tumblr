---
id: 106266123679
slug: and-like-as-someone-who-once-dated-in-the-gay
date: 2014-12-26 23:26:36 GMT
tags:
- teh gay community
title: 
---
and like… as someone who once dated in the gay world presenting as an asian guy?

u can fuck the hell off with ur compulsory femininity.

u don’t even _know_ what this means

to be compulsorily framed as feminine

in a context that fucking despises and hate femininity

