---
id: 102691961574
slug: tripleagender-b-binaohan-me-starting-to
date: 2014-11-15 14:30:36 GMT
tags:
- teh trans community
title: 
---
[tripleagender](http://tripleagender.tumblr.com/post/102689254370):

> [b-binaohan](http://xd.binaohan.org/post/102657008874/me-starting-to-get-really-fucking-annoyed-at-the):
> 
> > me: starting to get really fucking annoyed at the puberty blocker post going around…
> > 
> > why?
> > 
> > well….
> > 
> > the assumptions of the post
> > 
> > like. yes. obviously all trans ppl (young or old) should have easy and sufficient access to healthcare (trans related or not)
> > 
> > what irritates me is the…
> 
> that’s all very nice but not every post has to be about The Solution to Transness or is trying to be about that. Parents should know about puberty blockers being safe. I don’t know? there are prospective parents out there who are committed to raising children in a trans - inclusive way who didn’t know that puberty blockers are safe for kids. I didn’t know. I appreciated somebody telling me? like…that seems relevant.
> 
> i do dig your point tho especially western fixation on medical intervention but…yeah

well ACTUALLY

if ur trying to make a post that is about how to support trans kids

and all u do is talk about access to hormone blockers

u are pretty much failing to provide any meaningful level of support for trans kids

like how hard is it to frame a post that is providing information about how hormone blockers are safe by saying

“all trans ppl deserve access to health care. hormone blockers are safe for kids. destroy the pathologizing of transness. hormone blockers won’t make your kid a ~real~ boy or ~real~ girl, but they can help improve their quality of life”

look.

four fucking sentences. and, admittedly if we are doing an info post, the more militant ‘destroy’ can be removed.

> “all trans ppl deserve access to health care. hormone blockers are safe for kids. hormone blockers won’t make your kid a ~real~ boy or ~real~ girl, but they can help improve their quality of life.”

see?

not really all that difficult, is it?

my beef with the post is that it gave the appearance that getting kids access to hormone blockers will do the most for making them happy/healthy

when it only address one small part of the trans experience and our oppression

if ur not part of the solution, ur part of the problem

keep ur bullshit colonialist models of gender off my post

