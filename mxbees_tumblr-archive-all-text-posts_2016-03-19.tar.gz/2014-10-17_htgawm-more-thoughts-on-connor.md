---
id: 100243825724
slug: htgawm-more-thoughts-on-connor
date: 2014-10-17 15:23:48 GMT
tags:
- media musings
- htgawm
- race chasers
title: htgawm more thoughts on connor
---
so i’m only up to ep 3, where connor does his big outing of the Black bi guy.

which is shitty in its own respect and lots of ppl have been talking about this

but i’m also very interested to see

that of the two men he’s been sexually linked to on the show

both are men of color. One Asian and one Black.

Fascinating, isn’t it?

I hear that there is another moc in the ep4. which makes a pattern on his part.

so….

connor is a race chaser it seems.

this fetishization combined with his desire to use, abuse, and harm the moc that he gets involved with….

yeah.

i _know_ this white cis gay man.

i’ve dated him.

connor is just another shitty white man who loves to use his power over other people

