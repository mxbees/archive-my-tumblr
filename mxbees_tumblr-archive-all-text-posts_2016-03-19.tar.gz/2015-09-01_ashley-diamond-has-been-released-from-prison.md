---
id: 128117899367
slug: ashley-diamond-has-been-released-from-prison
date: 2015-09-01 16:55:11 GMT
tags:
- current events
- incarceration
- Black trans women
- Ashley Diamond
title: Ashley Diamond has been released from prison!
---
The Southern Poverty Law Centre is reporting that Ashley Diamond has been released from Augusta State Prison.

> She and SPLC attorney Chinyere Ezie said the lawsuit contending she was denied a safe environment and medically necessary gender dysphoria treatment will continue.
> 
> Ashley has endured more than three years of systematic abuse … Nor is her plight isolated. We will continue to advocate for an end to prison practices that unfairly punish and inflict pain on transgender inmates,” Ezie said.

This is amazing news.

( [Original Source. Trigger Warnings for incarceration, rape, abuse](https://archive.is/QmmrJ))

