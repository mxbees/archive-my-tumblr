---
id: 128347673137
slug: edin-cary-avendano-hernandez-will-not-be-deported
date: 2015-09-04 18:44:17 GMT
tags:
- current events
- ice
- refugees
title: Edin Cary Avendano-Hernandez will not be deported
---
Avendano-Hernandez has been granted asylum in the US and will not be deported back to Mexico, where she is at a high risk for violence.

( [Original Source. Trigger Warnings for rape, police violence,‘born as…’](http://web.archive.org/web/20150904101944/http://www.bbc.com/news/world-latin-america-34148003))

