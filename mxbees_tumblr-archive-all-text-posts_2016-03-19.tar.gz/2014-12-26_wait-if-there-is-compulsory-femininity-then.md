---
id: 106262327664
slug: wait-if-there-is-compulsory-femininity-then
date: 2014-12-26 22:36:25 GMT
tags:
- teh queer community
title: 
---
wait… if there is compulsory femininity

then this means that being butch is necessarily resistance to this

and then this means that butches are inherently more radical/revolutionary than femmes

gosh.

i swear…

this sounds EXACTLY LIKE the typical white discourse around gender and masculinity

(both queer and not-queer)

i mean…

obviously butches are more valuable bc of their revolutionary expression and resistance to compulsory femininity…

this means we ought to centre them in our discourse and spaces!

