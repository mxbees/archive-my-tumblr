---
id: 129225137438
slug: janice-tovars-killer-gets-off-with-probation
date: 2015-09-16 17:49:28 GMT
tags:
- current events
- janette tovar
- domestic violence
- tdor
title: Janice Tovar's killer gets off with probation
---
> A man responsible for the 2012 beating of a Dallas transgender woman who died from her injuries is set to receive probation and no jail sentence.
> 
> A spokesperson for the Dallas County District Attorney’s Office has confirmed to the Observer that Jonathan Stuart Kenney, 29, is expected to plead guilty Tuesday to first-degree felony aggravated assault. Under a plea bargain, Kenney will be sentenced to 10 years probation for the death of his then-partner, Janette Tovar.

It’s funny (in the way that it really isn’t) since I’ve been reading trans news… can you guess the race of this man?

I really am seeing a pattern here.

( [Original Source. Trigger Warnings for details of murder, domestic violence, intimate partner violence, transmisogyny](http://syx.pw/1LxJhZF))

