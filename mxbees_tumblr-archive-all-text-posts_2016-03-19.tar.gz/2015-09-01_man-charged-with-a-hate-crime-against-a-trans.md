---
id: 128127427954
slug: man-charged-with-a-hate-crime-against-a-trans
date: 2015-09-01 19:38:37 GMT
tags:
- current events
- hate crimes
- transmisogyny
- violence against women
title: Man charged with a hate crime against a trans woman
---
> Police say a man has been charged with committing a hate crime against a transgender woman at a Southern California Target store.
> 
> Glendale police said in a news release that 34-year-old Rodolfo Coria made derogatory comments toward the 45-year-old woman, then spat at her. A fight ensued that left the woman with a swollen thumb and leg abrasions.

( [Original Source. Trigger Warnings for transmisogyny, violence](https://web.archive.org/web/20150901130143/http://www.modbee.com/news/state/article33053121.html))

