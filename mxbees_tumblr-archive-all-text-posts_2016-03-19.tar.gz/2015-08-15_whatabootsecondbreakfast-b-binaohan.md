---
id: 126712606939
slug: whatabootsecondbreakfast-b-binaohan
date: 2015-08-15 01:51:45 GMT
tags:
- epilepsy warning
- i'm shedding a single tear of colour for you
title: 
---
[whatabootsecondbreakfast](http://whatabootsecondbreakfast.tumblr.com/post/126712480979):

> [b-binaohan](http://b-binaohan.tumblr.com/post/126712133459):
> 
> > [whatabootsecondbreakfast](http://whatabootsecondbreakfast.tumblr.com/post/126710585194):
> > 
> > > [hoodooqueer](http://hoodooqueer.tumblr.com/post/126710487604):
> > > 
> > > > [b-binaohan](http://b-binaohan.tumblr.com/post/126710400919):
> > > > 
> > > > > did i come home from getting tattooed only to find out that most of my friends on here are secret toxic whites?
> > > > > 
> > > > > \>.\>
> > > > > 
> > > > > what.&nbsp;
> > > > > 
> > > > > and all this time i’ve been a poc trans woman twoc?&nbsp;
> > > > > 
> > > > > hanging around all these whites???
> > > > 
> > > > How do we know you’re not a white appropriating trans PoC experiences?
> > > > 
> > > > SO WHAT IS THE TRUTH?
> > > 
> > > I’M not white, unlike _some_ people..<figure class="tmblr-full" data-orig-height="240" data-orig-width="468"><img src="https://38.media.tumblr.com/8813b32560786c25b6a79fd468a50e41/tumblr_inline_nt3osy9usz1rdzs46_500.gif" data-orig-height="240" data-orig-width="468"></figure>
> 
> [#but i’ve seen the light](https://tumblr.com/tagged/but-i%27ve-seen-the-light) [#the bright light reflecting off ur pale white skin](https://tumblr.com/tagged/the-bright-light-reflecting-off-ur-pale-white-skin)
> 
> stop spreading these untruths to your followers
> 
> <figure class="tmblr-full" data-orig-height="300" data-orig-width="500"><img src="https://31.media.tumblr.com/4ee2a36cd869635e9b15f05212750cbb/tumblr_inline_nt3p2y68TJ1s0v35e_500.gif" data-orig-height="300" data-orig-width="500"></figure><figure class="tmblr-full" data-orig-height="281" data-orig-width="500"><img src="https://33.media.tumblr.com/77aa70336880103c52f86163685af8d3/tumblr_inline_nt3p5rRz691rdzs46_500.gif" data-orig-height="281" data-orig-width="500"></figure>