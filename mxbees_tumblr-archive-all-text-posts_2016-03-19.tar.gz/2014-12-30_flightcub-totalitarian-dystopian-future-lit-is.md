---
id: 106600397544
slug: flightcub-totalitarian-dystopian-future-lit-is
date: 2014-12-30 10:26:08 GMT
tags:
- discussing discourse
title: 
---
[flightcub](http://flightcub.tumblr.com/post/69295318569/totalitarian-dystopian-future-lit-is-like-what-if):

> totalitarian dystopian future lit is like “what if the government got so powerful that all the bad stuff that’s already happening ALSO HAPPENED TO WHITE PEOPLE?”

ah.   
  
but this is actually the argument most white-centric movements make in order to gain state privileges  
  
white suffragetes: Black men can vote and we can’t? Give us the vote!  
  
Gay Inc: Gay is the new Black!!!!  
  
and so it goes

