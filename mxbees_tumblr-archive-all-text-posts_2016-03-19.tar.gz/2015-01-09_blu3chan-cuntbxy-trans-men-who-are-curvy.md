---
id: 107586357664
slug: blu3chan-cuntbxy-trans-men-who-are-curvy
date: 2015-01-09 09:55:55 GMT
tags:
- teh trans community
title: 
---
[blu3chan](http://blu3chan.tumblr.com/post/102993764235/cuntbxy-trans-men-who-are-curvy-are-men):

> [cuntbxy](http://cuntbxy.tumblr.com/post/102943524839/trans-men-who-are-curvy-are-men-trans-men-who):
> 
> > Trans men who are curvy are men.&nbsp;
> > 
> > Trans men who are skinny are &nbsp;men.&nbsp;
> > 
> > Just because some trans men have hips doesn’t make them any less of a man.&nbsp;
> > 
> > Just because some trans men don’t have a lot of muscle doesn’t make them any less of man.&nbsp;
> > 
> > Trans men who transition are men.&nbsp;
> > 
> > Trans men who don’t transition are &nbsp;men.&nbsp;
> > 
> > If you identify as male,&nbsp;_you are male.&nbsp;_
> 
> I needed to see this.

sure. sure.  
  
all of this is true until it is time to talk about male privilege and the suddenly……

