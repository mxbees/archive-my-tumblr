---
id: 106599727724
slug: medicine-only-on-tumblr-will-i-see-people
date: 2014-12-30 10:09:45 GMT
tags:
- teh trans community
title: 
---
[medicine](http://medicine.tumblr.com/post/106591048224/only-on-tumblr-will-i-see-people-applaud-the-idf):

> only on tumblr will i see people applaud the IDF for going vegan

i just saw an article the other day about how the IDF will support/fund its trans members during transition so, i’m waiting for the trans americans trying to push for open trans military service to use this as a great example for how things could be….

