---
id: 113773418309
slug: b-binaohan-b-binaohan-i-posted-this-on
date: 2015-03-16 08:51:53 GMT
tags:
- race to the bottom
title: 
---
[b-binaohan](http://xd.binaohan.org/post/113773289004/b-binaohan-i-posted-this-on-facebook-the):

> [b-binaohan](http://xd.binaohan.org/post/113773079714/i-posted-this-on-facebook-the-easiest-way-to):
> 
> > (i posted this on facebook)
> > 
> > The easiest way to determine if a group of people was white in the early days of colonization is a simple checklist of the most important white privileges:
> > 
> > 1. Could they become citizens?
> > 2. Could they own enslaved Black people?
> > 3. Could they own property?
> > 4. Could they marry white people?
> > 
> > If the answer to all of these questions is ‘yes’, then the group was white. Irish people could do all of these things from the moment they arrived to settle in the americas.
> > 
> > I will say this as much as is needed…. (this was posted in a comment thread elsewhere).
> > 
> > Only white people are able to answer ‘yes’ to all of these questions, esp. during the early days of colonization in the Americas. These were literally, at the time, the biggest and most important white privileges.
> 
> the great thing about this four part test is that it shows just how stable the boundaries of whiteness have been   
>   
> and how no one really seems to talk about the actual edge cases in terms of whiteness (west asians and north africans)  
>   
> instead we are constantly hearing about the fucking irish or east europeans, who’ve always been white.

people seem to forget that whiteness esp in the early days of its invention  
  
wasn’t just a \_social\_ category  
  
but a legal and biological one.   
  
the only way to ‘become’ what was through selective breeding (eugenics) which is why anti-miscegenation laws were a thing and even then… you could rarely change your legal classification without some serious difficulty and effort

