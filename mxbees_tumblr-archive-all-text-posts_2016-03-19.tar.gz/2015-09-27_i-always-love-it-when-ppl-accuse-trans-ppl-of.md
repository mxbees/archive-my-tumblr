---
id: 129996371864
slug: i-always-love-it-when-ppl-accuse-trans-ppl-of
date: 2015-09-27 16:55:00 GMT
tags:
- transmisogyny is fun for the whole family
- op
title: 
---
i always love it when ppl accuse trans ppl of rubbing their faces in our gender.

bc the situation literally is always:

trans person: \*exists\*

them: STop ruBBINg faCE in UR GendER

