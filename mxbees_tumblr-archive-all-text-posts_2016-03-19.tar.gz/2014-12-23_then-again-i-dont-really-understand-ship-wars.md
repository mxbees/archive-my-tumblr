---
id: 105921224074
slug: then-again-i-dont-really-understand-ship-wars
date: 2014-12-23 02:06:16 GMT
tags: []
title: 
---
(then again… i don’t really understand ship wars. lol. i prefer to block and ignore all of the ppl who disagree with me :P)

