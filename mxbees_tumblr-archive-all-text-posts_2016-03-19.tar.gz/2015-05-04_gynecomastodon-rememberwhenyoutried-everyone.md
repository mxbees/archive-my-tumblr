---
id: 118109978469
slug: gynecomastodon-rememberwhenyoutried-everyone
date: 2015-05-04 12:26:49 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[gynecomastodon](http://gynecomastodon.tumblr.com/post/109562154749/rememberwhenyoutried-everyone-listens-to-trans):

> [rememberwhenyoutried](http://rememberwhenyoutried.tumblr.com/post/109559395318/everyone-listens-to-trans-women-and-no-one):
> 
> > “Everyone listens to trans women and no-one listens to trans men!”
> > 
> > <figure class=""><img src="https://38.media.tumblr.com/01b3ec37a5f5ff72dbc2a3d4790f4267/tumblr_inline_niz7opHCk41qau6cp.png" alt="image"></figure>
> 
> Trans men have literally complained about the bias toward trans women at events like the Philadelphia Trans Health Conference where a side-by-side comparison of the workshops offered showed 1/3 more programming for trans men. Like, they’ve _filed complaints_&nbsp;about it.

gee…  
  
its almost like trans men are men….   
  
reason 2182983029384 why group in men and women just bc we are ‘trans’ is shitty and transmisogynist

