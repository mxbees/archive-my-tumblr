---
id: 129869790151
slug: incarcerated-trans-women-wins-suit
date: 2015-09-25 21:28:03 GMT
tags:
- current events
- usa
- incarceration
- legal victories
title: Incarcerated trans women wins suit
---
> In a decision that led Maryland prisons to adopt new policies about transgender inmates, Administrative Law Judge Denise Shaffer ruled in favor of Sandy Brown’s claim that prison officials at Patuxent Institution in Jessup, Maryland, failed to comply with national standards for the protection of inmates from sexual abuse, according to court documents.
> 
> Brown was serving a five-year sentence for assault when in 2014 she said she was placed in solitary confinement 24 hours a day for 66 days at Patuxent after a routine mental health screening, according to court records.
> 
> Shaffer ruled the prison should establish new transgender inmate policies including for strip searches, housing, and guard interactions. Shaffer also ordered the prison to pay Brown $5,000 in restitution for denying her recreational activities.
> 
> Brown’s attorney, Rebecca Earlbeck, said the case was the first in the country in which a transgender person successfully won a legal battle against prison officials for Prison Rape Elimination Act violations.

( [Original Source. Trigger Warnings for incarceration, sexual abuse, suicide](http://web.archive.org/web/20150925101958/http://www.reuters.com/article/2015/09/25/us-usa-maryland-transgender-idUSKCN0RP01Y20150925))

