---
id: 113154411334
slug: onlylesbianthings-girlpda-blucantrellvevo
date: 2015-03-09 09:44:50 GMT
tags:
- epilepsy warning
title: 
---
[onlylesbianthings](http://onlylesbianthings.tumblr.com/post/113148492930/girlpda-blucantrellvevo-traumatized-by):

> [girlpda](http://girlpda.tumblr.com/post/113148266103/blucantrellvevo-traumatized-by-penis-im):
> 
> > [blucantrellvevo](http://blucantrellvevo.tumblr.com/post/113146790551):
> > 
> > > “traumatized by penis” i’m out&nbsp;
> > 
> > Um…. Like…. Why are you completely disregarding rape victims feelings and experiences…
> 
> Anyone of any sexuality can be traumatized by penis. Rape, sexual abuse and dysphoria are things that very much exist. Why are we defending lesbians here, in this instance? Because they’re the ones who get told to question why they don’t like dick. But nice to see you absolutely don’t give a fuck about rape/abuse/csa victims, and trans women who cannot have sex with a dmab person due to dysphoria!

![](http://i.imgur.com/Db0uKGy.png)

![](http://g.nmp.pw/index.php?album=FU&image=FU_GloryHitByTruck.gif)

