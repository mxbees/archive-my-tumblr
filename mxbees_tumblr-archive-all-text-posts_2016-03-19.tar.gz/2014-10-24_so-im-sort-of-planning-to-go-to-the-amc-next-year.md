---
id: 100849089949
slug: so-im-sort-of-planning-to-go-to-the-amc-next-year
date: 2014-10-24 19:39:39 GMT
tags:
- race to the bottom
- i have that light skin privilege
title: 
---
so i’m sort of planning to go to the amc next year again.

i like that it is pretty close to where i live and i can do the whole trip fairly cheaply, which is great bc a lot of ppl i like go to it.

i have decided, though, that next year i’m not going to any of the poc-only spaces…

in part bc of what happened last amc during the poc lunch caucus that i inadvertently ended up facilitating.

one of the people (a Black person) said that some of us in the room looked white to him. still not sure if he meant me (and he could have, given my history with conditionally coding as white)

but also seeing… how overall light skinned even the twoc network gathering was. i’m just not super comfortable with being in those kinds of spaces because i know it is possible that my being their makes it unsafe/uncomfortable for darker skinned poc.

i’m also coming from a realization that i’ve known a few white latin@s who just… are completely unaware of the fact that their being latin@ does not mean they count as poc. and so they go into poc spaces fully thinking they have every right to be there…. but, they don’t.

and they definitely push out actual poc by being in the space.

like, i remember getting this scholarship from a US org for ‘poc’ and when we all got together, i totally wasn’t the 'whitest’ person there (in this group and context, I didn’t pass at all) and i remember looking at the white latin@ and thinking “omg, what the fuck are they doing here?”. it was only years afterwards that i found out that they were in the US category of 'white hispanic’ and I was like… _oh_.<sup id="fnref:p100849089949-1"><a href="#fn:p100849089949-1" rel="footnote">1</a></sup>

but for me… even if i’m not necessarily coding as white in a situation (from most accounts, I mostly wasn’t being coded as white at the amc last year), i _still_ have light skin privilege.

the amc was really the first poc-only type spaces in an anti-oppressive type of context that i went to. so next year i’ll skip.

it might change depending on the type of space, like i’d probably do the qtpoc tumblr meetup (if there is one) again, bc I have the opportunity to introduce myself and ppl know me there.

one thing, for sure, that i’m _never_ doing again is being in charge or otherwise 'leading’ a poc type session/event. to the extent that i’m welcome in such spaces, i def. do not think that i should be 'leading’ anything.

* * *

1. 

I actually just assumed they were Indigenous in some way, since I do know Indigenous ppl who look very white.&nbsp;↩

