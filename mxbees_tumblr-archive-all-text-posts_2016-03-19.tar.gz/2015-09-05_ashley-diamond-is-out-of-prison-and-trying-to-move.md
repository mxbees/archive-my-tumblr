---
id: 128417521856
slug: ashley-diamond-is-out-of-prison-and-trying-to-move
date: 2015-09-05 17:49:31 GMT
tags:
- current events
- ashley diamond
- Black trans women
- incarcerated trans women
title: Ashley Diamond is out of prison and trying to move on
---
> A few minutes before nine o’clock on Monday morning, Ashley Diamond found herself in an unfamiliar place—outside the walls of the Augusta State Medical Prison. Without notice, much less an explanation, the 37-year-old black transgender woman, who was more than three years into her 11-year sentence for burglary and theft—and in the midst of a legal battle with the Georgia Department of Corrections over the denial of proper medical care and adequate protection from repeated sexual assaults—was granted early release from state custody.
> 
> Diamond is working on both her physical recovery from the lack of hormone treatment, and her emotional recovery from the assaults. But she also needs to find a job. For now, Diamond remains in Georgia, awaiting the outcome of her lawsuit. She eventually wants to leave the state behind for Montgomery, Alabama, or Los Angeles—where she could someday pursue dreams of being an entertainer.
> 
> “I represent the everyday transgender person,” Diamond said. “I want people to recognize that I’m human.”

( [Original Source. Trigger Warnings for rape, incarceration, medical abuse](http://web.archive.org/web/20150905102525/http://www.atlantamagazine.com/news-culture-articles/after-unexpected-parole-transgender-inmate-ashley-diamond-picks-up-the-pieces-of-her-life/))

