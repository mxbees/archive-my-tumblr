---
id: 131743831204
slug: anescapedfish
date: 2015-10-23 12:18:17 GMT
tags:
- reblog
- the life of an ordinary bakla
title: 
---
[anescapedfish](http://anescapedfish.tumblr.com/post/119815821745):

> [ispenttoolongthinkingofanewname](http://ispenttoolongthinkingofanewname.tumblr.com/post/119014259284):
> 
> > [animatedamerican](http://animatedamerican.tumblr.com/post/118308455697):
> > 
> > > [isolationiste](http://isolationiste.tumblr.com/post/117963643056):
> > > 
> > > > [sirdef](http://sirdef.tumblr.com/post/79869797460):
> > > > 
> > > > > [sirdef](http://sirdef.tumblr.com/post/79865026421):
> > > > > 
> > > > > > [sirdef](http://sirdef.tumblr.com/post/79864552217):
> > > > > > 
> > > > > > > i did that adult thing you can do where you buy an entire cake and just eat it
> > > > > > > 
> > > > > > > i am eating an entire cake
> > > > > > 
> > > > > > update: there is more cake than i imagined.&nbsp;
> > > > > 
> > > > > i see now why my parents didn’t let me do this
> > > > 
> > > > never do this again
> > > 
> > > The trick to buying an entire cake and eating it is you don’t eat it all at once.
> > > 
> > > But, and this is crucial,&nbsp;_not_ because someone else is controlling your portions. &nbsp;Because it’s _your cake_. &nbsp;Because you don’t have to worry that if you don’t finish it now, somebody will take the rest away. &nbsp;Because you can eat as much cake as you feel like eating&nbsp;_and then stop_, and the remaining cake will still be there when you want some more. &nbsp;Which may be in an hour or may be in a couple of days.
> > > 
> > > Own your cake. &nbsp;Cake responsibly.
> > 
> > How to cake
> 
> This is so real though. Like I think a lot of kids overeat junk food and dessert is because if they’ve learned that if they don’t EAT IT ALL RIGHT NOW it’ll be eaten by somebody else or thrown out.   
>   
> You never learn how to control yourself because other people are always doing it for you, until you have a negative cake experience like OP.

huh.

while not the same, this post is making me realize that the reason i probably binge on junk food today is bc my dad would never buy it and the only time we got it was at family events.

where, you know, i’d binge on junk food bc i didn’t know when the next i’d get it would be.

(this makes me extra annoyed that my cousins ended up bullying me over my eating habits)

