---
id: 103409910359
slug: the-whole-trap-thing-is-something-that-makes-me
date: 2014-11-23 23:11:43 GMT
tags:
- teh trans community
title: 
---
the whole trap thing is something that makes me want to destroy everything.

like.

gtfo

whatever my personal feelings about the whole ‘deep stealth’ thing

trans women’s safety comes first.

