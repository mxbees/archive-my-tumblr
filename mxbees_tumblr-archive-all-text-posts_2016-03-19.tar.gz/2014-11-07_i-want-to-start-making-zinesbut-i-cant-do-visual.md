---
id: 102022547164
slug: i-want-to-start-making-zinesbut-i-cant-do-visual
date: 2014-11-07 18:22:36 GMT
tags:
- the life of an ordinary bakla
title: 
---
i want to start making zines…but i can’t do visual graphics

le sigh

