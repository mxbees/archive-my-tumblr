---
id: 102912193634
slug: the-really-really-irritating-thing-about
date: 2014-11-17 23:50:26 GMT
tags:
- media musings
title: 
---
the really REALLY irritating thing about farscape

is that although chrichton is super duper white d00d guy

and that it was a funny and amusing thing in the first season that

everyone on moya made fun of him for his ignorance and flailing about

in the 2nd season he has somehow become this alpha male whatever

wiat..

i just got distracted.

THE IRRITATING thing is, is that all of his irritating alpha male behavoiur is constantly rewarded by the writers

he yells a lot and is completely human centric

but ends up being right a lot of the time.

and so is justified in continuing to behave like this.

