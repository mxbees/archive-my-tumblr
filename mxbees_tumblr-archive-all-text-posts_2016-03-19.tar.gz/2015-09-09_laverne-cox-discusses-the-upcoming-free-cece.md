---
id: 128720990668
slug: laverne-cox-discusses-the-upcoming-free-cece
date: 2015-09-09 18:44:04 GMT
tags:
- current events
- laverne cox
- cece mcdonald
- black trans women thriving
title: Laverne Cox discusses the upcoming "Free CeCe" Documentary
---
> Every day when TV actress Laverne Cox goes to work on Orange is the New Black, she thinks of CeCe McDonald, a trans woman who was imprisoned in a men’s jail in 2012, despite her gender identity. Her harrowing story is detailed in the Cox-produced documentary Free CeCe, which premieres in early 2016. During her TimesTalks interview with New York Times’ senior culture editor Erik Piepenburg on Aug. 25, Cox spoke about Free CeCe and how important it was for her to tell this story.
> 
> The Free CeCe film tells this all-too-common story of abuse, harassment, and unfair treatment and includes Cox’s interview with McDonald while she was still incarcerated. When the trailer was played at the TimesTalks event, Cox grew misty-eyed thinking about McDonald and her struggles in jail, and in every day life as a transgender woman. “Why do I get to be the one living my dreams when so many of my sisters don’t?” she said tearfully in the movie.

( [Original Source. Trigger Warnings for t-slur, racialized transmisogynist violence, incarceration](https://archive.is/p54gq))

