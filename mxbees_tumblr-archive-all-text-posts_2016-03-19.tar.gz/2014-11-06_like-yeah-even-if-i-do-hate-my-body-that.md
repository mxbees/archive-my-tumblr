---
id: 101947915769
slug: like-yeah-even-if-i-do-hate-my-body-that
date: 2014-11-06 20:23:35 GMT
tags:
- the life of an ordinary bakla
title: 
---
like yeah,

even if i do hate my body

that doesn’t mean anyone else is okay to hate it too

or to shame me for having it.

