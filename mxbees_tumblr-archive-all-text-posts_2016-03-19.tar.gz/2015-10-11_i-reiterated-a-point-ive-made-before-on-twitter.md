---
id: 130916424509
slug: i-reiterated-a-point-ive-made-before-on-twitter
date: 2015-10-11 01:33:06 GMT
tags:
- ye olde abuse culture
- discussing discourse
- op
title: 
---
i reiterated a point i’ve made before on twitter yesterday…

what do ppl actually think happend to childhood bullies?

grow a heart of gold after some teachable moment? disappear in a cloud of fairy dust? ascend to a plane of higher existence? what?

its just like the post about how white millenials are just as racist as their parents and grandparents.

like. racism isn’t some innate behaviour. its learned.

just like bullies learn that their abusive behaviours will rarely result in any kind of consequence. so they grow up to be the sorts of adults that yell at cashiers. who play petty bullshit politics at work. grow up to be parents that abuse their children.

u don’t just ‘grow’ out of being a bully. not when abuse culture ensures that this behaviour is both normalized and rewarded.

