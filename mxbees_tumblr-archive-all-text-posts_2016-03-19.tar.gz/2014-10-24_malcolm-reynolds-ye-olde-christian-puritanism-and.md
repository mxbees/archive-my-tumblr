---
id: 100823700284
slug: malcolm-reynolds-ye-olde-christian-puritanism-and
date: 2014-10-24 12:00:46 GMT
tags:
- media musings
title: malcolm reynolds, ye olde christian puritanism, and firefly
---
I just finished re-watching the firefly series and this’ll be the last time I do so. I had a certain amount of nostalgia for the show ‘cause I watched 4/5 years ago. Long before I really started being critical of media and seeing the ways that it perpetuates and contributes to oppression.

Lots of people have talked about how ridiculous it is to have some notion that Mandarin is as common a language as english, but not actually have any Asians in the show with lines (excepting a sex worker in the massively whore-phobic 1x12). With 漢字 written backwards, poor pronunciation, and even worse intonation/rhythm of speech, it was sloppily handled and, frankly, racist and exploitative use of Chinese culture.

Lots of other people, I’m sure, have also talked about the ridiculous amounts of whore-phobia in the show. Companions are supposed to be a treasured and revered position/role in society, and they are in the eyes of everyone \*not\* malcolm reynolds, who makes his contempt for sex work very clear the \*entire\* series.

To a certain extent, this post is about that. It is also about the interesting insertion of christianity in the series of a time far into the future when we are supposed to understand that even white people speak some variety of Chinglish, but somehow only christianity, from all appearances, has somehow managed to last. [Only 4% of China](http://en.wikipedia.org/wiki/Religion_in_China), at the moment ID as christian, with the majority being atheist/agnostic, next with Daoism/Folk religion, etc. etc. Maybe these religions disappeared along with the actual Chinese people.

But this post is really about whedon’s apparent nostalgia for ye olde wild west and the ways that this christian informed puritanical mindset it embodied in malcolm reynolds.

(now, we all know that the white hetero cis man’s nostalgia for ye olde times is inherently racist and sexist and queerphobic and transphobic and ableist and etc. this is no different, but I guess I mostly want to think about the contours and shape of how it manifests in firefly)

captain reynolds is supposed to be the hero of the story. And he is. He swaggers his way through the show and we are supposed to buy into his particular morality and cheer him on as he defies the alliance. We are supposed to understand him as \*good\* even if in a slightly anti-hero sort of way. But, never mind, he is a \*real\* man. Firm in his convictions and, ultimately, vindicated by everything that happens in the series (via the love he somehow wins from Inara despite his constant slut shaming and degrading of her person, as well as the deep \*gratitude\* of simon and river).

But. With all this nostalgia chocking the air and the pervasive sense of heroism, you almost miss the ways (best evidenced by his whore-phobia) that he really just embodies a lot contemporary ideals of masculinity in the forms of an oppressive axis of racist, sexist, bullshit that white men love so dearly.

Given the premise of this 'verse. It is possible that malcolm has a Chinese counterpart. Or maybe this character could have been played by a Chinese man. Except… this seems almost unimaginable for all the ways that Chinese men are \*never\* allowed to occupy this same place of oppressive masculinity in media. And this is exactly how we know that the captain isn’t supposed to represent anything progressive, but rather supposed to glorify the ideals of a golden age where men like him were at the top of the world.

(It also makes you speculate. Because maybe the reason why the Chinese were largely invisible was because they mostly occupy the central planets, where there is – from what we are told – a repressive society that discourages individuality and is cold and machine like in its need for order and peace. And with all the white people on the 'border’ planets reprising their roles as settlers/pioneers, it really gives you pause. Because maybe the threat that malcolm’s throwback morality is supposed to combat is the 'homogenizing’ force of the borg-like Chinese. because firefly, at its basis, is a celebration of white, western individualism and christian morality. who cares if he is oppressive, 'cause he is \*righteous\*!)

Er… and that parenthetical statement totally made me loose track of what else I might have been trying to say. And I don’t quite care enough to try and figure it out.

