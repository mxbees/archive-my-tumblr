---
id: 110245278234
slug: ugh-what-should-i-get-for-my-first-gameboy-game
date: 2015-02-06 12:26:14 GMT
tags:
- the life of an ordinary bakla
title: 
---
ugh. what should i get for my first gameboy game? i’m thinking legend of zelda, link between worlds

