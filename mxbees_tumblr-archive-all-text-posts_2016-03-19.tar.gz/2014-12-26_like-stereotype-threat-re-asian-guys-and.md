---
id: 106266429174
slug: like-stereotype-threat-re-asian-guys-and
date: 2014-12-26 23:30:32 GMT
tags:
- the life of an ordinary bakla
title: 
---
like. stereotype threat re: asian guys and femninity

is part of what prevented me from embracing my femme self

for so long

so. yeah. gtfo.

