---
id: 128275874083
slug: adult-trans-woman-can-get-surgery-and-is-competent
date: 2015-09-03 18:44:05 GMT
tags:
- current events
- this is good news
- im happy
title: Adult trans woman can get surgery and is competent after all
---
> A Bucks County judge dismissed an emergency injunction Wednesday, allowing a 48-year-old transgender woman to move forward with plans to have gender-reassignment surgery.
> 
> In court, Judge Theodore Fritsch said there wasn’t evidence to show that Kitzler was in any way not competent or unable to make the decision for herself.

This is such a relief.

( [Original Source. Trigger Warnings for transmisogyny, child abuse, paternalism](http://www.theintell.com/news/local/judge-transgender-woman-can-get-gender-reassignment-surgery-opposed-by/article_5de6c6fe-51c2-11e5-aeb4-f7a7bfbd2328.html))

