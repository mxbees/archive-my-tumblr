---
id: 101711101589
slug: wow-this-episode-of-farscape-is-totally
date: 2014-11-03 23:35:02 GMT
tags:
- media musings
title: 
---
wow.

this episode of farscape is totally antiBlack

the villains in a village of Polynesian looking ppl just happen to be the only Black ppl in the village?

really?

