---
id: 131498082949
slug: not-being-able-to-replies-to-replies-has-changed
date: 2015-10-19 17:21:41 GMT
tags:
- the life of an ordinary bakla
title: 
---
not being able to replies to replies has changed how i use tumblr a great deal.

i definitely feel like its harder to actually have conversations with people.

but.

in case ppl don’t know: i’m not using xkit and replying to replies is more trouble than i’m willing to put into it bc i hate using the tumblr UI for posting.

i’m not ignoring uuuuu.

