---
id: 106852037704
slug: i-see-my-leelah-post-is-bringing-me-lots-of
date: 2015-01-02 01:14:50 GMT
tags:
- the life of an ordinary bakla
title: 
---
i see my leelah post is bringing me lots of followers….

u should be warned that i don’t normally bother with following normative grammar

i also don’t tend to sanitize my writing as much as i did for that post.

if u want to see where most of my long posts are, u can go to my [main blog](http://b.binaohan.org)

i also write books… more info can be found in [decolonizing trans/gender 101](http://biyuti.com/decol101)

