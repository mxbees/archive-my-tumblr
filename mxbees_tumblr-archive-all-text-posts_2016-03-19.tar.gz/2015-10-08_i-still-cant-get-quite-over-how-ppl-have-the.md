---
id: 130716940624
slug: i-still-cant-get-quite-over-how-ppl-have-the
date: 2015-10-08 00:42:02 GMT
tags:
- discussing discourse
- op
title: 
---
i still can’t get quite over how ppl have the strangest ideas about socialization.

bc that whole ‘if ppl thought u were a man, then u were socialized as one’ is the frequent counter-argumentt to what i say (or what others say)

like. this is what feminists say all the time about trans women. we don’t know what its like to be raised as a girl bc everyone mistakenly thought we were boys…

of course, the one thing these feminists haven’t been able answer for decades is why, exactly, they think their experiences:

1. ought to be universal
2. or actually are universal
3. are the gold standard by which everyone else’s womanhood is measured

bc. ppl do get that trans women aren’t the first group of women to challenge mainstream feminism’s sincere belief that it has a monopoly on womahood.

poor women have been saying for decades “ur not universal”

women of colour have been saying for centures “ur not fucking universal”

disabled women saying saying saying “but really. ur not universal”

fat women saying “i’m really not joking. ur not universal”

sex workers saying “ur not still not unversal”

on and on it goes and ppl _still_ insist that there is a universal, shared experience of womanhood.

and everyone treats _me_ like i’m the fucking irrational one.

