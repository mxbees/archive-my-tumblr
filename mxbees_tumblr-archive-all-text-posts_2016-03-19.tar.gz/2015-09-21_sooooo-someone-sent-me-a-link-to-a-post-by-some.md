---
id: 129601647864
slug: sooooo-someone-sent-me-a-link-to-a-post-by-some
date: 2015-09-21 23:48:20 GMT
tags:
- discussing discourse
- i rebuke thee feminism
- op
title: 
---
sooooo. someone sent me a link to a post by some radfems talking about how pointing out that they are radfems (on their posts) is somehow… pushing for ideological purity? acting like ur part of a cult? lol.

the title of this post is ‘to the 'op is a terf’ brigade’ and then it goes into talking about how tell ppl who they can or cannot reblog from is ideological purity and cult stuff. like, the radfem who agrees with her actually cites some source about cults and purity.

i could deconstruct the specific post bc it is actually a really great example of what i’m going to discuss in this post.

its funny too bc i just learned a term that partially describes the kind of rhetoric that radfems frequently use: dog whistle.

this is basically a thing where what is said is intended to have one meaning for a general audience, and a coded meaning for a small, targetted group.

in the context i’m talking about, what this really means about radfems and their brand of feminism is that much of what they say sounds entirely reasonable to most of the people who hear it. however, for the 'dogs’ (ie trans women) we actually hear what they are _really_ saying.

so when one writes something like this:

> Calm the fuck down and stop micro managing women’s speech and who they are reblog from.

your average person is going to hear this and nod and think it sounds entirely reasonable. i mean. free speech, amirite? not targetting women, amirite?

but then the very next sentence:

> ou are making a tense, uncomfortable and misogynist environment for female bloggers…

ah. now we get to the heart of it. in every other instance in this particular post, the OP uses 'women’ to denote the class of ppl she wishes to talk about. until this very last occurrence, when we see 'female’ instead. what we are meant to take away from this is that

woman = female

which, you know, is something radfems love to assert.

but the rest of the post sounds just as reasonable as the first cited one. i mean, the post, as a whole, actually invokes an idea that i’ve been critiqueing myself (the idea of how ideological purity is enforced in certain kinds of toxic communities). i literally do not disagree at all with the overall message OP is trying to communicate.

HOWEVER

i hear the dog whistle. i look back over the rest of the post and realize that this woman is telling people that warning others about a dangerous group of people with a proven history of harming and targetting trans women is cultish behaviour, all while making sure that we understand that trans women aren’t actual women (and thus, we don’t deserve the same considerations she is advocating for in the post and we don’t deserve protection from coded hateful speech of the sort that radfems fucking specialize in).

you know why radfem posts often get tagged with 'op is a terf’?

bc those of us who hear the dog whistle generally think that other people might like to know and learn how to hear it.

radfem posts are fucking _dangerous_ because they so often sound entirely reasonable and totally relatable… until you realize that whatever it is that they are saying doesn’t include trans women and a whole bunch other women.

radfems are dangerous bc ppl who might otherwise think they are our allies will often give them a greater platform than the conservatives or MRAs who say the _same thing_ that they do.

radfems are dangerous bc they have totally perfected dog whistle rhetoric and _so many people_ get fooled by it.

