---
id: 127785480654
slug: copperkeep-hoodoodyke-copperkeep
date: 2015-08-28 12:48:29 GMT
tags:
- epilepsy warning
title: 
---
[copperkeep](http://copperkeep.tumblr.com/post/127784869034):

> [hoodoodyke](http://hoodoodyke.tumblr.com/post/127784763214):
> 
> > [copperkeep](http://copperkeep.tumblr.com/post/127784614899):
> > 
> > > [hoodoodyke](http://hoodoodyke.tumblr.com/post/127783574764):
> > > 
> > > > [b-binaohan](http://b-binaohan.tumblr.com/post/127780268254):
> > > > 
> > > > > ur fav is problematic: me. in 2012 i said that i didn’t like icing on cinnamon rolls. (i still don’t) ( [link to tweet](http://twitter.com/b_binaohan/status/637208240816812032))
> > > > 
> > > > I…. I thought I knew you.
> > > 
> > > i will literally never get over this how could you
> > > 
> > > your blog is a bed of lies
> > 
> > <figure class="tmblr-full" data-orig-height="576" data-orig-width="453"><img src="https://40.media.tumblr.com/627973e7e1e1342942871131edc3bb60/tumblr_inline_ntslfoyGkR1qfzb2v_540.jpg" data-orig-height="576" data-orig-width="453"></figure>
> > 
> > I never thought the day would come
> 
> stale cinnamon roll too good for iced cinnamon rolls
> 
> (sound like elitism to me, hm? mhm mhm)<figure class="tmblr-full" data-orig-height="360" data-orig-width="480"><img src="https://33.media.tumblr.com/675f355eb882ffbf4fd5ab59f84214ce/tumblr_inline_ntsm8lPBz31rdzs46_500.gif" data-orig-height="360" data-orig-width="480"></figure>