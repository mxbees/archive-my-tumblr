---
id: 103329187189
slug: i-see-how-this-is-ppl-tagging-me-into-posts
date: 2014-11-23 01:47:30 GMT
tags:
- the life of an ordinary bakla
- a spoon is born
title: 
---
i see how this is…

ppl tagging me into posts when i’m too drowsy/sleepy from anxiety meds to

properly participate.

just want and see what happens when i get up tomorrow.

i’ll show u

@a-spoon-is-born

you’ll see…

