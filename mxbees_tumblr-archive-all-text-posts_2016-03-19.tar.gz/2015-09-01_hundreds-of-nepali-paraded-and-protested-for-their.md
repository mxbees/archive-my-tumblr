---
id: 128131037388
slug: hundreds-of-nepali-paraded-and-protested-for-their
date: 2015-09-01 20:33:15 GMT
tags:
- current events
- nepal
- trans rights
title: Hundreds of Nepali paraded and protested for their rights in Kathmandu
---
> Hundreds turned up for the colourful rally - dancing in the streets.
> 
> They are demanding same-sex marriage be guaranteed in the new constitution, gay couples’ rights to adopt, buy joint property or inherit from one another.
> 
> Nepal recognised a third gender as early as in 2007 when the Supreme Court ordered the government to scrap all laws that discriminated on the basis of sexual orientation or gender identity.
> 
> This year, it issued passports with “other” as the choice for those who do not wish to be identified as male or female.
> 
> But representatives of the LGBT [lesbians, gays, bisexuals and transgender] community say they have difficulty obtaining these passports.

( [Original Source](https://archive.is/QlFl1))

