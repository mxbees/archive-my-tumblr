---
id: 129863176695
slug: mural-honouring-trans-women-of-colour-vandalized
date: 2015-09-25 19:38:46 GMT
tags:
- current events
- canada
- transmisogyny
title: Mural honouring Trans Women of Colour Vandalized
---
> Ottawa Police have launched an investigation, after a Centretown mural honouring trans women of colour was vandalized on Wednesday night.
> 
> Sometime overnight the mural was doused with white paint and messages reading “All lives matter” and “You have been warned.”

( [Original Source. Trigger Warnings for transmisogyny](http://web.archive.org/web/20150925100613/http://www.cfra.com/news/2015/09/24/police-investigate-vandalized-mural-honouring-transgender-women-of-colour))

