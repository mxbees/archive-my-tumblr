---
id: 128070776934
slug: add-trans-to-that-previous-statement-a-focus
date: 2015-09-01 01:04:53 GMT
tags:
- teh trans community
title: 
---
add ‘trans’ to that previous statement: a focus on trans women, is not the erasure of men still true.

