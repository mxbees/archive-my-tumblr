---
id: 131119247559
slug: so-i-took-a-look-at-the-huge-queue-of-news-i
date: 2015-10-13 23:31:30 GMT
tags:
- b is for binary
- teh trans community
- op
title: 
---
so i took a look at the huge queue of news i haven’t been reading and read a few things (didn’t have the energy to write summaries, though, sorry.)

and… of course i see an article by a enby of colour – also dmab – who is talking about how the recent trans visibility isn’t helping enbies like them (or perhaps me, idk).

bc apparently only cis-blending, thin, conventionally attractive, binary people are getting attention or whatever. and that this media visibility isn’t helping ppl like them.

whats fascinating is that i figured out the writer just by the first sentence. and it is, unsurprisingly, a person whose been called out for anti-Blackness before and… still really hasn’t done a single thing to address this.

now. the article makes an explicit reference to Laverne Cox’s times cover where it said we were experiencing a transgender tipping point or whatever.

i can only surmise from this that they are including Ms. Cox in this pronouncement that trans visibility isn’t really helping ‘visibly gender non-conforming’ people like themselves.

its an interesting sleight of hand that depends on anti-Blackness bc Ms. Cox has said on _several_ occasions that she is regularly clocked as being trans. while, sure, she might have a 'binary’ gender presentation, this doesn’t, in fact, mean that she is suddenly not a 'visibly gender non-conforming’ trans person.

anyway. this is a good example of why i don’t talk to a lot of enbies. even ones of colour. bc… this? is still bullshit.

