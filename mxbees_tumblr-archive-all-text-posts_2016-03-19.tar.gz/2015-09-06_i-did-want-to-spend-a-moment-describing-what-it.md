---
id: 128490175095
slug: i-did-want-to-spend-a-moment-describing-what-it
date: 2015-09-06 16:55:17 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
i did want to spend a moment describing what it was like being ace before asexuality was the robust identity it is today.

- at least 2/3 of my sexual partners were people i had no desire to have sex with, but did anyway for a variety of reasons.
- i felt pressured or coerced into having sex not only by specific partners but bc of the general expectation that asian femmes should always be sexually available to white men
- i spent years wondering if there was something wrong with myself physically or mentally bc i didn’t desire sex
- i occassionally joked about being asexual but it never occurred to me that it was a real option
- for other reasons as well, it never occurred to me that i was allowed to say ‘no’ to sex. or to only have it when i actually wanted to.
- to this day i can’t actually coherently understand which of my experiences were unenthusiastic consent and which ones were assault.
- i still can’t quite separate out physical intimacy with sex itself. i can almost… but not quite.
- i hurt myself a lot.

all of this to say… i actually do understand ace issues. i’ve struggled with them for years. i still don’t ID as asexual and i never will. just as much as i know that the ace community, as a whole, doesn’t have room for me (whereas the aces of colour i’ve met and know? generally awesome).

