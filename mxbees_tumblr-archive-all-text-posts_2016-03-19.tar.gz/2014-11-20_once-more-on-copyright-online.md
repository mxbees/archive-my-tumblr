---
id: 103115324024
slug: once-more-on-copyright-online
date: 2014-11-20 11:28:23 GMT
tags:
- tech support
- discussing discourse
- antiblackness is real
title: once more on copyright online
---
[aminaabramovic](http://aminaabramovic.tumblr.com/post/102899314272/i-literally-just-saw-a-post-by-a-writer-on-here):

> i literally just saw a post by a writer on here who saw their work be lifted by someone on the huffington post like word for word….this shit is no joke if you’re a writer/artist get a statcounter on your blog also timestamp the fuck out of your work and get a CC on that shit and get paid for your work

i know nica already put an apology related to this…

but i remember when i first saw this and i’m like…

this is inaccurate information (on top of the [victim blaming aspects](http://yungmeduseld.tumblr.com/post/102902739109/aminaabramovic-i-literally-just-saw-a-post-by-a))

i see this a lot on tumblr…

Creative Commons licensing is NOT the solution to plagiarism

it is actually a more permissive thing to do to your work than retaining full copyrights.

i’ve said this in the past but…

_everything_ you publish (and yes, this includes posts on tumblr or even tweets) automatically has a copyright. services like tumblr and twitter both say that you retain your copyright when posting on their services <sup id="fnref:p103115324024-1"><a href="#fn:p103115324024-1" rel="footnote">1</a></sup>.

creative commons (CC) licensing is intended to actually be _less_ restrictive than copyright. which means that if you are concerned with plagiarism, do _not_ put a CC license on your work<sup id="fnref:p103115324024-2"><a href="#fn:p103115324024-2" rel="footnote">2</a></sup>.

but. of course this doesn’t work. since i’ve seen people have their all rights reserved copyrighted material stolen.

moreover, in the US, if you want to _enforce_ your copyright, you actually need to register your copyright. this costs $35. and websites (like ur tumblr blog) have to be re-registered every 3-4 months because of how often the content changes. this means at least $100/year to have an enforceable copyright.

but then if someone violates your copyright by stealing your entire post and putting it on the huffpo, then you have to try sending a letter to the editor. if that doesn’t work, maybe if you have thousands of dollars you can sue.

as with many things, these laws literally do not exist to substantively benefit marginalized people. we do not have equal protection under the law. this is why it is absurd to think that if you take x, y, and z measures your content will be safe from exploitation. esp. (as is the case with many Black thinkers) who you are actually designates you as a target for exploitation.

* * *

1. 

while also giving them a license to host/transform your creative work as necessary for the functioning of their businesses. not all social media sites are have this kind of licensing, so yes, read the terms of service&nbsp;↩

2. 

also, even if you put a CC license on your work, you retain your copyright. AND you can revoke the license at ANY TIME (but anyone who used it under the previous license is grandfathered)&nbsp;↩

