---
id: 104434334924
slug: ive-been-wallowing-in-my-depression-all-day-and
date: 2014-12-05 21:26:10 GMT
tags: []
title: 
---
i’ve been wallowing in my depression all day

and i’ve post like two things

about police violence against Black ppl

and some white person comes into my askbox to talk about (i’m guessing non-Black) Indigenous ppl?

yeah. i’m a settler.

yeah. in canada esp. police/state violence against Indigenous ppl is a very real thing

and, what, exactly does me reblogging stuff about _Black_ ppl’s experience of police/state violence

erases the experiences of Indigenous ppl of the same?

