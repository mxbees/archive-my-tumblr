---
id: 100710301974
slug: while-i-dont-think-seasonal-allergies
date: 2014-10-23 00:56:12 GMT
tags:
- able ableism
title: 
---
while i don’t think seasonal allergies = oppression per se

it is possible to have them so bad they can be disabling.

i know ‘cause this is me.

(before i started on pretty expensive shots)

either allergies so bad i actually can’t function

or

so much anti-histamines that i overdose (not joking: i’ve done this before just to get through work)

and my best solutions costs 200+/year.

on top of still having to take antihistamines everyday

