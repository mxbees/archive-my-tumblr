---
id: 102492664379
slug: next-famous-dystopian-ya-novel-a-hellish
date: 2014-11-13 01:30:39 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
next famous dystopian YA novel:

a hellish landscape and society where any woman could possibly

\*gasp\*

have a penis

