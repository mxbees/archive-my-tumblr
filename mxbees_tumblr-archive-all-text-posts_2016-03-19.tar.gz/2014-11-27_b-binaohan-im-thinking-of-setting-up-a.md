---
id: 103725222934
slug: b-binaohan-im-thinking-of-setting-up-a
date: 2014-11-27 15:21:44 GMT
tags:
- antiblackness is real
- i'm not black
- transcribe ferguson
title: 
---
[b-binaohan](http://xd.binaohan.org/post/103724466159/im-thinking-of-setting-up-a-distinct-tumblr-for):

> i’m thinking of setting up a distinct tumblr for transcribing image-text-posts related to ferguson and stuff. like. i usually delete all non-original posts at the end of every month and i kind of think it is important to keep this stuff up. also. other people would be able to contribute too…
> 
> y/n?

okay. i’m doing the thing  
  
follow this tumblr if you need/require/want/etc transcriptions from images that contain text and are related to ferguson.   
  
 [http://transcribe-ferguson.tumblr.com/](http://transcribe-ferguson.tumblr.com/)  
  
people are welcome to contribute. this idea was sort of born from a desire to support Black people with labour.  
  
note: rules for an image to be put on the blog is that it actually has to be something written by a Black person. yes. this means that you have a to put a little effort to verify the source.   
  
this is about amplifying Black voices on a Black tragedy.   
  
no images will of Black people who’ve been harmed by violence will be posted without a cut and trigger warning.  
  
you also will not see Darren Wilson’s face anywhere on this blog.   
  
appropriate trigger warnings will be applied where necessary (ie, “police violence”, “graphic descriptions”, and whatever else people suggest).  
  
my hope is to make the content accessible and as safe as possible for Black people (given the topic).   
  
i’m going to leave submissions open so people can put in links or images they’d like transcribed.

