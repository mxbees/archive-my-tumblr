---
id: 101429447704
slug: and-like-how-many-people-including-me-have
date: 2014-10-31 17:16:00 GMT
tags:
- race to the bottom
- epilepsy warning
- gif warning
- gifset
- mayo is as mayo does
title: 
---
and like how many people (including me)

have said:

if ur white, you need to mark ur race

???

white ppl, i don’t give a fuck what ur aesthetics are

one matters of race, u do as ur told

![](http://g.nmp.pw/albums/glare/react_EPicCateSideEYE.gif)

