---
id: 130143142981
slug: marla-krolikowski-is-dead-at-62
date: 2015-09-29 17:49:38 GMT
tags:
- current events
- usa
- tdir
title: Marla Krolikowski is dead at 62
---
> Marla Krolikowski, who was fired from her job as a teacher at a Roman Catholic high school in Queens for insubordination after acknowledging in 2011 that she was transgender, died on Sept. 20 in Oceanside, N.Y. She was 62.

( [Original Source. Trigger Warnings for transmisogyny, employment discrimination](https://archive.is/ACVkm))

