---
id: 128930278279
slug: nova-bradford-is-suing-a-hospital-for-denying-her
date: 2015-09-12 17:49:42 GMT
tags:
- current events
- medical discrimination
- usa
title: Nova Bradford is suing a hospital for denying her medical care
---
> A Minnesota woman said she was refused service by a hospital all because she is transgender.
> 
> Now, 21-year-old Nova Bradford is suing Fairview Health Services and the University of Minnesota Medical Center.
> 
> Bradford said she needed help with a chemical dependency problem, but said she was denied admission to the “Lodging Plus” substance abuse treatment program because she’s transgender.

( [Original Source. Trigger Warnings for medical discrimination, transmisogyny, cissexism](https://web.archive.org/web/20150912131914/http://kstp.com/article/stories/s3904355.shtml))

