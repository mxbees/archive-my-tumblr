---
id: 128860203297
slug: new-brunswick-health-minister-meets-with-trans
date: 2015-09-11 18:44:07 GMT
tags:
- current events
- canada
- healthcare
title: New Brunswick health minister meets with Trans activists
---
> Members of the New Brunswick Transgender Health Network met with the province’s health minister on the issue of covering the cost of gender reassignment surgery for the first time Thursday.
> 
> New Brunswick is the only province in Canada that does not pay for gender reassignment surgery.
> 
> Members of the New Brunswick Transgender Health Network say Health Minister Victor Boudreau did not guarantee that would change. Instead, they say they got a commitment that the issue is being taken seriously.

( [Original Source. Trigger Warnings for health discrimination](https://web.archive.org/web/20150911115421/http://atlantic.ctvnews.ca/n-b-health-minister-meets-with-transgender-health-network-for-the-first-time-1.2557251))

