---
id: 130209023717
slug: ashley-diamond-speaks-with-the-advocate-about-her
date: 2015-09-30 16:55:09 GMT
tags:
- current events
- usa
- incarceration
- Black trans women
- transmisogynoir
title: Ashley Diamond speaks with the Advocate about her experiences
---
> Just two weeks after she was released from Augusta State Medical Prison in Georgia, Ashley Diamond finally heard some good news from a federal judge. She would be allowed to pursue her legal claim that the Department of Corrections in Georgia unlawfully discriminated against her because she is a transgender woman, not only denying her medically necessary transition-related care but allegedly failing to protect her from repeated rapes and assaults while she spent three years incarcerated with men.
> 
> “It was torture. I might be free now, but I am still struggling,” Diamond says in a phone interview with The Advocate. “Straight out of solitary confinement, but into another confinement here on parole. Parole stipulates that I must stay here in Rome [Ga.], and this town can be like a prison too. Yes, it’s a town in the Deep South, and down here you feel it even more that the transgender issue is the civil rights issue of our time.”

( [Original Source. Trigger Warnings for discrimination, transmisogynoir, rape, incarceration](http://web.archive.org/web/20150930120225/http://www.advocate.com/transgender/2015/9/29/after-three-years-jailed-men-ashley-diamond-speaks))

