---
id: 131655842139
slug: trannysylvania-trannysylvania-mctanuki
date: 2015-10-22 01:25:55 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[trannysylvania](http://trannysylvania.tumblr.com/post/131652308616):

> [trannysylvania](http://trannysylvania.tumblr.com/post/131652094326):
> 
> > [mctanuki](http://mctanuki.tumblr.com/post/131651632361):
> > 
> > > [trannysylvania](http://trannysylvania.tumblr.com/post/131650045446):
> > > 
> > > > [mxbees](http://mxbees.tumblr.com/post/131650007294):
> > > > 
> > > > > [trannysylvania](http://trannysylvania.tumblr.com/post/131648914571):
> > > > > 
> > > > > > there are trans women who don’t WANT to be on hormones and it seems pretty fucked up to suggest that they’re being poisoned lol
> > > > > 
> > > > > have you seen the many times i’ve bitched about this?
> > > > > 
> > > > > it endlessly annoys me that every so often you’ll see that fake positive posts
> > > > > 
> > > > > ‘all trans girls bodies are valid uwu’
> > > > > 
> > > > > only to see the same ppl talking about testosterone poisoning.
> > > > > 
> > > > > its one of the main reasons i stopped hanging around a lot of tgirls.
> > > > 
> > > > [@mctanuki](http://tmblr.co/migMIb990HNCQzlftEKXoOg)
> > > 
> > > Not being poisonous to one person doesn’t change the fact that it is a very dangerous, and sometimes deadly, chemical for other people. If testosterone \*doesn’t\* make you want to die, then it’s probably not a problem for you.
> > > 
> > > Quit trying to tell other girls how to contextualize their own lives.
> > 
> > it’s just pointlessly bad rhetoric and there’s literally no good reason to cling to it but OK gorl whatever gets you off
> 
> like there are a million other ways to say that not being medicated makes you want to die without giving the implication that trans women who are not medicating are dying slowly by virtue of that

this is literally the sadest response i’ve ever seen to someone getting called out for their shitty, body-shaming bullshit.

ok. ok.

so there is this incarcerated trans women in the US who recently got the first ‘go ahead’ to get GCS while incarcerated.

you know why? the doctors decided it was medically necessary in her case bc she has hep c and cannot take hormones. she got hep c bc she’s incarcerated in a men’s prison and was raped.

these are the kinds of ppl you’re shitting on @mctanuki.

i also have a medical condition that means i cannot take hormones.

'quit trying to tell other girls how to contextualize their own lives’

nice try at deflecting and redirecting blame.

no, no. please do not be confused.

you’re the asshole here.

you.

