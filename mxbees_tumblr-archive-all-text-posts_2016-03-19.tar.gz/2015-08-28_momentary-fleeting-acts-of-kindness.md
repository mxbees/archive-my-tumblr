---
id: 127822056294
slug: momentary-fleeting-acts-of-kindness
date: 2015-08-28 23:37:38 GMT
tags:
- discussing discourse
- klass with a k
title: Momentary, fleeting acts of kindness
---
I’m seeing this thing on my dash where a [Syrian man with his kid was photographed and ppl on the internet wanted to help him and his family](http://a-spoon-is-born.tumblr.com/post/127819766538/american-radical-so-these-pictures-of-a-syrian).

I mean. It’s a sweet story and I’m glad he’s getting some help…

But this isn’t the first time something like this has happened. Every so often an image (usually of poverty) will go viral. Or a certain story will. Like remember that bus lady that was being treated like garbage by the kids and people raised a bunch of money for her? Or the ‘handsome’ homeless (but white) model guy in Brazil?

I guess the problem I’m having with this is that its so…

Individual. These acts of kindness. These ppl deserve help. So do the ppl who never have an image of them go viral. I also always wonder… who takes these pictures? Why did they take them? Did the person consent?

While this is sort of a 'positive’ example of surveillance, I just have a lot of questions.

Like… why can’t we translate this compassion and desire to help to make structural changes so that no one ever has to be in their position?

