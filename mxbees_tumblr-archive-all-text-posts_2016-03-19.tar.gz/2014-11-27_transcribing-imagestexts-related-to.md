---
id: 103684821329
slug: transcribing-imagestexts-related-to
date: 2014-11-27 01:44:00 GMT
tags:
- the life of an ordinary bakla
title: transcribing images/texts related to ferguson/anti-Blackness
---
hey. i’m planning on spending a portion of my day tomorrow transcribing a bunch of the image posts that contain text (for accessibility).

if you have a specific post you’d like me to transcribe, reblog or reply to this post with the URL/link

and i’ll do my best to do them all.

important thing: this is for posts related to ferguson only (related stuff re: police violence against Black people is fine. so too is anything related to anti-Blackness. but only this stuff. i won’t do anything else)

