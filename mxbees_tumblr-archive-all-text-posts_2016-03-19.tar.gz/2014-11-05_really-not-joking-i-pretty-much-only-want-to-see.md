---
id: 101801619129
slug: really-not-joking-i-pretty-much-only-want-to-see
date: 2014-11-05 00:41:51 GMT
tags:
- media musings
title: 
---
really not joking

i pretty much only want to see chubby/fat Black and brown people

cosplaying lumpy space princess

white people aren’t worthy.

