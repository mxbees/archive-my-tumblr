---
id: 106275671649
slug: here-is-an-incomplete-list-of-things-that-are-not
date: 2014-12-27 01:35:00 GMT
tags:
- abnormal parenting
- ye olde abuse culture
- classical biyuti
title: Here is an incomplete list of things that are not normal.
---
(someone has asked me to repost this… at least i think this is what they wanted. this was originally published aug 13, 2013 in a series of short text posts. each line was once its own post but i put them together.)

Here is an incomplete list of things that are not normal.–

It is not normal to fear your parents.–

It is not normal to feel like you never have any privacy.–

It is not normal for your parents to stalk you.–

It is not normal to hate your parents.–

If you hate your parents you probably have a good reason to.–

It is not normal for your parents to disrespect your boundaries.–

It is not normal for your parents to not allow you any boundaries.–

It is not normal for your parents to hate you.–

It is not normal for your parents to withhold affection.–

It is not normal for your parents to bribe you with basic necessities to ensure compliance.–

It is not normal for your parents to make you feel sorry for being born.–

It is not normal for your parents to blame you for ruining their lives.–

It is not normal for your parents to make you feel guilty about being alive.–

It is not normal for your parents to isolate you from other people.–

It is not normal for your parents to belittle you.–

It is not normal for your parents to take their anger out on you in physical, mental, or anyway.–

It not normal for your parents to make you so dependent on them that you actually can’t live without them.–

It is not normal for your parents to be jealous of your romantic partners.–

It is not normal for your parents to deny you medical care.–

It is not normal for your parents to make you miserable.–

It is not normal for your parents to disregard your feelings.–

It is not normal for your parents to convince you that you’re mistaken about something they did to hurt you.–

It is not normal for your parents to not love you.–

It is not normal for your parents to make you beg for clothing, food, attention, or affection.–

Okay. I’m at work now. So I’ll stop. These things aren’t normal. Not all families are the same.

