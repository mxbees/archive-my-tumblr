---
id: 131411308249
slug: just-saw-that-super-gross-post-on-tumblr-with-this
date: 2015-10-18 11:40:32 GMT
tags:
- discussing discourse
- the life of an ordinary bakla
- op
title: 
---
just saw that super gross post on tumblr with this like… bragging checklist of all the STIs that op has never got. making it into some sort of sexual purity contest.

offline, i usually unabashedly talk about the time that i got chlymidia in my throat. i also had some weird skin thing on my junk that i can’t remember the name of (it wasn’t warts) – this sucked bc i had to get them removed with liquid nitrogen and that fucking hurt.

STIs happen. it isn’t a big deal. not something to be ashamed about either.

since i know the kinds of STIs i got aren’t the most heavily stigmatized, its actually why i make sure to talk openly about it, since it doesn’t bother me and i’m trying to help create a culture where ppl don’t have to feel ashamed and embarrassed about getting one.

(what i’m not saying here: that you have some sort of ‘ideological’ repsonsibility to disclose private medical information to other people. you don’t. i’m just talking about what i do, not making a recommendation for anyone else.)

