---
id: 102919731554
slug: it-is-hard-not-to-see-those-graphic-descriptions
date: 2014-11-18 01:29:00 GMT
tags:
- media musings
- transmisogyny is fun for the whole family
title: 
---
it is hard not to see those graphic descriptions of violence

against marginalized ppl

as some kind of gore porn for oppressors

like… u want a really good example of this?

read the stories about Mayang Prasetyo (big fuck TW on the stories about her though)

yes, the racist and transmisogynist aspects are troubling….

but few ppl talk about how the gory, sensationalized descriptions of death are just….

