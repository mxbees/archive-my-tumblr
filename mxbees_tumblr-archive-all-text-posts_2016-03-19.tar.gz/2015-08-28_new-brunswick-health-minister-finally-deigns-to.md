---
id: 127790633304
slug: new-brunswick-health-minister-finally-deigns-to
date: 2015-08-28 14:40:29 GMT
tags:
- trans health
- current events
title: New Brunswick Health Minister finally deigns to meet with trans activists
---
New Brunswick is currently the only province in Canada that doesn’t include GCS as part of its provincial healthcare. The minister finally invited local trans activists to meet, after they’d been trying for months. ([source: tw: for medical abuse]( [http://www.cbc.ca/news/canada/new-brunswick/transgender-advocates-land-meeting-with-victor-boudreau-1.3206821](http://www.cbc.ca/news/canada/new-brunswick/transgender-advocates-land-meeting-with-victor-boudreau-1.3206821)))

