---
id: 131437163758
slug: this-past-weekends-word-festival-thing-that-i-was
date: 2015-10-18 19:38:41 GMT
tags:
- able ability
- the life of an ordinary bakla
- op
title: 
---
This past weekends word festival thing that I was participating in, is (I think) the first time I didn’t bother trying to appear neurotypical.

And, tbh, it felt pretty amazing. Amazing to take myself and my own needs seriously in a way that I’ve never done before. I played spider solitaire pretty much everywhere and all the time (even during my own panel I was playing solitaire).

It helps keep me focused on the discussion. And by giving me something I like to focus on, it helps deal with all the extra sensory stuff that was going on.

But also… I didn’t shake anyone’s hand. I fucking hate that. Hands creep me out and I don’t like touching strange ppl’s hands. So I didn’t. When people reached out to shake I usually said, “sorry, i don’t shake hands”.

This was met with differing reactions. Some ppl seem to be quite bothered by it, while others were okay. Not that I cared either way, since I didn’t have to touch anyone’s hand and that makes _me_ happy.

No one really talked to me after any of the things I did. And I honestly can’t bring myself to care all that much. I’m sure I seemed unfriendly and whatever to a lot of ppl. And I just don’t care.

I do care about making an effort at work… but even there I’m starting to relax things. I’m already unemployable so who gives a fuck if people think I’m rude and unfriendly?

\*shrugs\*

