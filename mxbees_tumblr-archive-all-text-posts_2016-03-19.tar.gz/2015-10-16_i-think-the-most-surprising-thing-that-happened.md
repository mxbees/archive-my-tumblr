---
id: 131300401509
slug: i-think-the-most-surprising-thing-that-happened
date: 2015-10-16 19:38:42 GMT
tags:
- the life of an ordinary bakla
- op
title: 
---
i think the most surprising thing that happened last night is what didn’t happen:

no panic attack before my reading

sure. i was a bit nervous. but i experienced none of the panic symptoms that, up until last night, was just a ‘regular’ level of apprehension about public speaking.

it reminds me again about what i was writing about before. that you can have panic attacks without the 'classic’ symptoms for _years_ before you realize that you’ve been having them.

i feel frustrated and annoyed by popular (mis)conceptions of shit like anxiety and panic attacks all over again. bc… based on other ppl’s assertions that they too were 'nervous’ about public speaking, i honestly thought that having a full blown panic attack = nervous. i thought this was normal and that something most people experienced (bc i don’t know too mnay people who actually _enjoy_ public speaking).

the way our culture talks about this stuff… 'face ur fears’ 'do the thing even though it makes u want to die because otherwise ur Whiny Wimp’

in this way, we normalize an expectation that our responses and feelings in certain situations ought to be ignored or that they don’t matter. we end up having zero context and ability to discern whether or not a negative reaction we are experiencing is proportional to the circumstance, or of it is something that maybe requires attention.

literally. i’m 32. and last night was the first time that i realized that my feelings about public speaking aren’t 'normal’ bc they were actually full blown panic attacks.

and still ppl are constantly insisting that i (and others) be more open to being 'uncomfortable’. last night? was uncomfortable. it was something new and pushed me beyond my usual comfort zone. having a panic attack is something just a wee bit past 'uncomfortable’. i understand the difference now.

