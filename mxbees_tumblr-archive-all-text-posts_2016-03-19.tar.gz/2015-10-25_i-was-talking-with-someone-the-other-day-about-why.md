---
id: 131906003884
slug: i-was-talking-with-someone-the-other-day-about-why
date: 2015-10-25 21:37:21 GMT
tags:
- decolonization nao
- the life of an ordinary bakla
- op
title: 
---
i was talking with someone the other day about why being known as a ‘philosopher’ was important to me.

i remember writing a post ages ago about how i was reclaiming 'philosophical’ space by identifying myself and the work i do as philosophy. this is still true.

at one level, philosophy (logic specifically) is what i basically studied in my undergrad and my MA. this is my educational background.

on another level. because i focused on a non-white system of philosophy… it became pretty clear that, as far as most philosophy departments in Canada/US/Europe/Australia/New Zealan are concerned, the only people who do philosophy and who are capable of philosophy are white men.

philosophy is one of the 'interesting’ fields bc if you study it in Canada (like was mostly true for me), it is this bastion of white male supremacy that appears completely untouched by critical theory. untouched by people of colour, by women, by anyone who isn’t a white man.

so calling what i do 'philosophy’ as opposed to anything else is me pushing back against this. bc i this is where my training is. bc i do think that philosophy can and does happen beyond the scope of white men. bc fuck u, that’s why.

my eschewing of other labels (like 'artist’) isn’t about denying those and their importance, but about affirming the importance of what i do and how i do it.

s. hey. my name is b./nina and i’m a philosopher. nice to meet u.

