---
id: 126711934369
slug: hoodooqueer-b-binaohan-did-i-come-home-from
date: 2015-08-15 01:41:13 GMT
tags:
- epilepsy warning
- hdu
title: 
---
[hoodooqueer](http://hoodooqueer.tumblr.com/post/126710487604):

> [b-binaohan](http://b-binaohan.tumblr.com/post/126710400919):
> 
> > did i come home from getting tattooed only to find out that most of my friends on here are secret toxic whites?
> > 
> > \>.\>
> > 
> > what.&nbsp;
> > 
> > and all this time i’ve been a poc trans woman twoc?&nbsp;
> > 
> > hanging around all these whites???
> 
> How do we know you’re not a white appropriating trans PoC experiences?
> 
> SO WHAT IS THE TRUTH?<figure class="tmblr-full" data-orig-height="300" data-orig-width="500"><img src="https://31.media.tumblr.com/be794f70884a56b12b67136a124a8cd8/tumblr_inline_nt3omv5IbQ1rdzs46_500.gif" data-orig-height="300" data-orig-width="500"></figure>

i’ll have u know that i’m an authentic 110% trans of colour poc

