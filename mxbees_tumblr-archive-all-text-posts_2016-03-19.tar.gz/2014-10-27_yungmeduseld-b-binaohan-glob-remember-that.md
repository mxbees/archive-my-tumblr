---
id: 101044461964
slug: yungmeduseld-b-binaohan-glob-remember-that
date: 2014-10-27 00:48:51 GMT
tags: []
title: 
---
[yungmeduseld](http://yungmeduseld.tumblr.com/post/101044277559/b-binaohan-glob-remember-that-time-some-awful):

> [b-binaohan](http://xd.binaohan.org/post/101044192189/glob-remember-that-time-some-awful-girl-told-me):
> 
> > glob.
> > 
> > remember that time some awful girl told me that
> > 
> > i had
> > 
> > ~begging for money privilege~
> > 
> > remember that shit?
> > 
> > BEGGING for money PRIVILEGE
> 
> SCREAMS I REMEMBER
> 
> I think I laid into her ass too.

you probably did. it was pretty fucking ridiculous.  
  
i could probably dig it up in my archive, but who cares!  
  
irrelevant puta

