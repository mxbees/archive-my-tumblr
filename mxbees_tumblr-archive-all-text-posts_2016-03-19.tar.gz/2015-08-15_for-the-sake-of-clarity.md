---
id: 126743361454
slug: for-the-sake-of-clarity
date: 2015-08-15 12:26:50 GMT
tags:
- transmisogyny is fun for the whole family
- antiblackness is real
- black lives matter
- transmisogynoir
title: for the sake of clarity
---
[Elisha Walker’s body was found recently](http://goqnotes.com/36341/remains-of-missing-rowan-county-transgender-woman-found/comment-page-1/) (the report is from yesterday, and TW). &nbsp;She went missing in October 2014. She was a Black trans woman.

[Aston O’hara was murdered in Detroit on July 14](https://www.autostraddle.com/ashton-ohara-black-trans-and-genderfluid-has-been-murdered-im-running-out-of-hope-302881/). He was a Black genderfluid trans person (dmab and still used&nbsp;‘he/him’ pronouns).

From the autostraddle article:

> O’Hara’s murder makes him (he was using he/him pronouns at the time of his murder) the 14th confirmed murder of a trans person this year, and the 12th of a trans person of color. If we include Mya Hall, a black trans woman who was shot by NSA Security, each of those numbers goes up by one. We’re only eight months into the year and we’ve already seen more trans women murdered than all of last year.

(which i’m actually quoting bc Mya Hall isn’t erased or forgotten.)

These numbers don’t include Elisha Walker bc i guess ppl are assuming that she was likely murdered around the time she went missing.

I’m taking the time to write this because there have been \_so many\_ Black trans ppl murdered (or their bodies found) recently (Amber Monroe was also recently murdered in Detroit and Ms. Shade’s body was recently found in Dallas, both Black trans women).

