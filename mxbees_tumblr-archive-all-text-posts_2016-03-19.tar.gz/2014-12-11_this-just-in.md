---
id: 104921736009
slug: this-just-in
date: 2014-12-11 12:53:58 GMT
tags:
- antiblackness is real
title: 'This just in:'
---
[yungmeduseld](http://yungmeduseld.tumblr.com/post/104897524909/this-just-in):

> Suey Park is trash, and doesn’t deserve to call herself a woman of color as that term is a gift of solidarity from Black women, who she gaslights.
> 
> Receipts here:&nbsp;https://twitter.com/boldandworthy

i’m completely not-at-all surprised by this.

i mean… after the inherent crap in your #notyourasiansidekick business (critiques of which are on my main blog)

i pretty much knew she was trash…

so seeing her abuse a Black woman like this? yeah. seems about right.

