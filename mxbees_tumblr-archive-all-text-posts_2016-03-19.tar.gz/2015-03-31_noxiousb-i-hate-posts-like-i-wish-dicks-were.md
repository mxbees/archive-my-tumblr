---
id: 115076229959
slug: noxiousb-i-hate-posts-like-i-wish-dicks-were
date: 2015-03-31 00:42:17 GMT
tags:
- teh trans community
- fuck white trans women and their coopting of Black trans women's narratives
- transmisogynoir
title: 
---
[noxiousb](http://noxiousb.tumblr.com/post/115029388475/i-hate-posts-like-i-wish-dicks-were):

> i hate posts like&nbsp;
> 
> “i wish DICKS were oversexualized then MEN would know what its like to be stared at and everyone would judge their DICKS and BALLS because DICKS AND BALLS arent VIOLENTLY OVERSEXUALIZED”
> 
> because its like
> 
> Dicks ARE violently oversexualized, just not for men. Women with penises can’t exist as nonsexual beings. We literally have to shove our genitals inside of ourselves so that someone walking down the street doesnt see a bulge, flip absolute shit, and beat us to death for existing. Men use their privilege and social entitlement to protect them from genital related violence, while women with the same genital configuration suffer.&nbsp;
> 
> Like, fantasies of stripping men of their social armor are fine and good but it just makes me wonder as a trans woman where girls like me would be in this dichotomy.&nbsp;

i love how this says ‘beat us to death’ when this is a white trans woman talking.  
  
i think of this only bc i’ve been scanning headlines from a bout a month ago and seeing stories of Islan Nettles’ murderer being arrested….  
  
let’s not pretend like WHITE trans women are in any real danger of this happening.

