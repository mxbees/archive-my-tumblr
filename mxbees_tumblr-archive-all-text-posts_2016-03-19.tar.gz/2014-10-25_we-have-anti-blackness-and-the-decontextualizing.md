---
id: 100924355534
slug: we-have-anti-blackness-and-the-decontextualizing
date: 2014-10-25 18:01:35 GMT
tags:
- antiblackness is real
title: 
---
we have anti-Blackness and the decontextualizing of history to thank

for the shit currently happening in my inbox

‘fu! of course i’m a poc, because i say i am, Black ppl aren’t allowed to tell me that i’m not a poc! hdu’

gtfo.

