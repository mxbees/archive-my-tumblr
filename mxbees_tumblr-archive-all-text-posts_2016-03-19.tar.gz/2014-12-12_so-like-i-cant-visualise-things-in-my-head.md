---
id: 105003527889
slug: so-like-i-cant-visualise-things-in-my-head
date: 2014-12-12 12:53:53 GMT
tags:
- media musings
title: 
---
so, like, i can’t visualise things in my head

and i used to read a lot of romance

imagine my surprise when i realized that

‘tall dark and handsome’ = italians with brown hair and brown eyes.

like… what. a. colossal. disappointment.

