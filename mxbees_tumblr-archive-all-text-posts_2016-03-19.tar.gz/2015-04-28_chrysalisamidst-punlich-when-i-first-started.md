---
id: 117597811299
slug: chrysalisamidst-punlich-when-i-first-started
date: 2015-04-28 12:02:57 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
[chrysalisamidst](http://chrysalisamidst.tumblr.com/post/117580444523):

> [punlich](http://punlich.tumblr.com/post/117580357073/when-i-first-started-the-whole-transition-thing-i):
> 
> > When I first started the whole transition thing I gave everyone around me so much slack, I wanted it to be easy on them, didn’t want to make anything annoying or hard. So I was lax on pronouns and on name and on lots of stuff.
> > 
> > In the end I regret it so much because people just used it as an excuse to walk all over me when I finally started to say,&nbsp;“hey it’s been a while maybe you could use the right pronouns now?”
> > 
> > And it quickly became clear that none of them deserved me “making it easy for them” because there was zero reciprocation. No one wanted to make the process anything but nearly fucking impossible for me. They wanted it to not happen in the end and all I did was give them more room to harm me instead of giving them space to learn and grow and get better.
> > 
> > If I had been hard and fast on it, yeah I would’ve lost people but you know? I lost all those same people anyways, I just suffered uselessly for several years trying to help them catch up when I could’ve eliminated the trash right away and moved on.
> 
> I feel like b Jenner would say this in retrospect

this is also why when i’ve posted about the ppl who’ll respond to a change in pronouns with  
  
‘you’ll have to be patient with me, it might take me a while to get used to it’  
  
the answer is “NO. i won’t be patient”  
  
i don’t care if u have to spend 25 hours every day all day practicing before the next time u see me, you better be using the pronoun i told u to use.   
  
same with the name.  
  
and i also don’t care if i happen to change my name and pronouns every other day bc i’m either fluid or i’m trying to find what feels right  
  
i still expect u to actually try your hardest to get it right every single time.

