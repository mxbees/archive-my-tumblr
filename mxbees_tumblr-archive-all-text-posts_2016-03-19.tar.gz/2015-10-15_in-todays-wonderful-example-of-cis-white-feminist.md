---
id: 131239533807
slug: in-todays-wonderful-example-of-cis-white-feminist
date: 2015-10-15 20:33:14 GMT
tags:
- i rebuke thee feminism
- op
title: 
---
in today’s [wonderful example of cis white feminist boring attempts to be critical](https://twitter.com/anygirlfriday/status/654561339411668992). for those who don’t bother to click the reference link, it takes u to some feminists twitter where she is responding to some article about how cis women are getting ‘muscular’ bodies and 'looking like men’ and how cis men Do Not find this Attractive.

and the responses to this i’m seeing on twitter: 'women don’t do everything to please men’

not a single person (when i looked) has mentioned the BLATANT in ur face transmisogyny of this all.

i think i’ve personally seen two cis women re/tweet this with nary a mention of this.

anyway, here’s ur periodic reminder that mainstream feminism doesn’t consider trans women to be women.

