---
id: 103204523324
slug: i-like-how-for-about-6-seconds-tumblrs-search
date: 2014-11-21 15:18:20 GMT
tags: []
title: 
---
i like how

for about 6 seconds tumblr’s search interface was okay

but it is pretty much useless

again.

