---
id: 108366146004
slug: i-will-say-this-re-the-whole-do-not-women
date: 2015-01-17 18:50:03 GMT
tags:
- teh trans community
- asab
title: 
---
i will say this

re: the whole ‘do not-women’ experience misogyny

while (most) ppl can admit that men do not experience misogyny

there is some question as to whether non-women experience it…

and.

tbh. i don’t really care?

re: names for the experiences of ppl who are non-women (and presumably afab) and their possible experiences just isn’t a priority for me.

