---
id: 100774516913
slug: ignorance-is-a-poor-excuse
date: 2014-10-23 21:01:46 GMT
tags:
- teh trans community
- classical biyuti
title: Ignorance (is a poor excuse)
---
So that thread going on about cis people being ignorant of what ‘cis’ means and generally not knowing all the 'politically correct’ things. And that we should be polite and forgiving, I guess if someone is using the wrong language or whatever.

There is a reason why focusing on impacts, rather than intent, is important. To use an analogy that I think Riley has before…

If you are standing on my neck, but don’t know, it doesn’t actually change the fact that you are standing on my neck.&nbsp;

If I ask (or tell) you to get off my neck, responding with, “I didn’t know I was standing on your neck!” as you continue to stand on my neck doesn’t actually change shit.&nbsp;

If I ask, perhaps with some amount of anger, you to get the fuck off my neck, responding with, “Well, if you said please, I’d get off but you are being rude,” WHILE STILL STANDING ON MY FUCKING NECK.

If, while standing on my neck, you finally hear my chocking and gasping breath, you say, “It appears I’m standing on your neck, maybe you could share your experience with me,” but not actually getting off my neck.&nbsp;

Tell me. At what point is it okay for me to blame you for standing on my neck? Why do you even think I care about why you are doing it? I don’t.&nbsp;

All I want is to breath and live, BUT YOU ARE STANDING ON MY FUCKING NECK!

I don’t care that you didn’t know. I don’t care that there may have been some magic word that would elicit your cooperation. I don’t care if you just want to learn.&nbsp;

I don’t care why someone is oppressing me. Don’t care and I don’t want to hear it.&nbsp;

Because you never fucking get it: all I want to do is live and breath but all I can see is your fucking foot on my throat. Maybe get the fuck off and maybe I’ll start caring about why you were doing it.&nbsp;

