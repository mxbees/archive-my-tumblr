---
id: 127820782945
slug: a-recent-federal-crackdown-is-being-hailed-as-a
date: 2015-08-28 23:17:00 GMT
tags:
- current events
- law suit
- discrimination
- medical abuse
title: 
---
> A recent federal crackdown is being hailed as a landmark in establishing standards for nondiscriminatory care of transgender patients, and industry experts say every health-care provider should take it as a warning and ensure compliance.
> 
> The recent settlement reached between The Brooklyn Hospital Center and Department of Health & Human Services’ Office of Civil Rights marked the first time the federal agency actively enforced a part of the Affordable Care Act that prohibits discrimination.

( [Original Source. Trigger Warnings for transmisogyny, medical abuse.](https://archive.is/B0KPB))

