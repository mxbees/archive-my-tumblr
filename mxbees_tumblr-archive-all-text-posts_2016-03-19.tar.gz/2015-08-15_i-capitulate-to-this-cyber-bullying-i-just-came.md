---
id: 126713803339
slug: i-capitulate-to-this-cyber-bullying-i-just-came
date: 2015-08-15 02:10:25 GMT
tags:
- epilepsy warning
- in reality
- i'm just really really tired
- and not actually capable of sustaining the fun
- lol
- i just wanted to join in before going to bed
- but i posted a pic of my tattoo on instagram
- if u want to see how it looks
- ur all the best
- even if u bullied me into going to bed
title: 
---
i capitulate to this cyber bullying.&nbsp;

<figure data-orig-height="184" data-orig-width="245"><img src="https://31.media.tumblr.com/9c39428344df7d06bf9ccff8df498565/tumblr_inline_nt3pw4yVQN1rdzs46_500.gif" data-orig-height="184" data-orig-width="245"></figure>

i just came out to have a good time tonight, and now i’m feeling so attacked.

<figure data-orig-height="263" data-orig-width="245"><img src="https://38.media.tumblr.com/ea586f9d3b14c88edd53a5b775c1813d/tumblr_inline_nt3pywOtku1rdzs46_500.gif" data-orig-height="263" data-orig-width="245"></figure>

i hope ur happy.&nbsp;

