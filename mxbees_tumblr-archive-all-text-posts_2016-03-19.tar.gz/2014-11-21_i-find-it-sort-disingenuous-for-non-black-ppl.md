---
id: 103232962779
slug: i-find-it-sort-disingenuous-for-non-black-ppl
date: 2014-11-21 22:48:08 GMT
tags:
- antiBlackness is real
- teh trans community
title: 
---
I find it…

Sort disingenuous for non Black ppl to ask, at this point

“what can we do about dmr and antiBlackness”

???

as if this is a real question.

first. we as non Black ppl created this situation. we are the antiBlack context that allowed two nonBlack poc to raise to such prominence in the community

to the extent that they are being asked to stand as authorities over things that they can never and should never be allowed to claim authority over.

we did this. we are the context that allows this to happen.

what can we do?

the question isn’t for us to answer.

Black ppl are already telling us what they need.

