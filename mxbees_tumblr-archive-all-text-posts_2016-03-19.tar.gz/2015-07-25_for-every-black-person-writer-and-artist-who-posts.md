---
id: 124994510824
slug: for-every-black-person-writer-and-artist-who-posts
date: 2015-07-25 11:16:01 GMT
tags:
- tech support
title: For EVERY Black person writer and artist who posts their work online!
---
.&nbsp; [sourcedumal](http://sourcedumal.tumblr.com/post/124965052211/for-every-black-person-writer-and-artist-who-posts):

> [dynastylnoire](http://dynastylnoire.tumblr.com/post/106668387205/for-every-black-person-writer-and-artist-who-posts):
> 
> > [decolonize-all-the-things](http://decolonize-all-the-things.tumblr.com/post/106668213693/for-every-black-person-writer-and-artist-who-posts):
> > 
> > > Get a creative commons license to protect your work.
> > > 
> > > LINK:&nbsp; [https://creativecommons.org/](https://creativecommons.org/)
> > 
> > BOOOOOOOOOOOOOOOOOOST [countessnoir](http://tmblr.co/mOMCLkeKeLsvqIumIN4tyKQ) [ouijubell](http://tmblr.co/mu80yn1adAtxMFQjTJG-afw) [hallokatzchen](http://tmblr.co/mmRO6zoIo8LMFa_0FVv8jEg) [coppertonepretty](http://tmblr.co/mBineoAOQSzASIzVGKIpCXg) [kiwimayu](http://tmblr.co/mi25sX8ErX0vU-4Xw-Egx-g)And all my other artist friends

i know this will be the third time i make a post like this, but it is really important:

creative commons licenses are not about&nbsp;‘protecting’ your work. they are about allowing easier re/use and sharing of your work.&nbsp;

copyright automatically applies to anything you create and is stronger and more restrictive than any creative commons license.&nbsp;

from the creative commons website:

> Creative Commons is a nonprofit organization that enables the sharing and use of creativity and knowledge through free legal tools.Our free, easy-to-use [copyright licenses](http://creativecommons.org/licenses/) provide a simple, standardized way to give the public permission to share and use your creative work — on conditions of your choice. CC licenses let you easily change your copyright terms from the default of “all rights reserved” to “ [some rights reserved](http://wiki.creativecommons.org/FAQ#What_does_.22Some_Rights_Reserved.22_mean.3F).”

please note that last sentence applying a CC license to your work changes it from \_all rights reserved\_ to&nbsp;“some rights reserved”

so doing \_nothing\_ means that you retain ALL of your copyrights. applying a CC license means that you are (willingly) giving up some of your copyrights.

what does this look like or mean, exactly for various licenses?

well, if you apply the least restrictive license the CC-BY (well, ok, CC-0 is the least restrictive but i doubt anyone will be wanting – if they are looking for protection – to consign their work to the public domain), say someone on here as a blog licensed CC-BY. This means I could take their \_entire\_ blog, organize it into a pdf and make a book to sell on amazon, so long as i attribute the work to the creator. In fact, there are entire content mining firms that do exactly this with wikipedia articles. you can, right now, go onto amazon and buy a print version of a collection of wikipedia articles that you can read for free. &nbsp;

what about the most restrictive? the CC-BY-ND-NC? this license would prevent the above use case but would still allow me to, for example, repost an entire blog post by someone else on my blog – without ever needing to ask them, since my blog is a non-commercial blog, so long as i credit them properly.&nbsp;

however, if you do nothing at all, you automatically retain all your copyrights and the maximum level of control over your creations. this is&nbsp;‘all rights reserved’.&nbsp;

now, depending on your jurisdiction, you might have to register your copyright in order to enforce it via litigation (this is true of the US). but enforcement is different than retaining the rights.&nbsp;

anyway. i write all of this because i see a lot of misinformation about how copyright works and what creativecommons means.&nbsp;

