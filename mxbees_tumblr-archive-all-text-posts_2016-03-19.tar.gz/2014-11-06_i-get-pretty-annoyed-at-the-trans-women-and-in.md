---
id: 101943034359
slug: i-get-pretty-annoyed-at-the-trans-women-and-in
date: 2014-11-06 19:12:56 GMT
tags:
- transmisogyny is fun for the whole family
- teh trans community
title: 
---
i get pretty annoyed at the trans women (and in general trans ppl)

who seem to forget that not all of us want to do hormones or are able to access it

hormones aren’t essential to the trans experience

not essential for transitioning

and this definitely goes for all the ppl who talk about

~testosterone~ or ~estrogen~

in disgusting and essentialist ways

like hearing ~radical~ trans women mock transbr0s and cis men

bc they have ‘testosterone poisoning’

and use this like an insult

yeah. pretty fucking radical to essentialize ur hormones and shit on the trans women who aren’t doing HRT (for whatever reason)

