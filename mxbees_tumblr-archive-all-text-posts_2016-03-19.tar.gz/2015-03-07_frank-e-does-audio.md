---
id: 112991045114
slug: frank-e-does-audio
date: 2015-03-07 18:49:16 GMT
tags:
- able ability
title: 
---
[frank-e-does-audio](http://frank-e-does-audio.tumblr.com/post/112984807344/a-spoon-is-born-frank-e-does-audio-replied-to):

> [a-spoon-is-born](http://a-spoon-is-born.tumblr.com/post/112984377718/frank-e-does-audio-replied-to-your-post-no-one):
> 
> > [frank-e-does-audio](http://frank-e-does-audio.tumblr.com/) replied to your [post](http://a-spoon-is-born.tumblr.com/post/112983221583/no-one-warned-me-that-writing-fiction-takes-this): _[No one warned me that writing fiction takes this…](http://a-spoon-is-born.tumblr.com/post/112983221583/no-one-warned-me-that-writing-fiction-takes-this)_
> > > I have only ever completed anything during hypomanic episodes. Good luck to you, lol.
> > 
> > I had to look up hypomanic. And well, let’s just say lucky for me I’m tired of being diagnosed with shit because that’s….yeah.
> > 
> > But anyhow, I’m feeling like this is a thing I have a handle on. A lot of the time when I try something new, I have to just \*do\* and be like, “is this something I already know how to do?\*” I was suspecting the answer was yes, and I was not disappointed. I can already envision myself in six months and rereading the shit I’m doing now like “TERRIBLE!” That’s kind of a good feeling.
> > 
> > :) Thank you.
> > 
> > \*And when the answer is “no” there may be a great deal of crying. And some quitting.
> 
> I actually got this term from biyuti. We were talking and they said they experienced hypomania and I was like explain the difference between hypo and just mania, and then I was like OOOOOOOHH, that’s me.  
>   
> If I force myself to write, I usually get into it and feel really good about myself. Writing is my first language. Speaking sucked until I was like 19.  
>   
> My issue is always no motivation, or self doubt… Like I will go, no one will believe this. This is too unrealistic (even when writing fantasy). But let someone else say that and I’m like are YOU FUCKING BLIND THIS IS BRILLIANT… Issues  
>   
> and I have no idea what I actually meant to write you.

i like how i got everyone with this…  
  
but i can’t actually get a psych to listen to me bc to them, the only mania is mania. hypomania? lol nope.   
  
to them it seems like the only bipolar that exists is type one.  
  
nothing else.

