---
id: 100925075719
slug: also-if-u-dont-like-something-someone-else
date: 2014-10-25 18:11:42 GMT
tags: []
title: 
---
also, if u don’t like something someone else said…

take it up with them.

