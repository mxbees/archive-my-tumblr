---
id: 127886329924
slug: kindness-is-cheaper-but-death-is-the-cheapest
date: 2015-08-29 20:15:37 GMT
tags:
- klass with a k
- op
title: kindness is cheaper but death is the cheapest
---
i just saw a link to an article discussing how its cheaper to give homeless ppl a home (or even just steady shelter) than it is to leave them on the streets.

calculated by the cost of a bed/shelter vs. being harassed by police, needing emergency medical help bc not having a home is hard on the body and dangerous, etc and so on.

i’ve talked before about why economic arguments for liberation don’t work. this is another example.

the classism that feeds into why ppl are left out to find for themselves isn’t about money. and the saving of it.

capitalism would be most happy if these unproductive ppl who don’t contribute to the economy in a meaningful way would just die.

_that’s_ the point.

