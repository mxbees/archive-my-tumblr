---
id: 127891036535
slug: the-us-dept-of-justice-wants-a-ruling-on-the
date: 2015-08-29 21:27:44 GMT
tags:
- current events
- workplace discrimination
- lawsuits
- transmisogyny
title: The US Dept. of Justice wants a ruling on the exclusion of GID as a protected
  disability.
---
Kate Blatt is involved in an antibias case, claiming two grounds for discrimination: bassed on sex and based on disability: “Blatt claims Cabela’s discriminated against her on the basis of her disability.”

The DOJ doesn’t think she ought to be allowed to challenge this exclusion, since the grounds for sex discrimination, if found in her favour, would remove the need to explore whether or not gender dysphoria’s exclusion from the Americans with Disabilities Act is a bad thing.

( [Original Source. Trigger Warnings for workplace discrimination, the legal system](https://web.archive.org/web/20150829094912/http://www.epgn.com/news/local/9284-both-sides-in-trans-case-urge-judge-to-issue-ruling))

