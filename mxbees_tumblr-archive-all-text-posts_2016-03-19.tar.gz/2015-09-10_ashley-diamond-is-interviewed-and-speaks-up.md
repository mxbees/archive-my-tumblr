---
id: 128790248211
slug: ashley-diamond-is-interviewed-and-speaks-up
date: 2015-09-10 18:44:01 GMT
tags:
- current events
- black trans women
- incarceration
title: Ashley Diamond is interviewed and speaks up.
---
 **Note: There is a video of the interview in this that I can’t watch because I don’t have flash in my browser. So I cannot TW for any of that content or summarize it. This is just from the text. But I do encourage people to watch the video, since again, its rare we get to see incarcerated Black trans women actually speaking for themselves**

> For the first time, Ashley Diamond, a transgender woman, is speaking out about her mistreatment in the Georgia prison system.
> 
> “I really didn’t know what to expect,” Diamond said about going to prison for the first time. “As soon as I got there, I was immediately told to strip in front of other men. Of course, there were stares and hollers. It was one of the most humiliating moments of my life.”
> 
> According to Diamond, the assaults began immediately. She said she was “targeted right away.”
> 
> “It was an every night thing,” Diamond said of the attacks. “(The staff) turned a blind-eye to it all. I think that the gangs run the prisons. I think think that I was extorted and used.”
> 
> “People need to realize transgender people are just like anyone else. We have the same dreams as everyone else – we are just like every one else, it just so happens we were born in the wrong body,” she said. “This is about transgender people being accepted, period. There are so many people there counting on me and it’s a role I gladly assume.”

( [Original Source. Trigger Warnings for rape, institutional abuse, medical abuse,](http://www.11alive.com/story/news/local/2015/09/09/transgender-woman-speaks-out-about-mistreatment-in-georgia-prisons/71934508/))

