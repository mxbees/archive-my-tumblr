---
id: 107038295849
slug: ugh-this-book-not-sure-i-can-keep-listening
date: 2015-01-03 21:18:27 GMT
tags:
- media musings
title: 
---
ugh….

this book. not sure I can keep listening.

protag is a cop and gloating about her extra brutal tactics for bringing in ppl.

like.

fucking gross.

