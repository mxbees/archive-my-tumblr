---
id: 128059800067
slug: memorial-held-for-tamara-dominguez-in-kansas-city
date: 2015-08-31 22:22:48 GMT
tags:
- current events
- tamara dominguez
- tdor
title: Memorial held for Tamara Dominguez in Kansas City
---
The title kind of says it all. I mostly wanted to share this because remembering Tamara Dominguez is important.

Also, there are some nice pictures in the original story.

( [Original Source. Trigger Warnings for non-graphic descriptions of murder, death.](https://web.archive.org/web/20150831121832/http://kcur.org/post/activists-hold-community-memorial-service-slain-kansas-city-transgender-woman))

