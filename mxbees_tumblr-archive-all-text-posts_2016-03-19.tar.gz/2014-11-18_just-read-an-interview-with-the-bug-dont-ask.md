---
id: 102957607159
slug: just-read-an-interview-with-the-bug-dont-ask
date: 2014-11-18 14:06:17 GMT
tags:
- transmisogyny is fun for the whole family
title: 
---
just read an interview with the bug

(don’t ask why)

i like how she managed to turn a question about her fav joy division song into how much she hates trans women

like…

that is a serious level of obsession

