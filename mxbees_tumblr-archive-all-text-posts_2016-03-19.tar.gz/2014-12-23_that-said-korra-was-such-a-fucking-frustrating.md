---
id: 105920626814
slug: that-said-korra-was-such-a-fucking-frustrating
date: 2014-12-23 01:58:30 GMT
tags:
- media musings
title: 
---
that said…

korra was such a fucking frustrating show

not necessarily bc it wasn’t as good as atla (it wasn’t)

but bc it had…

the potential to be SO MUCH better

i don’t like how the narrative treated korra (esp. in contrast with aang)

half the time i was watching i wanted to punch my monitor

overall, the writing was sloppy and unfocused.

