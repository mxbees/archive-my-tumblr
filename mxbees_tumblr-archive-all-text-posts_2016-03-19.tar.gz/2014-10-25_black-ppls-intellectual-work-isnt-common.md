---
id: 100924645989
slug: black-ppls-intellectual-work-isnt-common
date: 2014-10-25 18:05:44 GMT
tags:
- antiblackness is real
title: 
---
Black ppl’s intellectual work isn’t common property, FYI

so, yeah, if a Black person (and they aren’t monoliths)

decides that there is _this_ line demarcating between who is or isn’t a poc

then that’s that.

srsly.

don’t come into my inbox talking about how ‘poc appropriate’ ur culture

when u are literally trying to colonize Black ppl’s intellectual work and history

