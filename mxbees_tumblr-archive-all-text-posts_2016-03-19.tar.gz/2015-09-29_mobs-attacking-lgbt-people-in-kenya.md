---
id: 130140319901
slug: mobs-attacking-lgbt-people-in-kenya
date: 2015-09-29 16:55:18 GMT
tags:
- current events
- kenya
- homophobia
title: Mobs attacking LGBT people in Kenya
---
> Homophobic mobs have repeatedly attacked lesbian, gay, bisexual and transgender (LGBT) people in Kenya but police are unwilling to even attempt to bring the perpetrators to justice, rights groups said on Monday.
> 
> Homosexuality is taboo in almost all African countries and is punishable by up to 14 years in jail in Kenya.
> 
> Violence against LGBT people is common in the east African nation, but victims fear reporting hate crimes to the police who, in turn, often refuse to pursue their cases.
> 
> There have been at least six incidents since 2008 of mob violence against LGBT minorities on the coast, Human Rights Watch (HRW) and PEMA Kenya, a community organisation in the coastal city of Mombasa, said in a report.

( [Original Source. Trigger Warnings for violence, police discrimination, police violence, rape](http://web.archive.org/web/20150929101548/http://www.the-star.co.ke/news/homophobic-mobs-attack-lgbt-people-kenya-impunity-report))

