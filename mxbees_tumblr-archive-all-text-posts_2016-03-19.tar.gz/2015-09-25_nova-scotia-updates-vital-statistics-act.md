---
id: 129860143576
slug: nova-scotia-updates-vital-statistics-act
date: 2015-09-25 18:44:18 GMT
tags:
- current events
- canada
- documentation
title: Nova Scotia updates Vital Statistics Act
---
Nova Scotia just updated their vital statistics act to allow transgender people born within the province to change their gender marker on their birth certificate with a letter of self declaration and supporting document from a health professional.

( [Original Source](http://web.archive.org/web/20150925100350/http://www.cbc.ca/news/canada/nova-scotia/transgender-nova-scotians-birth-certificates-1.3242382))

