---
id: 104093543764
slug: soooo-something-ive-been-thinking-about-re
date: 2014-12-01 19:51:14 GMT
tags:
- antiblackness is real
title: 
---
soooo

something i’ve been thinking about re: recent murders of Black ppl by police

is in some of the cases, the police were called.

like. With Tamir Rice, someone called the police saying they saw him with a ‘gun’

and this is also true of John Crawford… like look at this:

> Police had repeatedly been told via a customer on the line to a 911 dispatcher that John Crawford III was pointing the gun at shoppers and may have loaded it with bullets. But the footage, released by prosecutors on Wednesday, shows Crawford walking past several customers in the minutes before he died without pointing the gun at them. ( [source](http://biyuti.com/9))

one thing we never ever hear about in these stories is about the ppl who called the cops

bc… i’m like 99.9% sure that is was probably a white person who called the cops on John Crawford and Tamir Rice (and if not a white person, a non-Black person).

the role these ppl played in murdering these Black ppl ought not to be forgotten, because these aren’t the only two examples (just recent ones that are in my mind atm)

who is this person who _repeatedly_ lied about what John Crawford was doing and got him killed?

why don’t we know their name?

because the anti-Blackness involved in these police killings isn’t just about the police… it is about the people who’re able to mobilize the state to legally murder Black ppl.

who the fuck is calling the cops on Black ppl and getting them killed?

i want to know their names. they should be as famous as the cops who killed them since they are directly complicit in it.

