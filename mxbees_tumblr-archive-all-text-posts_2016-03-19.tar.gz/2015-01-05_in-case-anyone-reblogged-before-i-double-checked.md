---
id: 107218001494
slug: in-case-anyone-reblogged-before-i-double-checked
date: 2015-01-05 14:42:29 GMT
tags:
- accountability post
title: 
---
in case anyone reblogged before i double checked the last post:

i took a second look and realized not everyone in the ‘hispanic not latino’ category was white

sorry

