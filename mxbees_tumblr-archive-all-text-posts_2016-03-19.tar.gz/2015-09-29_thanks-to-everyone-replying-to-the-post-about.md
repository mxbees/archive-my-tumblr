---
id: 130100320939
slug: thanks-to-everyone-replying-to-the-post-about
date: 2015-09-29 01:15:54 GMT
tags:
- op
- antiblackness is real
- race to the bottom
title: 
---
thanks to everyone replying to the post about racism/race

(i stopped using xkit so i cant actually reply to replies in an easy way)

i appreciate the validation.

idk. it really fucks me up to go from reading primary sources in scientific racism and eugenics

to this academic stuff where they are like

‘everything is racism!!!’

its weird how this… idk. generalization of racism and what it refers to is also striking me as anti-Black.

(note: i have no idea to what extent these critical race ideas might’ve been articulated by Black people. i didn’t look into the race of everyone i read today.)

but… i can’t really help it.

ppl arguing that racism isn’t always about bodies and biology… but never really addressing how

(to the extent that their theories are true)

racism/white supremacy/anti-Blackness

seems so firmly rooted in the Black body and on Black skin.

(ok. i’m going to stop here bc i’m tired and confused and i’m not sure i can adequetly articulate what i want to say)

