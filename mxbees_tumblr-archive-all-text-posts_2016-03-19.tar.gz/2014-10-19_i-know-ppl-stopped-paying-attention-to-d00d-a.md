---
id: 100442754339
slug: i-know-ppl-stopped-paying-attention-to-d00d-a
date: 2014-10-19 21:26:46 GMT
tags:
- able ability
title: 
---
i know ppl stopped paying attention to d00d a while back…

but that fucking bullshit about the point of ‘recovery’ is health

and that tumblr promotes this culture of validation over recovery… a

and it is like… are u fucking srs rn?

some chronic shit is chronic. that means there is no coherent path to ‘recovery’ such that ur magical notion of ‘health’ is achievable.

