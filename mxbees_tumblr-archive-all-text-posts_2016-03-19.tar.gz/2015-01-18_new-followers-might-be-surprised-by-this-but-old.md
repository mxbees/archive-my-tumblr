---
id: 108435357094
slug: new-followers-might-be-surprised-by-this-but-old
date: 2015-01-18 11:47:39 GMT
tags:
- media musings
title: 
---
new followers might be surprised by this, but old ones won’t…

i still watch glee. yes. i’m well aware of how problematic the show is. i’ve been blogging and criticising the show since about season 3.

and….

i sort of stopped blogging about it a while ago bc while i still watch the show i’m pretty disengaged now and watch for reasons (but usually spend most of the episodes fast forwarding)

anyway.

so…..

glee had coach bieste come out as a trans man. which. cool.

but now the burning question is, is why the fuck glee manages to treat _him_ with humanity and respect but spent a season and a half basically making lol-tranny jokes about Unique…

i’ll give u two guesses…

coach Bieste, of course, is a white trans guy. and so is afforded a level of humanity and compassion in the show that Unique, never ever got.

i mean. the discrepancy between how sue treats Bieste and how she treated Unique? like. holy fuck. she is 100% supportive of bieste but literally spent her entire time bullying Unique and outright using transmisogynist slurs against her while policing her in the washroom and generally being a giant shitbag.

more irritating is the way that everyone (in the mainstream media and fandom) is talking about glee’s sensitive portrayal of transness….

this is why i ejected myself from the glee fandom. this kind of cognitive dissonance around the issues of race in the show is fucking amazing.

worse yet, is the self-congratulatory way that glee has been patting itself on the back for all the groundbreaking shit it apparently did over the series (since this is the last season).

it should be super duper clear that the show has only had positive representations of white ppl, first and foremost, and where queer/trans shit is concerned this is especially true.

