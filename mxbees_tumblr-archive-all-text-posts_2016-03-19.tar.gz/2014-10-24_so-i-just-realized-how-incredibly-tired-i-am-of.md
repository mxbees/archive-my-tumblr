---
id: 100854955125
slug: so-i-just-realized-how-incredibly-tired-i-am-of
date: 2014-10-24 21:01:40 GMT
tags:
- media musings
- classical biyuti
title: 
---
So. I just realized how incredibly tired I am of that romance trope of ‘we annoy each other because we are such opposites, so obviously we shall fall in love!“

Because. LIke. Does this happen in real life? Does anyone actually think ithis is appealing? 'Cause I have never considered dating anyone who irritated the fuck out of me. Ever.

If you annoy me. I will not want to have sex with you. Or even sit and have coffee with you.

Why is this such a thing?

