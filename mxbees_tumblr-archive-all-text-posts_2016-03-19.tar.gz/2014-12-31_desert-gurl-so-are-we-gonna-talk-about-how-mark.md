---
id: 106661029614
slug: desert-gurl-so-are-we-gonna-talk-about-how-mark
date: 2014-12-31 01:10:36 GMT
tags:
- teh trans community
title: 
---
[desert-gurl](http://desert-gurl.tumblr.com/post/106659063756):

> So are we gonna talk about how Mark Aguhar’s/ posts about Mark posts have less than one tenth the notes that Leelah Alcorn’s/ posts about Leelah Alcorn do…?

ok ok

i already made a reply but i do actually want to talk about this.

like. obviously Mark was too fat and too brown and too unapologetic about being both of those things for the mainstream to care about. fuck. for even more than other trans girls/nb trans feminine poc/trans poc to really care about.

but like.

LIKE

it goes further than just how much attention has been paid to either

but also the _kind_ of attention

bc. you know how i’ve seen white cis/trans ppl engage with Mark and her legacy?

i’ve seen a white trans woman claim Mark as _her_ ancestor, trigger the everloving fuck out of my by doing so, AND NEVER APOLOGIZING FOR IT.

i’ve seen white afab queers and nb trans academics ~study~ Mark and her blog

i’ve seen white trans ppl of all kind _steal_ her art and words AND/OR completely decontextualize the source and the context

bc even in death girls like Mark aren’t ever _human_

we are case studies.

rhetorical points.

objects to be consumed

